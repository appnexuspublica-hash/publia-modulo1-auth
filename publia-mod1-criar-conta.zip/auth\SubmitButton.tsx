"use client";
import { useFormStatus } from "react-dom";

export default function SubmitButton({ label = "Enviar", loadingLabel = "Carregando..." }: { label?: string; loadingLabel?: string }) {
  const { pending } = useFormStatus();
  return (
    <button
      type="submit"
      className="w-full h-11 rounded-md bg-blue-600 text-white font-medium transition hover:bg-blue-700 disabled:opacity-60"
      disabled={pending}
    >
      {pending ? loadingLabel : label}
    </button>
  );
}
