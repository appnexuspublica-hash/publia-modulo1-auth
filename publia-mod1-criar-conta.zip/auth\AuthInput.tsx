"use client";
import { InputHTMLAttributes, ReactNode } from "react";

type Props = {
  label: string;
  name: string;
  id?: string;
  hintRight?: ReactNode;
} & InputHTMLAttributes<HTMLInputElement>;

export default function AuthInput({ label, name, id, hintRight, ...rest }: Props) {
  const inputId = id || name;
  return (
    <div>
      <div className="flex items-center justify-between">
        <label htmlFor={inputId} className="block text-sm font-medium text-gray-700">
          {label}
        </label>
        {hintRight ? <span className="text-xs text-blue-600">{hintRight}</span> : null}
      </div>
      <input
        id={inputId}
        name={name}
        className="mt-1 w-full h-11 rounded-md border border-gray-300 bg-white px-3 text-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
        {...rest}
      />
    </div>
  );
}
