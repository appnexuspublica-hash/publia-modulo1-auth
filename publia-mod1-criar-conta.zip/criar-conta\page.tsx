﻿import { redirect } from "next/navigation";
import AuthShell from "../../../components/auth/AuthShell";
import SignupForm from "./SignupForm";

export const metadata = {
  title: "Criar conta - Publ.IA / Nexus Pública",
};

type PageProps = {
  searchParams?: { tk?: string };
};

export default function CriarContaPage({ searchParams }: PageProps) {
  const tokenParam = searchParams?.tk || "";

  const redirectUrl =
    process.env.REDIRECT_BLOCKED_SIGNUP || "https://nexuspublica.com.br/";
  const expectedToken = process.env.SIGNUP_TOKEN;

  // 1) Sem token na URL -> redireciona para o site público
  if (!tokenParam) {
    redirect(redirectUrl);
  }

  // 2) Com token na URL -> tela de cadastro
  const tokenOk = !!expectedToken && tokenParam === expectedToken;

  return (
    <AuthShell
      title="Publ.IA - Nexus Pública"
      subtitle="Crie sua conta para acessar o painel."
    >
      {/* O formulário é client component e recebe o token e o estado de validade */}
      <SignupForm token={tokenParam} tokenOk={tokenOk} />
    </AuthShell>
  );
}
