"use client";

export default function Alert({ type, children }: { type: "error" | "success"; children: React.ReactNode }) {
  const style = type === "error" ? "border-red-200 bg-red-50 text-red-700" : "border-emerald-200 bg-emerald-50 text-emerald-700";
  return <div className={`mb-4 rounded-md border px-3 py-2 text-sm ${style}`}>{children}</div>;
}

