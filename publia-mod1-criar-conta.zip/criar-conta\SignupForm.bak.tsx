﻿"use client";
import { useEffect, useState } from "react";
import { useFormState } from "react-dom";
import { useSearchParams, useRouter } from "next/navigation";
import type { SignUpState } from "./formActions";
import { signUpAction } from "./formActions";

const initialState: SignUpState = { ok: false, error: "" } as any;

export default function SignupForm() {
  const search = useSearchParams();
  const router = useRouter();
  const tk = search.get("tk") || "";
  const [state, formAction] = useFormState<SignUpState, FormData>(signUpAction, initialState);
  const [showPassword, setShowPassword] = useState(false);
  const loginUrl = process.env.NEXT_PUBLIC_AFTER_SIGNUP_LOGIN || "/login";

  useEffect(() => {
    if (state?.ok) {
      const t = setTimeout(() => router.push(loginUrl), 1200);
      return () => clearTimeout(t);
    }
  }, [state?.ok, router, loginUrl]);

  return (
    <form action={formAction} className="space-y-4 max-w-xl">
      <input type="hidden" name="tk" value={tk} />

      <div>
        <label className="block text-sm">CPF/CNPJ</label>
        <input name="cpf_cnpj" required className="w-full border p-2 rounded" />
      </div>

      <div>
        <label className="block text-sm">Nome / Razão Social</label>
        <input name="nome" required className="w-full border p-2 rounded" />
      </div>

      <div>
        <label className="block text-sm">E-mail</label>
        <input type="email" name="email" required className="w-full border p-2 rounded" />
      </div>

      <div>
        <label className="block text-sm">Telefone (WhatsApp)</label>
        <input name="telefone" required className="w-full border p-2 rounded" />
      </div>

      <div>
        <label className="block text-sm">Cidade/UF</label>
        <input name="cidade_uf" required className="w-full border p-2 rounded" />
      </div>

      <div>
        <label className="block text-sm">Senha (mínimo 6)</label>
        <div className="relative">
          <input
            type={showPassword ? "text" : "password"}
            name="senha"
            minLength={6}
            required
            className="w-full border p-2 rounded pr-20"
          />
          <button
            type="button"
            onClick={() => setShowPassword((v) => !v)}
            className="absolute right-2 top-1/2 -translate-y-1/2 text-blue-700 text-sm"
          >
            {showPassword ? "Ocultar" : "Mostrar"}
          </button>
        </div>
      </div>

      <button type="submit" className="px-4 py-2 rounded bg-blue-600 text-white">
        Criar conta
      </button>

      {state && !state.ok && (state as any).error && (
        <p role="alert" className="text-red-600 mt-2">Erro: {(state as any).error}</p>
      )}

      {state && state.ok && (
        <div className="text-green-700 mt-2">
          Conta criada com sucesso! Redirecionando…
          {" "}
          <a className="underline text-blue-700" href={loginUrl}>Fazer login agora</a>
        </div>
      )}
    </form>
  );
}

