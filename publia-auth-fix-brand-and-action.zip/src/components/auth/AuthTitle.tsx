"use client";

import Image from "next/image";
import { ReactNode } from "react";

type Props = {
  title: string;
  subtitle?: string;
  brand?: ReactNode;
  logoSrc?: string;
  className?: string;
};

export default function AuthTitle({
  title,
  subtitle,
  brand,
  logoSrc = "/logos/nexus.png",
  className = "",
}: Props) {
  return (
    <div className={`flex flex-col items-center text-center mb-6 ${className}`}>
      {brand ? (
        <div className="mb-2">{brand}</div>
      ) : logoSrc ? (
        <Image src={logoSrc} alt={title} width={40} height={40} className="mb-2" priority />
      ) : null}
      <h1 className="text-lg font-semibold">{title}</h1>
      {subtitle ? <p className="text-sm text-gray-500">{subtitle}</p> : null}
    </div>
  );
}
