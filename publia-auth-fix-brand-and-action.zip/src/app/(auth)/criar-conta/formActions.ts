"use server";

import { z } from "zod";
import { createAdminClient } from "@/lib/external/supabase";
import { isValidCpfCnpj, onlyDigits } from "@/lib/validators";

const schema = z.object({
  nome: z.string().min(2, "Informe seu nome"),
  cpf_cnpj: z
    .string()
    .refine((v) => (isValidCpfCnpj ? isValidCpfCnpj(v) : v && v.length >= 11), "CPF/CNPJ inválido")
    .transform((v) => (onlyDigits ? onlyDigits(v) : v)),
  email: z.string().email("E-mail inválido"),
  telefone: z.string().min(8, "Telefone inválido"),
  cidade_uf: z.string().min(2, "Cidade/UF inválido"),
  senha: z.string().min(8, "A senha precisa ter 8+ caracteres"),
  tk: z.string().optional(),
});

export async function criarConta(prevState: any, formData: FormData) {
  try {
    const raw = Object.fromEntries(formData.entries());
    const { nome, cpf_cnpj, email, telefone, cidade_uf, senha, tk } = schema.parse(raw);

    const tokenOk = process.env.SIGNUP_TOKEN && tk === process.env.SIGNUP_TOKEN;
    if (!tokenOk) return { ok: false, error: "Cadastro bloqueado.", code: "blocked" };

    const admin = createAdminClient();

    const { data: created, error: createErr } = await admin.auth.admin.createUser({
      email,
      password: senha,
      email_confirm: true,
    });
    if (createErr || !created?.user?.id) {
      return { ok: false, error: "Não foi possível criar o usuário. Tente novamente." };
    }

    const userId = created.user.id;

    const { error: profileErr } = await admin.from("profiles").insert({
      user_id: userId,
      nome,
      cpf_cnpj,
      email,
      telefone,
      cidade_uf,
    });
    if (profileErr) {
      await admin.auth.admin.deleteUser(userId).catch(() => {});
      return { ok: false, error: "Falha ao salvar perfil. Tente novamente." };
    }

    return { ok: true, redirect: process.env.NEXT_PUBLIC_AFTER_SIGNUP_LOGIN || "/login" };
  } catch (e: any) {
    console.error("[signup] error", e);
    return { ok: false, error: "Não foi possível concluir o cadastro agora." };
  }
}
