"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { useFormState } from "react-dom";
import AuthCard from "@/components/auth/AuthCard";
import AuthTitle from "@/components/auth/AuthTitle";
import AuthInput from "@/components/auth/AuthInput";
import SubmitButton from "@/components/auth/SubmitButton";
import Alert from "@/components/auth/Alert";
import Brand from "@/app/components/brand";
import { criarConta } from "./formActions";

export default function CriarContaPage() {
  const sp = useSearchParams();
  const tk = sp.get("tk") || "";
  const [state, action] = useFormState(criarConta as any, { ok: false } as any);

  return (
    <AuthCard>
      <AuthTitle brand={<Brand />} title="Publ.IA – Nexus Pública" subtitle="Crie sua conta para acessar o painel." />
      {state?.error && <Alert type="error">{state.error}</Alert>}
      {state?.ok && state?.redirect && <Alert type="success">Conta criada! Redirecionando…</Alert>}
      <form action={action} className="space-y-4">
        <input type="hidden" name="tk" value={tk} />
        <AuthInput label="CPF/CNPJ" name="cpf_cnpj" inputMode="numeric" placeholder="Digite seu CPF ou CNPJ" required />
        <AuthInput label="Nome / Razão Social" name="nome" placeholder="Seu nome completo" required />
        <AuthInput label="E-mail" name="email" type="email" placeholder="seuemail@exemplo.com" required />
        <AuthInput label="Telefone (WhatsApp)" name="telefone" inputMode="tel" placeholder="(00) 00000-0000" required />
        <AuthInput label="Cidade/UF" name="cidade_uf" placeholder="Sua cidade/UF" required />
        <AuthInput label="Senha (mínimo 8)" name="senha" type="password" placeholder="Crie uma senha" minLength={8} required />
        <SubmitButton label="Criar conta" loadingLabel="Criando conta..." />
      </form>
      <div className="mt-4 text-center text-sm">
        <span className="text-gray-500">Já tem conta? </span>
        <Link href="/login" className="text-blue-600 hover:underline">Entrar</Link>
      </div>
    </AuthCard>
  );
}
