"use client";

import Link from "next/link";
import { useFormState } from "react-dom";
import AuthCard from "@/components/auth/AuthCard";
import AuthTitle from "@/components/auth/AuthTitle";
import AuthInput from "@/components/auth/AuthInput";
import SubmitButton from "@/components/auth/SubmitButton";
import Alert from "@/components/auth/Alert";
import Brand from "@/app/components/brand";
import { resetSenha } from "./resetActions"; // ajuste se necessário

export default function RecuperarSenhaPage() {
  const [state, action] = useFormState(resetSenha as any, { ok: false } as any);

  return (
    <AuthCard>
      <AuthTitle brand={<Brand />} title="Publ.IA – Nexus Pública" subtitle="Recupere o acesso informando seu CPF/CNPJ." />
      {state?.error && <Alert type="error">{state.error}</Alert>}
      {state?.ok && <Alert type="success">Seus dados foram enviados. Verifique o e-mail.</Alert>}
      <form action={action} className="space-y-4">
        <AuthInput label="CPF/CNPJ" name="cpf_cnpj" inputMode="numeric" placeholder="Digite seu CPF ou CNPJ" required />
        <SubmitButton label="Enviar" loadingLabel="Enviando..." />
      </form>
      <div className="mt-4 text-center text-sm">
        <Link href="/login" className="text-blue-600 hover:underline">Voltar ao login</Link>
      </div>
    </AuthCard>
  );
}
