// src/app/(debug)/debug-public/page.tsx
'use client';

function hostFromUrl(url?: string | null) {
  try {
    if (!url) return '';
    const u = new URL(url);
    return u.host;
  } catch {
    return '';
  }
}

export default function DebugPublic() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  const urlHost = hostFromUrl(url || '');
  const keyLen = anon ? anon.length : 0;
  const keyHead = anon ? anon.slice(0, 10) : '';

  return (
    <div style={{ padding: 24, fontFamily: 'ui-sans-serif, system-ui' }}>
      <h1>Debug de Variáveis Públicas</h1>
      <p>Use isto só para testes e remova depois.</p>
      <pre style={{ background: '#111', color: '#0f0', padding: 16, borderRadius: 8 }}>
{`{
  "urlHost": "${urlHost || ''}",
  "keyLen": ${keyLen},
  "keyHead": "${keyHead}"
}`}
      </pre>
      <p><strong>Esperado:</strong> urlHost = seu domínio .supabase.co e keyLen &gt; 0.</p>
    </div>
  );
}
