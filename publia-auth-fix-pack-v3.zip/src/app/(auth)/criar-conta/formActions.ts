// src/app/(auth)/criar-conta/formActions.ts
'use server';

import { redirect } from 'next/navigation';
import { supabaseAdmin } from '@/lib/supabase';

const SIGNUP_TOKEN = process.env.SIGNUP_TOKEN;
const REDIRECT_BLOCKED = process.env.REDIRECT_BLOCKED_SIGNUP || '/';

type FormState = {
  ok: boolean;
  message: string;
  details?: any;
};

export async function signUpAction(_: FormState | undefined, formData: FormData): Promise<FormState> {
  try {
    // 1) Checa token de convite
    const tk = formData.get('tk')?.toString() || '';
    if (!SIGNUP_TOKEN) {
      return { ok: false, message: 'Config ausente: SIGNUP_TOKEN não definido no servidor.' };
    }
    if (tk !== SIGNUP_TOKEN) {
      // Não faz redirect aqui para não quebrar SPA; retorna erro para a UI lidar.
      return { ok: false, message: 'Token inválido. Acesso negado.' };
    }

    // 2) Captura os campos na ORDEM informada
    const cpf_cnpj = (formData.get('cpf_cnpj') || '').toString().trim();
    const nome = (formData.get('nome') || '').toString().trim();
    const email = (formData.get('email') || '').toString().trim();
    const telefone = (formData.get('telefone') || '').toString().trim();
    const cidade_uf = (formData.get('cidade_uf') || '').toString().trim();
    const senha = (formData.get('senha') || '').toString();

    if (!email || !senha || !nome) {
      return { ok: false, message: 'Informe ao menos nome, email e senha.' };
    }

    // 3) Usa ADMIN (SERVICE ROLE) para criar o usuário no auth
    const admin = supabaseAdmin();
    const { data: created, error: createErr } = await admin.auth.admin.createUser({
      email,
      password: senha,
      email_confirm: true,
      user_metadata: { nome, cpf_cnpj, telefone, cidade_uf },
    });

    if (createErr) {
      return { ok: false, message: 'Falha ao criar usuário no Auth.', details: createErr.message };
    }
    const userId = created.user?.id;
    if (!userId) {
      return { ok: false, message: 'Usuário criado, mas ID ausente.' };
    }

    // 4) Insere o perfil
    const { error: insErr } = await admin
      .from('profiles')
      .insert({
        user_id: userId,
        cpf_cnpj,
        nome,
        email,
        telefone,
        cidade_uf,
      });

    if (insErr) {
      return { ok: false, message: 'Conta criada, mas falha ao salvar perfil.', details: insErr.message };
    }

    return { ok: true, message: 'Conta criada com sucesso!' };
  } catch (e: any) {
    // Trate erros de DNS / ENOTFOUND e mostre dica
    const msg = (e?.message || '').toString();
    if (msg.includes('ENOTFOUND') || msg.includes('getaddrinfo')) {
      return { ok: false, message: 'Falha de rede/DNS ao contatar o Supabase (verifique NEXT_PUBLIC_SUPABASE_URL).', details: msg };
    }
    return { ok: false, message: 'Erro inesperado na criação de conta.', details: msg };
  }
}
