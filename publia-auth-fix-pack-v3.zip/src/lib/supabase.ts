// src/lib/supabase.ts
import 'server-only';
import { cookies, headers } from 'next/headers';
import { createServerClient, type CookieOptions } from '@supabase/ssr';
import { createClient as createSupabaseClient } from '@supabase/supabase-js';

// Variáveis obrigatórias
const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL;
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

function assertEnv() {
  if (!SUPABASE_URL || !SUPABASE_URL.includes('.supabase.co')) {
    throw new Error('Env inválido: NEXT_PUBLIC_SUPABASE_URL ausente ou inválido.');
  }
  if (!SUPABASE_ANON_KEY || !SUPABASE_ANON_KEY.startsWith('ey')) {
    throw new Error('Env inválido: NEXT_PUBLIC_SUPABASE_ANON_KEY ausente ou inválido.');
  }
}

assertEnv();

/**
 * Cliente para browser (ANON), usado quando precisa renderizar algo com sessão no cliente.
 * Em server components/server actions, prefira supabaseAdmin ou supabaseServer.
 */
export function supabaseBrowser() {
  // Este cliente NÃO deve ser usado com SERVICE ROLE
  return createSupabaseClient(SUPABASE_URL!, SUPABASE_ANON_KEY!, {
    auth: { persistSession: true, autoRefreshToken: true },
  });
}

/**
 * Cliente para server components/actions com cookies compartilhados.
 */
export function supabaseServer() {
  const cookieStore = cookies();
  return createServerClient(
    SUPABASE_URL!,
    SUPABASE_ANON_KEY!,
    {
      cookies: {
        get(name: string) {
          return cookieStore.get(name)?.value;
        },
        set(name: string, value: string, options: CookieOptions) {
          cookieStore.set({ name, value, ...options });
        },
        remove(name: string, options: CookieOptions) {
          cookieStore.set({ name, value: '', ...options, maxAge: 0 });
        },
      },
    }
  );
}

/**
 * Cliente ADMIN (SERVICE ROLE). **Somente no servidor**.
 * Use para criar usuário via GoTrueAdmin e inserções privilegiadas.
 */
export function supabaseAdmin() {
  if (typeof window !== 'undefined') {
    throw new Error('supabaseAdmin não pode ser usado no browser.');
  }
  if (!SUPABASE_SERVICE_ROLE_KEY || !SUPABASE_SERVICE_ROLE_KEY.startsWith('ey')) {
    throw new Error('Env inválido: SUPABASE_SERVICE_ROLE_KEY ausente ou inválido.');
  }
  return createSupabaseClient(SUPABASE_URL!, SUPABASE_SERVICE_ROLE_KEY!, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}
