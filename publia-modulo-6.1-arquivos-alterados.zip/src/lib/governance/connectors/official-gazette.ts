export type DiscoveredOfficialEdition = {
  title: string;
  pdfUrl: string;
  editionNumber: string | null;
  publicationDate: string | null;
};

export interface OfficialSourceConnector {
  discover(sourceUrl: string): Promise<DiscoveredOfficialEdition[]>;
}

function decodeHtml(value: string) {
  return value
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/&nbsp;/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function normalizeDate(value: string | null) {
  if (!value) return null;

  const isoMatch = value.match(/\b(20\d{2})[-/](\d{2})[-/](\d{2})\b/);
  if (isoMatch) return `${isoMatch[1]}-${isoMatch[2]}-${isoMatch[3]}`;

  const brMatch = value.match(/\b(\d{1,2})[/.](\d{1,2})[/.](20\d{2})\b/);
  if (!brMatch) return null;

  return `${brMatch[3]}-${brMatch[2].padStart(2, "0")}-${brMatch[1].padStart(2, "0")}`;
}

function extractEditionNumber(value: string) {
  const patterns = [
    /edi(?:ç|c)[ãa]o\s*(?:n[º°o.]?\s*)?([0-9][0-9./-]*)/i,
    /(?:n[º°o.]?\s*)([0-9][0-9./-]*)/i,
  ];

  for (const pattern of patterns) {
    const match = value.match(pattern);
    if (match?.[1]) return match[1].trim();
  }

  return null;
}

function buildTitle(label: string, editionNumber: string | null) {
  if (editionNumber) return `Diário Oficial nº ${editionNumber}`;
  return label || "Diário Oficial";
}

export class HtmlOfficialGazetteConnector implements OfficialSourceConnector {
  async discover(sourceUrl: string): Promise<DiscoveredOfficialEdition[]> {
    const normalizedSourceUrl = new URL(sourceUrl).toString();

    if (/\.pdf(?:$|[?#])/i.test(normalizedSourceUrl)) {
      return [{
        title: "Diário Oficial",
        pdfUrl: normalizedSourceUrl,
        editionNumber: extractEditionNumber(normalizedSourceUrl),
        publicationDate: normalizeDate(normalizedSourceUrl),
      }];
    }

    const response = await fetch(normalizedSourceUrl, {
      cache: "no-store",
      headers: {
        "User-Agent": "Publ.IA/6.1 (+sincronizacao-diario-oficial)",
        Accept: "text/html,application/xhtml+xml",
      },
    });

    if (!response.ok) {
      throw new Error(`Portal oficial respondeu com status ${response.status}.`);
    }

    const html = await response.text();
    const editions = new Map<string, DiscoveredOfficialEdition>();
    const anchorPattern = /<a\b[^>]*href\s*=\s*(["'])(.*?)\1[^>]*>([\s\S]*?)<\/a>/gi;

    for (const match of html.matchAll(anchorPattern)) {
      const href = decodeHtml(match[2] ?? "");
      if (!href || !/\.pdf(?:$|[?#])/i.test(href)) continue;

      const pdfUrl = new URL(href, normalizedSourceUrl).toString();
      const label = decodeHtml(match[3] ?? "");
      const contextStart = Math.max(0, (match.index ?? 0) - 240);
      const contextEnd = Math.min(html.length, (match.index ?? 0) + match[0].length + 240);
      const context = decodeHtml(html.slice(contextStart, contextEnd));
      const metadataText = `${label} ${context} ${pdfUrl}`;
      const editionNumber = extractEditionNumber(metadataText);
      const publicationDate = normalizeDate(metadataText);

      editions.set(pdfUrl, {
        title: buildTitle(label, editionNumber),
        pdfUrl,
        editionNumber,
        publicationDate,
      });
    }

    return [...editions.values()];
  }
}
