"use client";

import Link from "next/link";
import { useFormState } from "react-dom";
import AuthCard from "@/components/auth/AuthCard";
import AuthTitle from "@/components/auth/AuthTitle";
import AuthInput from "@/components/auth/AuthInput";
import SubmitButton from "@/components/auth/SubmitButton";
import Alert from "@/components/auth/Alert";
import { login } from "./loginActions"; // ajuste se o export tiver outro nome

export default function LoginPage() {
  const [state, action] = useFormState(login as any, { ok: false } as any);

  return (
    <AuthCard>
      <AuthTitle title="Publ.IA – Nexus Pública" subtitle="Faça login para acessar o painel." />
      {state?.error && <Alert type="error">{state.error}</Alert>}
      <form action={action} className="space-y-4">
        <AuthInput label="CPF/CNPJ" name="cpf_cnpj" inputMode="numeric" placeholder="Digite seu CPF ou CNPJ" required />
        <AuthInput label="Senha" name="senha" type="password" placeholder="Sua senha" required />
        <SubmitButton label="Entrar" loadingLabel="Entrando..." />
      </form>
      <div className="mt-4 text-center text-sm">
        <Link href="/recuperar-senha" className="text-blue-600 hover:underline">Esqueceu a senha?</Link>
      </div>
      <div className="mt-2 text-center text-sm">
        <Link href="/criar-conta" className="text-blue-600 hover:underline">Criar uma conta</Link>
      </div>
    </AuthCard>
  );
}
