"use client";

import Image from "next/image";

export default function AuthTitle({
  title,
  subtitle,
  logoSrc = "/logos/nexus.png",
  className = "",
}: {
  title: string;
  subtitle?: string;
  logoSrc?: string;
  className?: string;
}) {
  return (
    <div className={`flex flex-col items-center text-center mb-6 ${className}`}>
      {logoSrc ? <Image src={logoSrc} alt={title} width={40} height={40} className="mb-2" priority /> : null}
      <h1 className="text-lg font-semibold">{title}</h1>
      {subtitle ? <p className="text-sm text-gray-500">{subtitle}</p> : null}
    </div>
  );
}
