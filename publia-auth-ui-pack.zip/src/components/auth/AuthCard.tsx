"use client";

import { ReactNode } from "react";

/** Centraliza a página e aplica o card padrão (igual ao login). */
export default function AuthCard({ children, className = "" }: { children: ReactNode; className?: string }) {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-gray-50 px-4">
      <div className="w-full max-w-md">
        <div className={`bg-white border border-gray-200 shadow-sm rounded-2xl p-8 ${className}`}>
          {children}
        </div>
      </div>
    </div>
  );
}
