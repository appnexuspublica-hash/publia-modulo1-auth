
import { Brand } from "@/components/brand";
import PasswordInput from "@/components/password-input";
import { actionSignUp } from "../actions";
import { redirect } from "next/navigation";

export const dynamic = "force-dynamic";

export default async function Page({ searchParams }: { searchParams: { [k: string]: string | string[] | undefined } }) {
  const tk = searchParams?.tk;
  const required = process.env.SIGNUP_TOKEN;
  const redirectUrl = process.env.REDIRECT_BLOCKED_SIGNUP || "https://nexuspublica.com.br/";
  if (!tk || tk !== required) {
    redirect(redirectUrl);
  }

  return (
    <div className="container-narrow">
      <div className="card p-8">
        <Brand subtitle="Preencha seus dados para solicitar acesso." />
        <form className="space-y-4" action={async (formData) => {
          "use server";
          const cpfcnpj = String(formData.get("cpfcnpj") || "");
          const nome = String(formData.get("nome") || "");
          const email = String(formData.get("email") || "");
          const telefone = String(formData.get("telefone") || "");
          const cidadeUf = String(formData.get("cidadeUf") || "");
          const senha = String(formData.get("senha") || "");
          const res = await actionSignUp({ cpfcnpj, nome, email, telefone, cidadeUf, senha });
          if (!res.ok) return { error: res.error };
          return { ok: true };
        }}>
          <div>
            <label className="label">CPF/CNPJ</label>
            <input name="cpfcnpj" className="input" placeholder="Somente números" required />
          </div>
          <div>
            <label className="label">Nome / Razão Social</label>
            <input name="nome" className="input" required />
          </div>
          <div>
            <label className="label">E-mail</label>
            <input name="email" type="email" className="input" required />
          </div>
          <div>
            <label className="label">Telefone (WhatsApp)</label>
            <input name="telefone" className="input" />
          </div>
          <div>
            <label className="label">Cidade/UF</label>
            <input name="cidadeUf" className="input" />
          </div>
          <div>
            <label className="label">Senha (Mínimo 6 caracteres)</label>
            <PasswordInput name="senha" minLength={6} required />
          </div>
          <button className="btn w-full" type="submit">CRIAR CONTA</button>
        </form>
        <div className="mt-6 text-center">
          <a className="link" href="/login">Ir para o login</a>
        </div>
      </div>
    </div>
  );
}
