
import { Brand } from "@/components/brand";
import PasswordInput from "@/components/password-input";
import { actionResetPassword } from "../actions";

export default function Page() {
  return (
    <div className="container-narrow">
      <div className="card p-8">
        <Brand subtitle="Informe seu CPF/CNPJ e a nova SENHA" />
        <form className="space-y-4" action={async (formData) => {
          "use server";
          const cpfcnpj = String(formData.get("cpfcnpj") || "");
          const senha = String(formData.get("senha") || "");
          const senha2 = String(formData.get("senha2") || "");
          if (senha !== senha2) return { error: "As senhas não conferem." };
          const res = await actionResetPassword(cpfcnpj, senha);
          if (!res.ok) return { error: res.error };
          return { ok: true };
        }}>
          <div>
            <label className="label">CPF/CNPJ</label>
            <input name="cpfcnpj" className="input" required />
          </div>
          <div>
            <label className="label">Nova senha (mínimo 6 caracteres)</label>
            <PasswordInput name="senha" minLength={6} required />
          </div>
          <div>
            <label className="label">Confirmar nova senha</label>
            <PasswordInput name="senha2" minLength={6} required />
          </div>
          <div className="flex items-center justify-between">
            <button className="btn" type="submit">ATUALIZAR SENHA</button>
            <a className="link" href="/login">Voltar para LOGIN</a>
          </div>
        </form>
      </div>
    </div>
  );
}
