
import { Brand } from "@/components/brand";
import PasswordInput from "@/components/password-input";
import { actionLoginCpfCnpj } from "../actions";
import { redirect } from "next/navigation";

export default function Page() {
  return (
    <div className="container-narrow">
      <div className="card p-8">
        <Brand subtitle="Informe seu CPF/CNPJ e SENHA para acessar" />
        <form className="space-y-4" action={async (formData) => {
          "use server";
          const cpfcnpj = String(formData.get("cpfcnpj") || "");
          const senha = String(formData.get("senha") || "");
          const res = await actionLoginCpfCnpj(cpfcnpj, senha);
          if (!res.ok) return { error: res.error };
          redirect("http://localhost:3000/chat");
        }}>
          <div>
            <label className="label">CPF/CNPJ</label>
            <input name="cpfcnpj" className="input" required />
          </div>
          <div>
            <label className="label">Senha (Mínimo 6 caracteres)</label>
            <PasswordInput name="senha" minLength={6} required />
          </div>
          <div className="flex items-center justify-between">
            <button className="btn" type="submit">ENTRAR</button>
            <a className="link" href="/recuperar-senha">Esqueceu a senha?</a>
          </div>
        </form>
      </div>
    </div>
  );
}
