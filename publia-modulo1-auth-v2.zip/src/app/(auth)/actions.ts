
"use server";

import { supabaseAdmin, supabaseClient } from "@/lib/supabase";
import { isValidCpfCnpj, onlyDigits } from "@/lib/validators";

type SignUpPayload = {
  cpfcnpj: string;
  nome: string;
  email: string;
  telefone?: string;
  cidadeUf?: string;
  senha: string;
};

export async function actionSignUp(data: SignUpPayload) {
  if (!isValidCpfCnpj(data.cpfcnpj)) {
    return { ok: false, error: "CPF/CNPJ inválido." };
  }
  const cpf = onlyDigits(data.cpfcnpj);

  const admin = supabaseAdmin();

  // Verifica duplicidade
  const dup = await admin.from("profiles").select("id").eq("cpf_cnpj", cpf).maybeSingle();
  if (dup.data) return { ok: false, error: "CPF/CNPJ já cadastrado." };

  // Cria usuário no Auth
  const created = await admin.auth.admin.createUser({
    email: data.email,
    password: data.senha,
    email_confirm: true,
    user_metadata: { cpf_cnpj: cpf, nome_razao: data.nome }
  });
  if (created.error || !created.data.user) {
    return { ok: false, error: "Erro ao criar usuário." };
  }

  const user = created.data.user;

  // Insere profile (service role)
  const ins = await admin.from("profiles").insert({
    user_id: user.id,
    cpf_cnpj: cpf,
    nome_razao: data.nome,
    email: data.email,
    telefone: data.telefone || null,
    cidade_uf: data.cidadeUf || null
  }).select("id").single();

  if (ins.error) {
    // rollback do usuário auth em caso de falha
    await admin.auth.admin.deleteUser(user.id);
    return { ok: false, error: "Erro ao salvar perfil." };
  }

  return { ok: true };
}

export async function actionLoginCpfCnpj(cpfcnpj: string, senha: string) {
  if (!isValidCpfCnpj(cpfcnpj)) return { ok: false, error: "CPF/CNPJ inválido." };
  const cpf = onlyDigits(cpfcnpj);
  const anon = supabaseClient();

  // Busca e-mail pelo cpf
  const q = await anon.from("vw_profiles_lookup").select("email").eq("cpf_cnpj", cpf).maybeSingle();
  if (q.error || !q.data) return { ok: false, error: "Usuário não encontrado." };
  const email = q.data.email;

  const { data, error } = await anon.auth.signInWithPassword({ email, password: senha });
  if (error || !data.session) return { ok: false, error: "Senha incorreta." };

  return { ok: true };
}

export async function actionResetPassword(cpfcnpj: string, novaSenha: string) {
  if (!isValidCpfCnpj(cpfcnpj)) return { ok: false, error: "CPF/CNPJ inválido." };
  const cpf = onlyDigits(cpfcnpj);
  const admin = supabaseAdmin();

  // buscar user_id por cpf
  const q = await admin.from("profiles").select("user_id").eq("cpf_cnpj", cpf).maybeSingle();
  if (q.error || !q.data) return { ok: false, error: "Usuário não encontrado." };

  const upd = await admin.auth.admin.updateUserById(q.data.user_id, { password: novaSenha });
  if (upd.error) return { ok: false, error: "Erro ao atualizar senha." };

  return { ok: true };
}
