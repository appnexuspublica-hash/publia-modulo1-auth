
import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Publ.IA — Módulo 1 (Auth)",
  description: "Autenticação com CPF/CNPJ + Supabase",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body>
        <main className="min-h-screen flex items-center justify-center p-6">
          {children}
        </main>
      </body>
    </html>
  );
}
