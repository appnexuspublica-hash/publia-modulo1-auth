
export function onlyDigits(v: string) { return (v || "").replace(/\D+/g, ""); }

export function isValidCPF(cpfRaw: string): boolean {
  const cpf = onlyDigits(cpfRaw);
  if (!cpf || cpf.length !== 11) return false;
  if (/^(\d)\1{10}$/.test(cpf)) return false;
  let sum = 0; let rest = 0;
  for (let i = 1; i <= 9; i++) sum += parseInt(cpf.substring(i-1, i)) * (11 - i);
  rest = (sum * 10) % 11; if (rest === 10 || rest === 11) rest = 0;
  if (rest !== parseInt(cpf.substring(9, 10))) return false;
  sum = 0;
  for (let i = 1; i <= 10; i++) sum += parseInt(cpf.substring(i-1, i)) * (12 - i);
  rest = (sum * 10) % 11; if (rest === 10 || rest === 11) rest = 0;
  return rest === parseInt(cpf.substring(10, 11));
}

export function isValidCNPJ(cnpjRaw: string): boolean {
  const cnpj = onlyDigits(cnpjRaw);
  if (!cnpj || cnpj.length !== 14) return false;
  if (/^(\d)\1{13}$/.test(cnpj)) return false;
  const calc = (base: string, factors: number[]) =>
    factors.reduce((acc, f, i) => acc + parseInt(base[i]) * f, 0);
  let base = cnpj.slice(0, 12);
  let d1 = 11 - (calc(base, [5,4,3,2,9,8,7,6,5,4,3,2]) % 11); d1 = d1 >= 10 ? 0 : d1;
  base += d1.toString();
  let d2 = 11 - (calc(base, [6,5,4,3,2,9,8,7,6,5,4,3,2]) % 11); d2 = d2 >= 10 ? 0 : d2;
  return cnpj === base + d2.toString();
}

export function isValidCpfCnpj(v: string): boolean {
  const d = onlyDigits(v);
  if (d.length === 11) return isValidCPF(d);
  if (d.length === 14) return isValidCNPJ(d);
  return false;
}
