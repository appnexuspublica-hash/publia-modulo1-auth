
import { createClient } from "@supabase/supabase-js";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseAnon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;
const supabaseService = process.env.SUPABASE_SERVICE_ROLE_KEY!;

// Cliente público (anon) – para código de servidor comum
export function supabaseClient() {
  return createClient(supabaseUrl, supabaseAnon, { auth: { persistSession: false } });
}

// Cliente admin (service role) – use APENAS em código de servidor
export function supabaseAdmin() {
  return createClient(supabaseUrl, supabaseService, { auth: { persistSession: false } });
}
