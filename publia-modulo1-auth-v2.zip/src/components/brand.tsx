
export function Brand({ subtitle }: { subtitle?: string }) {
  return (
    <div className="header-brand">
      <img className="brand-logo" src="https://nexuspublica.com.br/wp-content/uploads/2025/09/icon_nexus.png" alt="Nexus Pública" />
      <span className="brand-title">Publ.IA - Nexus Pública</span>
      {subtitle ? <p className="helper mt-1">{subtitle}</p> : null}
    </div>
  );
}
