
# Publ.IA — Módulo 1 (Auth) — v2

Fluxos: Criar conta (com token), Login por CPF/CNPJ, Recuperar senha por CPF/CNPJ.
Stack: Next.js (App Router, TS, Tailwind) + Supabase (Auth, Postgres, RLS).

## Como descompactar o ZIP (Windows/macOS/Linux)
- **Windows PowerShell**: `Expand-Archive -Path .\publia-modulo1-auth-v2.zip -DestinationPath .\publia-modulo1-auth-v2`
- **Windows CMD**: `tar -xf publia-modulo1-auth-v2.zip`
- **macOS/Linux**: `unzip publia-modulo1-auth-v2.zip`
Para apagar `.next` no PowerShell: `Remove-Item .next -Recurse -Force`

## Instalação
```bash
cp .env.example .env         # no Windows: copy .env.example .env
# Preencha variáveis em .env
npm install
npm run dev
```

Acesse:
- Criar conta:  `http://localhost:3000/criar-conta?tk=SEU_TOKEN`
- Login:        `http://localhost:3000/login`
- Recuperar:    `http://localhost:3000/recuperar-senha`

## Supabase — execute este SQL
Abra **SQL Editor** e cole o conteúdo de `supabase/sql/001_schema_profiles_rls.sql`, depois **Run**.

Observações:
- Login usa CPF/CNPJ para achar o e-mail e autenticar com `email+senha`.
- Service Role Key é usada apenas no servidor para criar usuário e reset de senha.
