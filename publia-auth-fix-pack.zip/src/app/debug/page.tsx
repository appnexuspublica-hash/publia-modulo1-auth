// src/app/debug/page.tsx
"use client";
export default function DebugEnvPage() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL || "";
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "";
  let host = "INVALID_URL";
  try { host = new URL(url).host; } catch {}
  const data = { urlHost: host, keyLen: key.length, keyHead: key.slice(0, 12) };
  return (
    <main style={{padding:20,fontFamily:"ui-sans-serif, system-ui"}}>
      <h1>Debug de Variáveis Públicas</h1>
      <p>Use isto só para testes e remova depois.</p>
      <pre>{JSON.stringify(data, null, 2)}</pre>
      <p>Esperado: <code>urlHost</code> = seu domínio .supabase.co e <code>keyLen &gt; 0</code>.</p>
    </main>
  );
}
