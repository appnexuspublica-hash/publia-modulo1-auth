// src/lib/supabase-server.ts
import { createClient } from "@supabase/supabase-js";
import "server-only";
const url = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const service = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!service) {
  console.error("[supabase-server] SUPABASE_SERVICE_ROLE_KEY ausente no ambiente do servidor.");
}
export const supabaseServer = () => {
  if (!service) throw new Error("SUPABASE_SERVICE_ROLE_KEY ausente no servidor");
  return createClient(url, service, { auth: { persistSession: false } });
};
