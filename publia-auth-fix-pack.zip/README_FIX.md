# Publia Auth Fix Pack
Conteúdo:
- `src/lib/supabase-browser.ts` → client do Supabase para o **browser** (usa ANON)
- `src/lib/supabase-server.ts`  → client do Supabase para o **servidor** (usa SERVICE ROLE)
- `src/app/debug/page.tsx`      → página de **debug** para conferir as variáveis públicas
- `scripts/find-supabase-imports.ps1` → localiza imports antigos
- `scripts/clean-and-run.ps1`          → limpa `.next` e sobe o dev server

## Passos
1) Feche `npm run dev`. Faça backup da pasta do projeto.
2) Extraia este ZIP **na raiz do projeto** mantendo as pastas.
3) Confirme `.env.local` com as 3 variáveis:
   NEXT_PUBLIC_SUPABASE_URL, NEXT_PUBLIC_SUPABASE_ANON_KEY, SUPABASE_SERVICE_ROLE_KEY
4) Ajuste imports:
   - Em código **client** → `@/lib/supabase-browser`
   - Em código **server** → `@/lib/supabase-server`
   Rode: `./scripts/find-supabase-imports.ps1`
5) Rode `./scripts/clean-and-run.ps1`
6) Abra `http://localhost:3000/debug` e confirme url/key.
7) Teste criar conta novamente.
8) Após validar, remova a rota `/debug`.

Dica: Para eliminar o warning do Next, adicione `"type": "module"` no package.json
ou renomeie `next.config.js` para `next.config.mjs`.
