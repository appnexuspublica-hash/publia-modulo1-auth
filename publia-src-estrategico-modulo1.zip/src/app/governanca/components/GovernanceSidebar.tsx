// src/app/governanca/components/GovernanceSidebar.tsx
"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  BarChart3,
  BookOpen,
  Building2,
  FileSearch,
  FileText,
  Landmark,
  MessageSquare,
  Settings,
  ShieldCheck,
  Users,
} from "lucide-react";

type GovernanceSidebarProps = {
  organizationName: string;
  organizationLogoUrl?: string | null;
  functionalRoleLabel: string;
  technicalRoleLabel: string;
};

const navigationItems = [
  {
    label: "Visão geral",
    icon: Landmark,
    href: "/governanca",
    enabled: true,
  },
  {
    label: "Chat Governança",
    icon: MessageSquare,
    href: "/governanca/chat",
    enabled: true,
    alsoActiveWhen: ["/governanca/conversas"],
  },
  {
    label: "Usuários",
    icon: Users,
    href: "/governanca/usuarios",
    enabled: true,
  },
  {
    label: "Documentos institucionais",
    icon: BookOpen,
    href: "/governanca/base-institucional",
    enabled: true,
  },
  {
    label: "Fontes oficiais",
    icon: FileSearch,
    href: "/governanca/fontes-oficiais",
    enabled: true,
  },
  {
    label: "Diário Oficial",
    icon: FileText,
    href: "/governanca/diario-oficial",
    enabled: true,
  },
  {
    label: "Auditoria",
    icon: ShieldCheck,
    href: "/governanca/auditoria",
    enabled: true,
  },
  {
    label: "Indicadores",
    icon: BarChart3,
    href: "/governanca/indicadores",
    enabled: true,
  },
  {
    label: "Configurações",
    icon: Settings,
    href: "/governanca/configuracoes",
    enabled: true,
  },
];

export default function GovernanceSidebar({
  organizationName,
  organizationLogoUrl,
  functionalRoleLabel,
}: GovernanceSidebarProps) {
  const pathname = usePathname();

  return (
    <aside className="hidden w-80 shrink-0 border-r border-[#dedede] bg-[#e6e6e6] p-5 lg:flex lg:flex-col">
      <div className="rounded-3xl border border-[#dedede] bg-white p-5 shadow-sm">
        <p className="text-xs font-semibold uppercase tracking-wide text-[#0f3a4a]">
          Órgão
        </p>

        <div className="mt-3 flex items-start gap-3">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center overflow-hidden rounded-2xl border border-[#dedede] bg-[#f8f8f8] text-[#0f3a4a]">
            {organizationLogoUrl ? (
              <img
                src={organizationLogoUrl}
                alt={`Logo de ${organizationName}`}
                className="h-full w-full object-contain p-1"
              />
            ) : (
              <Building2 size={24} />
            )}
          </div>

          <h2 className="line-clamp-3 min-w-0 text-base font-bold text-slate-950">
            {organizationName}
          </h2>
        </div>

        <div className="mt-4 space-y-2 text-xs">
          <div className="rounded-2xl bg-[#e6e6e6] p-3 text-[#0f3a4a]">
            <span className="block font-semibold">Papel funcional</span>
            <span>{functionalRoleLabel}</span>
          </div>

        </div>
      </div>

      <nav className="mt-5 space-y-2">
        {navigationItems.map((item) => {
          const Icon = item.icon;
          const isActive =
            pathname === item.href ||
            (item.href !== "/governanca" && pathname.startsWith(item.href)) ||
            Boolean(
              item.alsoActiveWhen?.some((activePath) =>
                pathname.startsWith(activePath),
              ),
            );

          if (!item.enabled) {
            return (
              <button
                key={item.label}
                type="button"
                disabled
                className="flex w-full cursor-not-allowed items-center gap-3 rounded-2xl px-4 py-3 text-left text-sm font-semibold text-slate-600 opacity-60 transition"
              >
                <Icon size={18} />
                {item.label}
              </button>
            );
          }

          return (
            <Link
              key={item.label}
              href={item.href}
              className={[
                "flex w-full items-center gap-3 rounded-2xl px-4 py-3 text-left text-sm font-semibold transition",
                isActive
                  ? "bg-[#0f3a4a] text-white shadow-sm"
                  : "text-slate-700 hover:bg-white hover:text-[#0f3a4a]",
              ].join(" ")}
            >
              <Icon size={18} />
              {item.label}
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
