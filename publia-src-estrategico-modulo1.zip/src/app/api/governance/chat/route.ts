// src/app/api/governance/chat/route.ts
/**
 * CHAT GOVERNANÇA
 *
 * Usado somente pelo produto:
 * - Publ.IA Governança
 *
 * IMPORTANTE:
 * Esta rota EXIGE organização ativa.
 *
 * Banco usado:
 * - governance_conversations
 * - governance_messages
 *
 * Chave de isolamento:
 * - organization_id
 */
import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { createServerClient } from "@supabase/ssr";
import { createClient as createSupabaseClient } from "@supabase/supabase-js";
import OpenAI from "openai";

import { getCurrentGovernanceOrganization } from "@/lib/governance/get-current-organization";
import { buildGovernancePrompt } from "@/lib/prompts/governance/prompt";
import { buildGovernanceKnowledgeContext } from "@/lib/governance/knowledge-engine";
import { analyzeGovernanceQuery } from "@/lib/governance/knowledge-engine/analyzer";
import { buildGovernanceFinalAnswer } from "@/lib/governance/knowledge-engine/response-builder";
import { filterGovernanceSourcesForResponse } from "@/lib/governance/knowledge-engine/source-filter";
import { buildGovernanceLegalGuardrails, findGovernanceCriticalKnowledge } from "@/lib/governanceLegalGuardrails";
import { shouldForceWebFirst } from "@/lib/webFirstDetector";
import { chunkText, pickRelevantChunks } from "@/lib/pdf/chunking";
import type {
  GovernanceMessage,
  GovernanceResponseMode,
} from "@/types/governance";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const openaiApiKey = process.env.OPENAI_API_KEY;

const OPENAI_MODEL_GOVERNANCE =
  process.env.OPENAI_MODEL_GOVERNANCE ||
  process.env.OPENAI_MODEL_NO_PDF ||
  "gpt-5.1";

const EMBEDDING_MODEL =
  process.env.OPENAI_EMBEDDING_MODEL || "text-embedding-3-small";

const RAG_TOP_K = Math.max(2, Math.min(10, Number(process.env.RAG_TOP_K ?? 4)));

const MAX_USER_MESSAGE_LENGTH = 12000;
const MAX_HISTORY_MESSAGES = 6;
const MAX_GOVERNANCE_PDF_CONTEXT_CHARS = 9000;
const MAX_SELECTED_PDFS_IN_GOVERNANCE_CHAT = 5;

const MAX_OFFICIAL_GAZETTE_CONTEXT_CHARS = 9000;
const MAX_OFFICIAL_GAZETTE_CHUNKS = 250;
const MAX_OFFICIAL_GAZETTE_SELECTED_CHUNKS = 80;
const MAX_OFFICIAL_GAZETTE_COMPLETE_LIST_CONTEXT_CHARS = 30000;

const MAX_INSTITUTIONAL_CONTEXT_CHARS = 24000;
const MAX_INSTITUTIONAL_DOCUMENTS = 30;
const MAX_INSTITUTIONAL_SELECTED_CHUNKS = 24;

const uuidRe =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

const SSE_HEADERS: HeadersInit = {
  "Content-Type": "text/event-stream; charset=utf-8",
  "Cache-Control": "no-cache, no-transform",
  Connection: "keep-alive",
  "X-Accel-Buffering": "no",
};


let openai: OpenAI | null = null;

if (!openaiApiKey) {
  console.error("[/api/governance/chat] OPENAI_API_KEY não está definida.");
} else {
  openai = new OpenAI({ apiKey: openaiApiKey });
}

type GovernanceChatRequestBody = {
  conversationId?: string;
  content?: string;
  responseMode?: GovernanceResponseMode;
  selectedPdfAttachmentNames?: string[];
  selectedPdfFileIds?: string[];
};

type GovernanceConversationForChat = {
  id: string;
  organization_id: string;
  user_id: string;
  title: string;
  category: string | null;
  response_mode: GovernanceResponseMode;
  visibility: "private" | "organization";
  status: "active" | "archived" | "deleted";
  deleted_at: string | null;
};

type GovernanceOfficialSourceForChat = {
  id: string;
  organization_id: string;
  name: string;
  source_type: string;
  url: string;
  notes: string | null;
  status: string;
  priority: string | null;
  reviewed_at: string | null;
};

type OpenAIInputMessage = {
  role: "system" | "user" | "assistant";
  content: string;
};

const allowedResponseModes: GovernanceResponseMode[] = [
  "objective",
  "summary",
  "checklist",
  "technical_opinion",
  "risk_analysis",
  "attention_points",
  "action_plan",
  "draft",
  "comparison",
  "manager_guidance",
];

function isValidGovernanceResponseMode(
  value: unknown,
): value is GovernanceResponseMode {
  return (
    typeof value === "string" &&
    allowedResponseModes.includes(value as GovernanceResponseMode)
  );
}

function normalizeResponseMode(
  value: unknown,
  fallback: GovernanceResponseMode,
): GovernanceResponseMode {
  return isValidGovernanceResponseMode(value) ? value : fallback;
}

function createWritableSupabaseRouteClient() {
  const cookieStore = cookies();

  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
  const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

  return createServerClient(supabaseUrl, supabaseAnonKey, {
    cookies: {
      get(name: string) {
        return cookieStore.get(name)?.value;
      },
      set(name: string, value: string, options: any) {
        cookieStore.set({ name, value, ...options });
      },
      remove(name: string, options: any) {
        cookieStore.set({ name, value: "", ...options });
      },
    },
  });
}

function createServiceRoleSupabaseClient() {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const supabaseServiceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!supabaseUrl || !supabaseServiceRoleKey) {
    return null;
  }

  return createSupabaseClient(supabaseUrl, supabaseServiceRoleKey, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  });
}


function mapGovernanceModeToPromptMode(
  mode: GovernanceResponseMode,
):
  | "objective"
  | "summary"
  | "step_by_step"
  | "checklist"
  | "document_draft"
  | "manager_guidance" {
  switch (mode) {
    case "summary":
      return "summary";

    case "checklist":
    case "risk_analysis":
    case "attention_points":
    case "action_plan":
    case "comparison":
      return "checklist";

    case "technical_opinion":
    case "draft":
      return "document_draft";

    case "manager_guidance":
      return "manager_guidance";

    case "objective":
    default:
      return "objective";
  }
}

function buildGovernanceModeInstruction(mode: GovernanceResponseMode): string {
  switch (mode) {
    case "summary":
      return [
        "MODO DE RESPOSTA ATIVO: RESUMO.",
        "OBEDEÇA AO FORMATO: entregue uma síntese curta, sem parecer, sem checklist longo e sem plano de ação.",
        "Estrutura obrigatória:",
        "1. Comece com 1 parágrafo de visão geral.",
        "2. Depois apresente no máximo 5 pontos essenciais.",
        "3. Finalize com uma conclusão prática em 1 parágrafo.",
        "Limite a resposta a uma versão enxuta, focada no essencial.",
      ].join("\n");

    case "checklist":
      return [
        "MODO DE RESPOSTA ATIVO: CHECKLIST.",
        "OBEDEÇA AO FORMATO: a resposta deve ser predominantemente uma lista verificável.",
        "Estrutura obrigatória:",
        "Título: CHECKLIST PRÁTICO",
        "Use itens iniciados por '☐'.",
        "Cada item deve ser acionável e verificável.",
        "Evite parágrafos longos. Não escreva parecer, minuta ou análise de risco.",
      ].join("\n");

    case "technical_opinion":
      return [
        "MODO DE RESPOSTA ATIVO: PARECER TÉCNICO.",
        "OBEDEÇA AO FORMATO: a resposta deve iniciar obrigatoriamente com o título PARECER TÉCNICO.",
        "Escreva como documento técnico institucional, não como conversa, resumo, checklist, minuta ou orientação ao gestor.",
        "Use obrigatoriamente estes blocos, nesta ordem e com títulos em caixa alta:",
        "PARECER TÉCNICO",
        "",
        "1. ASSUNTO",
        "Indique em uma frase o tema analisado.",
        "",
        "2. RELATÓRIO",
        "Contextualize brevemente a situação apresentada pelo usuário.",
        "",
        "3. FUNDAMENTAÇÃO TÉCNICA",
        "Aponte os fundamentos administrativos, técnicos e normativos aplicáveis, sem inventar norma local.",
        "",
        "4. ANÁLISE",
        "Examine o caso de forma objetiva, relacionando fatos, cautelas, riscos e condições de validade.",
        "",
        "5. CONCLUSÃO",
        "Apresente conclusão clara sobre o entendimento técnico.",
        "",
        "6. RECOMENDAÇÃO TÉCNICA",
        "Indique as providências recomendadas ao órgão.",
        "",
        "É proibido começar com introdução conversacional do tipo 'Na prática' ou 'O ponto central é'.",
        "É proibido responder apenas com tópicos soltos. O formato deve parecer um parecer técnico institucional.",
      ].join("\n");

    case "risk_analysis":
      return [
        "MODO DE RESPOSTA ATIVO: ANÁLISE DE RISCO.",
        "OBEDEÇA AO FORMATO: a resposta deve mapear riscos, não virar orientação genérica.",
        "Estrutura obrigatória:",
        "1. Matriz de riscos em tópicos ou tabela.",
        "2. Para cada risco, indique: risco, probabilidade, impacto, consequência e mitigação.",
        "3. Finalize com prioridades de controle.",
        "Não escreva como resumo, parecer ou checklist simples.",
      ].join("\n");

    case "attention_points":
      return [
        "MODO DE RESPOSTA ATIVO: PONTOS DE ATENÇÃO.",
        "OBEDEÇA AO FORMATO: liste alertas objetivos e cuidados críticos.",
        "Estrutura obrigatória:",
        "Título: PONTOS DE ATENÇÃO",
        "Use tópicos curtos iniciados por 'Atenção:'.",
        "Destaque riscos de conformidade, documentação, prazos, responsabilidades e validações necessárias.",
        "Não transforme em plano de ação completo.",
      ].join("\n");

    case "action_plan":
      return [
        "MODO DE RESPOSTA ATIVO: PLANO DE AÇÃO.",
        "OBEDEÇA AO FORMATO: organize ações práticas em sequência operacional.",
        "Estrutura obrigatória:",
        "Use uma tabela em Markdown com as colunas: Etapa | Ação | Responsável sugerido | Prazo sugerido | Resultado esperado.",
        "Depois da tabela, inclua apenas 3 prioridades imediatas.",
        "Não escreva parecer, minuta ou resumo.",
      ].join("\n");

    case "draft":
      return [
        "MODO DE RESPOSTA ATIVO: MINUTA.",
        "OBEDEÇA AO FORMATO: produza um texto formal editável, pronto para adaptação pelo órgão.",
        "Estrutura obrigatória:",
        "1. Título da minuta.",
        "2. Texto em linguagem institucional.",
        "3. Campos faltantes entre colchetes, como [NOME DO ÓRGÃO], [DATA], [RESPONSÁVEL].",
        "4. Observação final de validação jurídica/técnica.",
        "Não responda com explicação longa; entregue a minuta.",
      ].join("\n");

    case "comparison":
      return [
        "MODO DE RESPOSTA ATIVO: COMPARATIVO.",
        "OBEDEÇA AO FORMATO: compare alternativas, cenários, regras ou caminhos.",
        "Estrutura obrigatória:",
        "Use uma tabela em Markdown com colunas adequadas ao tema, por exemplo: Critério | Opção A | Opção B | Observação.",
        "Depois da tabela, inclua uma conclusão comparativa objetiva.",
        "Não escreva como checklist ou parecer.",
      ].join("\n");

    case "manager_guidance":
      return [
        "MODO DE RESPOSTA ATIVO: ORIENTAÇÃO AO GESTOR.",
        "OBEDEÇA AO FORMATO: responda para apoiar decisão administrativa.",
        "Estrutura obrigatória:",
        "1. Decisão que o gestor precisa tomar.",
        "2. O que observar antes de decidir.",
        "3. Providências recomendadas.",
        "4. Riscos se nada for feito.",
        "5. Próximo passo sugerido.",
        "Use tom direto, executivo e prático.",
      ].join("\n");

    case "objective":
    default:
      return [
        "MODO DE RESPOSTA ATIVO: PADRÃO CONSULTIVO.",
        "Responda de forma natural, consultiva e didática.",
        "Comece com texto corrido explicando a lógica do tema.",
        "Depois, se útil, organize os principais pontos práticos.",
        "Não force formato de checklist, parecer, minuta, tabela ou plano de ação, salvo pedido expresso do usuário.",
      ].join("\n");
  }
}

function buildConversationContext(params: {
  organizationName: string;
  organizationId: string;
  conversation: GovernanceConversationForChat;
}) {
  const { organizationName, organizationId, conversation } = params;

  return [
    "CONTEXTO INSTITUCIONAL DO GOVERNANÇA",
    `- Organização: ${organizationName}`,
    `- organization_id: ${organizationId}`,
    `- Conversa: ${conversation.title}`,
    `- Categoria: ${conversation.category || "não informada"}`,
    `- Visibilidade: ${conversation.visibility}`,
    "",
    "REGRAS DE ISOLAMENTO",
    "- Responda apenas no contexto da organização atual.",
    "- Não presuma acesso a dados de outros órgãos.",
    "- Quando faltar informação local, diga que o órgão deve validar em sua base institucional ou norma própria.",
    "- Não afirme que consultou documentos institucionais se eles ainda não foram fornecidos nesta conversa.",
    "- Para temas jurídicos, contábeis, fiscais, licitatórios ou de controle, indique quando houver necessidade de revisão por área técnica competente.",
  ].join("\n");
}


function normalizeOfficialSourcePriority(priority: string | null | undefined) {
  const normalizedPriority = String(priority ?? "medium")
    .trim()
    .toLowerCase();

  if (["alta", "high", "1"].includes(normalizedPriority)) {
    return "alta";
  }

  if (["baixa", "low", "3"].includes(normalizedPriority)) {
    return "baixa";
  }

  return "media";
}

function getOfficialSourcePriorityLabel(priority: string | null | undefined) {
  const normalizedPriority = normalizeOfficialSourcePriority(priority);

  if (normalizedPriority === "alta") {
    return "Alta";
  }

  if (normalizedPriority === "baixa") {
    return "Baixa";
  }

  return "Média";
}

function getOfficialSourcePriorityRank(priority: string | null | undefined) {
  const normalizedPriority = normalizeOfficialSourcePriority(priority);

  if (normalizedPriority === "alta") {
    return 1;
  }

  if (normalizedPriority === "media") {
    return 2;
  }

  return 3;
}

function getOfficialSourceTypeLabel(sourceType: string | null | undefined) {
  switch (sourceType) {
    case "municipal_website":
      return "Site municipal";
    case "official_gazette":
      return "Diário oficial";
    case "transparency_portal":
      return "Portal da transparência";
    case "institutional_repository":
      return "Repositório institucional";
    case "other":
      return "Outra fonte";
    default:
      return sourceType ? String(sourceType) : "Tipo não informado";
  }
}

function normalizeOfficialSourceSearchText(value: string) {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();
}

type OfficialSourceIntent =
  | "legislation"
  | "official_gazette"
  | "transparency"
  | "institutional"
  | "bidding"
  | "generic";

function detectOfficialSourceIntent(question: string): OfficialSourceIntent {
  const normalizedQuestion = normalizeOfficialSourceSearchText(question);

  if (
    /\b(lei|leis|legislacao|legislativo|decreto|decretos|portaria|portarias|codigo|norma|normas|ato administrativo|atos administrativos|lei organica)\b/.test(
      normalizedQuestion,
    )
  ) {
    return "legislation";
  }

  if (
    /\b(diario oficial|diario|edicao|publicacao|publicado|publicada|publicados|publicadas|edital|extrato|ratificacao)\b/.test(
      normalizedQuestion,
    )
  ) {
    return "official_gazette";
  }

  if (
    /\b(transparencia|receita|receitas|despesa|despesas|empenho|empenhos|pagamento|pagamentos|orcamento|prestacao de contas)\b/.test(
      normalizedQuestion,
    )
  ) {
    return "transparency";
  }

  if (/\b(licitacao|licitacoes|dispensa|inexigibilidade|pregao|contrato|contratos)\b/.test(normalizedQuestion)) {
    return "bidding";
  }

  if (/\b(site|portal|pagina oficial|endereco|url|link|acessar|acesso)\b/.test(normalizedQuestion)) {
    return "institutional";
  }

  return "generic";
}

function getOfficialSourceIntentLabel(intent: OfficialSourceIntent) {
  switch (intent) {
    case "legislation":
      return "legislação municipal, leis, decretos, portarias e atos administrativos";
    case "official_gazette":
      return "Diário Oficial, edições, publicações, editais, extratos e atos publicados";
    case "transparency":
      return "Portal da Transparência, receitas, despesas, empenhos, orçamento e prestação de contas";
    case "bidding":
      return "licitações, dispensas, inexigibilidades, pregões e contratos";
    case "institutional":
      return "site, portal, URL, acesso e páginas oficiais";
    case "generic":
    default:
      return "referências oficiais gerais da organização";
  }
}

function getOfficialSourceTextForScoring(source: GovernanceOfficialSourceForChat) {
  return normalizeOfficialSourceSearchText(
    [
      source.name,
      source.source_type,
      source.url,
      source.notes,
      getOfficialSourceTypeLabel(source.source_type),
    ]
      .filter(Boolean)
      .join(" "),
  );
}

function scoreOfficialSourceForQuestion(
  source: GovernanceOfficialSourceForChat,
  question: string,
) {
  const intent = detectOfficialSourceIntent(question);
  const text = getOfficialSourceTextForScoring(source);
  const sourceName = normalizeOfficialSourceSearchText(String(source.name ?? ""));
  const sourceUrl = normalizeOfficialSourceSearchText(String(source.url ?? ""));
  const sourceType = normalizeOfficialSourceSearchText(String(source.source_type ?? ""));
  let score = 0;

  score += Math.max(0, 4 - getOfficialSourcePriorityRank(source.priority));

  if (intent === "legislation") {
    const isExplicitLegislationSource =
      /legislacao municipal|legislacao|leis municipais|leis|atos administrativos|atos-administrativos|lei organica/.test(
        sourceName,
      ) ||
      /leis-e-atos-administrativos|leis|atos-administrativos|legislacao|lei-organica/.test(
        sourceUrl,
      );

    const isGenericTransparencySource =
      /portal da transparencia|transparencia/.test(sourceName) &&
      !/leis|atos|legislacao/.test(sourceName) &&
      !/leis|atos-administrativos|legislacao/.test(sourceUrl);

    const isOfficialGazetteSource = /diario oficial|official_gazette|gazette/.test(text);

    if (isExplicitLegislationSource) score += 500;
    if (/legislacao|leis|lei|atos administrativos|atos-administrativos|lei organica/.test(text)) score += 120;
    if (/transparencia.*leis|leis.*atos|leis-e-atos-administrativos/.test(text)) score += 100;
    if (isOfficialGazetteSource) score += 15;
    if (isGenericTransparencySource) score -= 80;
  }

  if (intent === "official_gazette") {
    if (/diario oficial|official_gazette|gazette|publicacao|edicao/.test(text)) score += 120;
    if (/leis|legislacao|atos administrativos/.test(text)) score += 15;
  }

  if (intent === "transparency") {
    if (/transparencia|transparency|receita|despesa|empenho|orcamento|prestacao/.test(text)) score += 120;
    if (/leis-e-atos-administrativos|legislacao municipal/.test(text)) score -= 20;
  }

  if (intent === "bidding") {
    if (/licitacao|licitacoes|pregao|contrato|contratos|dispensa|inexigibilidade/.test(text)) score += 120;
    if (/transparencia|transparência|betha|betha contabil|betha contábil/.test(text)) score += 120;
    if (/diario oficial/.test(text)) score += 40;
    if (/portal|site oficial|municipal_website/.test(text)) score += 35;
  }

  if (intent === "institutional") {
    if (/site municipal|municipal_website|portal|prefeitura|municipio/.test(text)) score += 80;
  }

  if (sourceType.includes(intent)) {
    score += 20;
  }

  const normalizedQuestion = normalizeOfficialSourceSearchText(question);
  const questionWords = normalizedQuestion
    .split(/\W+/)
    .filter((word) => word.length >= 4);

  for (const word of questionWords) {
    if (text.includes(word)) {
      score += 4;
    }
  }

  return {
    score,
    intent,
  };
}

function sortOfficialSourcesForQuestion(
  sources: GovernanceOfficialSourceForChat[],
  question: string,
) {
  return [...sources].sort((a, b) => {
    const scoreA = scoreOfficialSourceForQuestion(a, question).score;
    const scoreB = scoreOfficialSourceForQuestion(b, question).score;

    if (scoreA !== scoreB) {
      return scoreB - scoreA;
    }

    const priorityDiff =
      getOfficialSourcePriorityRank(a.priority) - getOfficialSourcePriorityRank(b.priority);

    if (priorityDiff !== 0) {
      return priorityDiff;
    }

    return String(a.name ?? "").localeCompare(String(b.name ?? ""), "pt-BR", {
      sensitivity: "base",
      numeric: true,
    });
  });
}

type PrioritizedOfficialSourceForChat = {
  source: GovernanceOfficialSourceForChat;
  score: number;
  intent: OfficialSourceIntent;
};

function getPrioritizedOfficialSourceForQuestion(
  sources: GovernanceOfficialSourceForChat[],
  question: string,
): PrioritizedOfficialSourceForChat | null {
  const intent = detectOfficialSourceIntent(question);

  if (intent === "legislation") {
    const explicitLegislationSource = sources.find((source) => {
      const sourceName = normalizeOfficialSourceSearchText(String(source.name ?? ""));
      const sourceUrl = normalizeOfficialSourceSearchText(String(source.url ?? ""));
      const sourceNotes = normalizeOfficialSourceSearchText(String(source.notes ?? ""));

      return (
        /legislacao municipal|legislacao|leis municipais|leis|atos administrativos|lei organica/.test(
          sourceName,
        ) ||
        /leis-e-atos-administrativos|legislacao|lei-organica/.test(sourceUrl) ||
        /legislacao municipal|leis municipais|atos administrativos|lei organica/.test(sourceNotes)
      );
    });

    if (explicitLegislationSource) {
      return {
        source: explicitLegislationSource,
        score: 10000,
        intent,
      };
    }
  }

  const sortedSources = sortOfficialSourcesForQuestion(sources, question);
  const scoredSources = sortedSources.map((source) => ({
    source,
    ...scoreOfficialSourceForQuestion(source, question),
  }));

  return scoredSources.find((item) => item.score >= 25) ?? null;
}

function buildOfficialSourcesContextText(
  sources: GovernanceOfficialSourceForChat[],
  question: string,
) {
  if (sources.length === 0) {
    return "";
  }

  const sortedSources = sortOfficialSourcesForQuestion(sources, question);
  const prioritizedSource = getPrioritizedOfficialSourceForQuestion(sources, question);
  const detectedIntent = detectOfficialSourceIntent(question);

  const lines = [
    "FONTES OFICIAIS CADASTRADAS DA ORGANIZAÇÃO",
    "",
    "Use estas fontes como referência preferencial para indicar links oficiais do órgão atual.",
    "Regra obrigatória: quando existir uma fonte oficial cadastrada claramente relacionada ao assunto da pergunta, cite essa fonte específica com a URL oficial cadastrada.",
    "Regra obrigatória: para perguntas sobre onde encontrar leis, legislação, decretos, portarias ou atos administrativos, responda primeiro com a fonte Legislação Municipal quando ela estiver cadastrada.",
    "Não substitua uma fonte específica por uma fonte genérica. Exemplo: para perguntas sobre leis, legislação, decretos, portarias ou atos administrativos, priorize a fonte de Legislação Municipal, quando cadastrada.",
    "Não afirme que consultou o conteúdo da página em tempo real; use os links como referências oficiais cadastradas.",
    "",
    prioritizedSource
      ? [
          "FONTE OFICIAL PRIORITÁRIA PARA ESTA PERGUNTA",
          `Nome exato obrigatório: ${String(prioritizedSource.source.name ?? "Fonte oficial").trim()}`,
          `Tipo: ${getOfficialSourceTypeLabel(prioritizedSource.source.source_type)}`,
          `Prioridade cadastrada: ${getOfficialSourcePriorityLabel(prioritizedSource.source.priority)}`,
          `URL exata obrigatória: ${String(prioritizedSource.source.url ?? "").trim()}`,
          `Motivo: a pergunta foi classificada como relacionada a ${getOfficialSourceIntentLabel(prioritizedSource.intent)}.`,
          "Instrução obrigatória: comece a orientação de consulta por esta fonte prioritária.",
          "Instrução obrigatória: cite o nome exato obrigatório e a URL exata obrigatória antes de qualquer fonte genérica.",
          "Instrução obrigatória: não troque, resuma, encurte ou substitua esta URL por outro endereço.",
          "Instrução obrigatória: se a fonte prioritária for Legislação Municipal, não substitua por Portal da Transparência genérico nem por Diário Oficial.",
          "",
        ].join("\n")
      : [
          "ASSUNTO IDENTIFICADO",
          `A pergunta foi classificada como relacionada a ${getOfficialSourceIntentLabel(detectedIntent)}.`,
          "Nenhuma fonte específica superou o limite de priorização; use a lista abaixo por ordem de relevância e prioridade.",
          "",
        ].join("\n"),
    "DEMAIS FONTES OFICIAIS ATIVAS, ORDENADAS POR RELEVÂNCIA PARA A PERGUNTA",
    "",
    ...sortedSources.flatMap((source, index) => [
      `${index + 1}. ${String(source.name ?? "Fonte oficial").trim()}`,
      `   Tipo: ${getOfficialSourceTypeLabel(source.source_type)}`,
      `   Prioridade: ${getOfficialSourcePriorityLabel(source.priority)}`,
      `   URL oficial cadastrada: ${String(source.url ?? "").trim()}`,
      source.notes ? `   Observações: ${String(source.notes).trim()}` : "",
      source.reviewed_at ? `   Última revisão: ${source.reviewed_at}` : "",
      "",
    ]),
  ];

  return lines.filter((line) => line !== "").join("\n").trim();
}

function resolveMandatoryOfficialSourceForFinalAnswer(params: {
  sources: GovernanceOfficialSourceForChat[];
  prioritizedSource: PrioritizedOfficialSourceForChat | null;
  question: string;
}) {
  const { sources, prioritizedSource, question } = params;
  const intent = detectOfficialSourceIntent(question);

  if (intent === "legislation") {
    const legislationSource = sources.find((source) => {
      const sourceName = normalizeOfficialSourceSearchText(String(source.name ?? ""));
      const sourceUrl = normalizeOfficialSourceSearchText(String(source.url ?? ""));
      const sourceNotes = normalizeOfficialSourceSearchText(String(source.notes ?? ""));

      return (
        /legislacao municipal|legislacao|leis municipais|leis|atos administrativos|lei organica/.test(
          sourceName,
        ) ||
        /leis-e-atos-administrativos|legislacao|lei-organica/.test(sourceUrl) ||
        /legislacao municipal|leis municipais|atos administrativos|lei organica/.test(sourceNotes)
      );
    });

    if (legislationSource) {
      return legislationSource;
    }
  }

  return prioritizedSource?.source ?? null;
}

function applyOfficialSourceCitationGuard(params: {
  assistantText: string;
  sources: GovernanceOfficialSourceForChat[];
  prioritizedSource: PrioritizedOfficialSourceForChat | null;
  question: string;
}) {
  const { assistantText, sources, prioritizedSource, question } = params;

  const mandatorySource = resolveMandatoryOfficialSourceForFinalAnswer({
    sources,
    prioritizedSource,
    question,
  });

  if (!mandatorySource) {
    return assistantText;
  }

  const sourceName = String(mandatorySource.name ?? "Fonte oficial").trim();
  const sourceUrl = String(mandatorySource.url ?? "").trim();

  if (!sourceName || !sourceUrl) {
    return assistantText;
  }

  const normalizedAssistantText = normalizeOfficialSourceSearchText(assistantText);
  const normalizedSourceName = normalizeOfficialSourceSearchText(sourceName);
  const hasExactUrl = assistantText.includes(sourceUrl);
  const hasSourceName = normalizedAssistantText.includes(normalizedSourceName);

  if (hasExactUrl && hasSourceName) {
    return assistantText;
  }

  const guardBlock = [
    "Referência oficial específica cadastrada:",
    `- ${sourceName}: ${sourceUrl}`,
  ].join("\n");

  return `${assistantText.trim()}\n\n${guardBlock}`;
}


function sanitizeGovernanceAssistantText(params: {
  assistantText: string;
  question: string;
  institutionalSources: GovernanceChatSource[];
}) {
  const { question, institutionalSources } = params;
  let text = String(params.assistantText ?? "").trim();

  const hasCreationLawSource = institutionalSources.some((source) =>
    normalizeInstitutionalSearchText(source.title).includes("lei estadual") &&
    normalizeInstitutionalSearchText(source.title).includes("cria") &&
    normalizeInstitutionalSearchText(source.title).includes("municipio")
  );

  if (isMunicipalCreationLawQuestion(question) && hasCreationLawSource) {
    text = text
      .replace(
        /A criação do Município de Santana do Itararé decorre de lei estadual do Paraná,\s*mas o trecho recuperado traz,?\s*por engano,?\s*[^.]+\./gi,
        "O Município de Santana do Itararé foi criado por lei estadual do Paraná identificada na Base Institucional consultada.",
      )
      .replace(
        /Essa não é a lei específica de criação de Santana do Itararé\.\s*/gi,
        "",
      )
      .replace(
        /Como o número e a data exatos não constam no trecho disponível,\s*/gi,
        "",
      );
  }

  text = text.replace(
    /\[([^\]]+)\]\((https?:\/\/(?:www\.)?planalto\.gov\.br\/[^)]+)\)/gi,
    (full, label) => {
      const normalizedLabel = String(label ?? "");
      const isFederal =
        /\bFederal\b/i.test(normalizedLabel) ||
        /Constitui[cç][aã]o Federal/i.test(normalizedLabel);

      if (isFederal) {
        return full;
      }

      return String(label ?? "");
    },
  );

  text = text
    .replace(/\(o trecho recuperado é cortado aqui[^)]*\)/gi, "")
    .replace(/o trecho recuperado é cortado aqui[^.\n]*[.\n]/gi, "")
    .replace(/\n{3,}/g, "\n\n")
    .trim();

  return text;
}

function shouldSuppressExternalGovernanceContext(question: string) {
  return (
    isMunicipalCreationLawQuestion(question) ||
    isAdministrativeStructureQuestion(question) ||
    isCareerProgressionQuestion(question)
  );
}


async function loadActiveOfficialSourcesForChat(params: {
  client: ReturnType<typeof createWritableSupabaseRouteClient>;
  organizationId: string;
  question: string;
}) {
  const { client, organizationId, question } = params;

  const { data, error } = await client
    .from("official_sources")
    .select(
      `
        id,
        organization_id,
        name,
        source_type,
        url,
        notes,
        status,
        priority,
        reviewed_at
      `,
    )
    .eq("organization_id", organizationId)
    .eq("status", "active")
    .order("name", { ascending: true });

  if (error) {
    console.warn(
      "[governance/chat] Não foi possível carregar fontes oficiais ativas:",
      error,
    );

    return {
      sources: [] as GovernanceOfficialSourceForChat[],
      prioritizedSource: null as PrioritizedOfficialSourceForChat | null,
      contextText: "",
      error: "Não foi possível carregar as fontes oficiais cadastradas.",
    };
  }

  const sources = ((data ?? []) as GovernanceOfficialSourceForChat[])
    .filter((source) => String(source.url ?? "").trim().length > 0);

  return {
    sources,
    prioritizedSource: getPrioritizedOfficialSourceForQuestion(sources, question),
    contextText: buildOfficialSourcesContextText(sources, question),
    error: "",
  };
}


function buildGovernanceConsultantStyleInstruction(
  mode: GovernanceResponseMode,
  userText = "",
  relation: ConversationRelation = "INICIAL",
): string {
  if (mode !== "objective") {
    return [
      "REGRA DE PRIORIDADE DO MODO DE RESPOSTA",
      "O modo selecionado pelo usuário tem prioridade sobre o estilo consultivo geral.",
      "Não neutralize o formato escolhido.",
      "Se o modo for checklist, responda como checklist.",
      "Se o modo for parecer técnico, responda como parecer técnico.",
      "Se o modo for análise de risco, responda como análise de risco.",
      "Se o modo for minuta, entregue minuta.",
      "Se o modo for comparativo, use comparação clara.",
      "Mantenha clareza e segurança técnica, mas preserve a estrutura específica do modo selecionado.",
    ].join("\n");
  }

  if (relation === "CONTINUA_COMPLEMENTAR") {
    return [
      "ESTILO ESPECIAL PARA FOLLOW-UP EXECUTIVO",
      "A pergunta atual foi classificada como continuidade complementar.",
      "Neste caso, NÃO abra uma nova consultoria completa.",
      "Responda como continuidade da conversa, mas sem omitir detalhes necessários.",
      "Comece diretamente pelo ponto solicitado pelo usuário.",
      "Não faça introdução longa.",
      "Não redefina conceitos já explicados.",
      "Não reapresente o contexto anterior.",
      "Não repita listas gerais já apresentadas.",
      "Produza a análise necessária para responder corretamente, sem economia artificial.",
      "Não inclua seção de base legal, salvo se o usuário pedir expressamente ou se houver risco jurídico direto.",
      "Não limite a resposta por economia quando houver contexto suficiente. Responda de forma completa, proporcional ao pedido.",
      "Use somente lista curta, tabela simples ou roteiro objetivo.",
      "Quando a pergunta pedir indicadores, métricas, monitoramento ou avaliação, entregue os indicadores diretamente.",
      "Finalize com uma orientação prática curta para o gestor.",
    ].join("\n");
  }

  if (isObjectiveAdministrativeQuestion(userText)) {
    return [
      "REGRA PRIORITÁRIA DE ESTILO PARA PERGUNTA OBJETIVA",
      "A pergunta atual pede dado objetivo ligado à Administração Pública.",
      "Neste caso, a utilidade administrativa tem prioridade sobre o estilo consultivo longo.",
      "Comece pela resposta direta, sem introdução conceitual.",
      "É permitido iniciar com lista curta, tabela simples, valor, percentual, prazo ou frase objetiva.",
      "Não aplique a regra de 'explicar a lógica antes de responder'.",
      "Não transforme a resposta em mini parecer quando a pergunta pedir apenas limite, valor, prazo ou percentual.",
      "Depois da resposta direta, acrescente fundamento legal e cautelas práticas em blocos curtos.",
      "A resposta deve ser escaneável: o gestor precisa encontrar o dado principal nos primeiros segundos.",
    ].join("\n");
  }

  return [
    "REGRA PRIORITÁRIA DE ESTILO DO GOVERNANÇA",
    "A resposta deve soar como uma conversa técnica com um consultor experiente, não como despacho, checklist, manual interno ou relatório de auditoria.",
    "Antes de listar providências, explique a lógica do tema em 2 a 4 frases curtas, com linguagem natural e didática.",
    "Use frases de transição, exemplo: 'Na prática...', 'O ponto central é...', 'Antes de abrir o processo...', 'Sem isso, o procedimento fica frágil...'.",
    "Explique o porquê das providências. O usuário precisa entender a razão administrativa, não apenas receber uma sequência de tarefas.",
    "Evite começar a resposta com lista numerada, tópicos ou blocos intitulados. Comece com uma orientação em texto corrido.",
    "Use listas somente depois da introdução, quando elas ajudarem a organizar a resposta.",
    "Quando usar listas, misture orientação com explicação curta. Não escreva itens secos.",
    "Não use aparência de checklist no modo Padrão. Checklist só quando o usuário pedir ou escolher modo Checklist.",
    "Evite excesso de seções como 'Riscos', 'Providências', 'Base legal' em toda resposta. Use apenas quando realmente agregarem valor.",
    "O tom desejado é fluido, seguro, didático e aplicável à rotina de uma prefeitura.",
  ].join("\n");
}

function buildFinalConsultativeOverride(
  mode: GovernanceResponseMode,
  relation: ConversationRelation = "INICIAL",
): string {
  if (mode === "technical_opinion") {
    return [
      "REGRA FINAL OBRIGATÓRIA PARA PARECER TÉCNICO",
      "A resposta deve iniciar obrigatoriamente com o título: PARECER TÉCNICO.",
      "Use exatamente os blocos: 1. ASSUNTO, 2. RELATÓRIO, 3. FUNDAMENTAÇÃO TÉCNICA, 4. ANÁLISE, 5. CONCLUSÃO e 6. RECOMENDAÇÃO TÉCNICA.",
      "É proibido responder como conversa consultiva, checklist, resumo, plano de ação ou minuta.",
      "Não use abertura genérica. Comece diretamente no formato de parecer.",
      "Mantenha linguagem formal, institucional e tecnicamente cautelosa.",
    ].join("\n");
  }

  if (mode !== "objective") {
    return [
      "REGRA FINAL OBRIGATÓRIA",
      `O modo selecionado é ${mode}. A resposta precisa ficar visual e estruturalmente diferente do modo Padrão.`,
      "Não comece com a mesma introdução genérica usada no modo Padrão.",
      "Não entregue uma orientação consultiva genérica se o modo exigir outro formato.",
      "Siga rigorosamente a estrutura indicada para o modo selecionado.",
    ].join("\n");
  }

  if (relation === "CONTINUA_COMPLEMENTAR") {
    return [
      "REGRA FINAL OBRIGATÓRIA PARA FOLLOW-UP EXECUTIVO",
      "A pergunta atual é complementar ao tema anterior.",
      "A resposta NÃO deve seguir o formato longo do modo Padrão.",
      "Não comece com contextualização ampla.",
      "Não explique novamente a lógica administrativa já apresentada.",
      "Não use estrutura de artigo, parecer, relatório ou mini consultoria.",
      "Não inclua Base legal ou Referências oficiais, salvo pedido expresso ou risco jurídico direto.",
      "FORMATO EXATO OBRIGATÓRIO:",
      "Resposta direta:",
      "Uma frase curta respondendo ao ponto perguntado.",
      "",
      "Indicadores/Métricas principais:",
      "- item 1",
      "- item 2",
      "- item 3",
      "- item 4",
      "- item 5",
      "",
      "Como acompanhar:",
      "- item 1",
      "- item 2",
      "",
      "REGRAS DE TAMANHO:",
      "- Máximo de 180 palavras.",
      "- Máximo de 6 indicadores/métricas.",
      "- Máximo de 2 itens em Como acompanhar.",
      "- Fechamento prático em uma única frase.",
    ].join("\n");
  }

  return [
    "REGRA FINAL OBRIGATÓRIA PARA O MODO PADRÃO",
    "No modo Padrão, a primeira parte da resposta deve ser texto corrido, explicativo e fluido.",
    "É proibido começar diretamente com '1.', '-', '•', tabela ou cabeçalho técnico.",
    "Formato desejado:",
    "1. Um parágrafo inicial contextualizando o tema.",
    "2. Um segundo parágrafo explicando a lógica administrativa.",
    "3. Só depois, se útil, uma lista com os pontos principais.",
    "4. Fechar com um cuidado prático ou orientação ao gestor.",
    "Escreva como o módulo Estratégico: didático, natural, gostoso de ler, mas tecnicamente seguro.",
  ].join("\n");
}

function mapMessagesToOpenAIInput(
  messages: GovernanceMessage[],
  options?: {
    currentMessageOnly?: boolean;
  },
): OpenAIInputMessage[] {
  const sourceMessages = options?.currentMessageOnly
    ? [...messages].reverse().filter((message) => message.role === "user").slice(0, 1).reverse()
    : messages;

  const relevantMessages = sourceMessages.filter((message) => {
    return (
      message.role === "user" ||
      message.role === "assistant" ||
      message.role === "system"
    );
  });

  return relevantMessages.map((message) => {
    if (message.role === "system") {
      return {
        role: "system",
        content: message.content,
      };
    }

    if (message.role === "assistant") {
      return {
        role: "assistant",
        content: message.content,
      };
    }

    return {
      role: "user",
      content: message.content,
    };
  });
}


type SuggestedNextQuestion = {
  id: string;
  label: string;
  prompt: string;
};

function stripSuggestionMarkdown(value: string) {
  return String(value ?? "")
    .replace(/^[-*•\d.)\s]+/g, "")
    .replace(/\*\*(.*?)\*\*/g, "$1")
    .replace(/__(.*?)__/g, "$1")
    .replace(/`([^`]+)`/g, "$1")
    .replace(/\s+/g, " ")
    .trim();
}

function normalizeSuggestionText(value: unknown) {
  const text = stripSuggestionMarkdown(String(value ?? ""));

  if (!text) {
    return "";
  }

  return text.length > 140 ? `${text.slice(0, 137).trim()}...` : text;
}

function makeSuggestionId(value: string, index: number) {
  const base = String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 48);

  return base ? `${base}-${index + 1}` : `suggestion-${index + 1}`;
}

function parseSuggestedNextQuestions(rawText: string): SuggestedNextQuestion[] {
  const text = String(rawText ?? "").trim();

  if (!text) {
    return [];
  }

  const candidates: unknown[] = [];

  try {
    const parsed = JSON.parse(text);
    const list = Array.isArray(parsed)
      ? parsed
      : Array.isArray(parsed?.suggestions)
        ? parsed.suggestions
        : Array.isArray(parsed?.questions)
          ? parsed.questions
          : [];

    candidates.push(...list);
  } catch {
    const jsonMatch = text.match(/\{[\s\S]*\}|\[[\s\S]*\]/);

    if (jsonMatch?.[0]) {
      try {
        const parsed = JSON.parse(jsonMatch[0]);
        const list = Array.isArray(parsed)
          ? parsed
          : Array.isArray(parsed?.suggestions)
            ? parsed.suggestions
            : Array.isArray(parsed?.questions)
              ? parsed.questions
              : [];

        candidates.push(...list);
      } catch {
        // Fallback abaixo.
      }
    }
  }

  if (candidates.length === 0) {
    const fallbackLines = text
      .split("\n")
      .map((line) => normalizeSuggestionText(line))
      .filter(Boolean);

    candidates.push(...fallbackLines);
  }

  const seen = new Set<string>();
  const suggestions: SuggestedNextQuestion[] = [];

  for (const candidate of candidates) {
    const rawLabel =
      typeof candidate === "string"
        ? candidate
        : (candidate as any)?.label ?? (candidate as any)?.question ?? (candidate as any)?.prompt;

    const rawPrompt =
      typeof candidate === "string"
        ? candidate
        : (candidate as any)?.prompt ?? (candidate as any)?.question ?? (candidate as any)?.label;

    const label = normalizeSuggestionText(rawLabel);
    const prompt = normalizeSuggestionText(rawPrompt);

    if (!label || !prompt) {
      continue;
    }

    const key = prompt.toLowerCase();

    if (seen.has(key)) {
      continue;
    }

    seen.add(key);
    suggestions.push({
      id: makeSuggestionId(prompt, suggestions.length),
      label,
      prompt,
    });

    if (suggestions.length >= 5) {
      break;
    }
  }

  return suggestions;
}

async function generateGovernanceFollowUpSuggestions(params: {
  userContent: string;
  assistantText: string;
  responseMode: GovernanceResponseMode;
  hasSelectedPdfAttachments: boolean;
  selectedPdfAttachmentNames: string[];
}): Promise<SuggestedNextQuestion[]> {
  if (!openai) {
    return [];
  }

  const assistantContext = clampText(params.assistantText, 7000);
  const userContext = clampText(params.userContent, 1800);

  if (!assistantContext) {
    return [];
  }

  const pdfContext = params.hasSelectedPdfAttachments
    ? [
        "A pergunta envolveu PDFs selecionados.",
        params.selectedPdfAttachmentNames.length > 0
          ? `PDFs informados: ${params.selectedPdfAttachmentNames.join(", ")}.`
          : "",
      ]
        .filter(Boolean)
        .join("\n")
    : "A pergunta não usou PDFs selecionados.";

  const suggestionInstructions = [
    "Você gera sugestões inteligentes de próxima pergunta para o chat Publ.IA Governança.",
    "Baseie-se exclusivamente na pergunta do usuário e na resposta da IA.",
    "Crie perguntas realmente contextuais, específicas e úteis para continuidade da conversa.",
    "Não use sugestões genéricas como 'Gerar resumo executivo', 'Pontos de atenção' ou 'Transformar em checklist', salvo se isso for claramente o próximo passo mais específico.",
    "As perguntas devem ser em português do Brasil, curtas e acionáveis.",
    "Retorne somente JSON válido, sem Markdown, sem comentários e sem texto antes ou depois.",
    'Formato obrigatório: {"suggestions":[{"label":"...","prompt":"..."}]}',
    "Gere entre 3 e 5 sugestões.",
  ].join("\n");

  const suggestionInput = [
    {
      role: "user" as const,
      content: [
        `Modo de resposta usado: ${params.responseMode}.`,
        pdfContext,
        "",
        "Pergunta do usuário:",
        userContext,
        "",
        "Resposta da IA:",
        assistantContext,
      ].join("\n"),
    },
  ];

  try {
    const response = await openai.responses.create({
      model: OPENAI_MODEL_GOVERNANCE,
      instructions: suggestionInstructions,
      input: suggestionInput,
      temperature: 0.2,
      max_output_tokens: 700,
    } as any);

    return parseSuggestedNextQuestions(response.output_text ?? "");
  } catch (error) {
    console.error("[governance/chat] Erro ao gerar sugestões de próxima pergunta:", error);
    return [];
  }
}

type GovernancePdfContextResult = {
  selectedPdfFileIds: string[];
  pdfContextText: string;
  pdfContextAvailable: boolean;
  pdfContextWarnings: string[];
};

type GovernancePdfFileRow = {
  id: string;
  file_name: string | null;
  extracted_text: string | null;
  extracted_text_status: string | null;
  vector_index_status: string | null;
  vector_chunks_count: number | null;
};

type GovernanceMatchPdfChunkRow = {
  chunk_index: number;
  content: string;
};

function clampText(text: string, maxChars: number) {
  const clean = String(text ?? "").trim();

  if (clean.length <= maxChars) {
    return clean;
  }

  return `${clean.slice(0, Math.max(0, maxChars - 20)).trim()}\n\n[texto cortado]`;
}

function normalizePdfText(text: string) {
  return String(text ?? "")
    .replace(/\u0000/g, " ")
    .replace(/\r/g, "\n")
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .replace(/[ \t]{2,}/g, " ")
    .trim();
}

function buildGovernancePdfLabel(pdfRow: GovernancePdfFileRow) {
  const fileName = String(pdfRow.file_name ?? "").trim();
  return fileName || `PDF ${pdfRow.id}`;
}

async function getGovernancePdfQueryEmbedding(question: string) {
  if (!openai) {
    return null;
  }

  try {
    const response = await openai.embeddings.create({
      model: EMBEDDING_MODEL,
      input: question,
      encoding_format: "float",
    } as any);

    const embedding = (response as any)?.data?.[0]?.embedding;

    if (!Array.isArray(embedding) || embedding.length === 0) {
      return null;
    }

    return embedding as number[];
  } catch (error) {
    console.error("[governance/chat] Erro ao gerar embedding da pergunta:", error);
    return null;
  }
}

async function buildGovernancePdfContextFromVector(
  client: ReturnType<typeof createWritableSupabaseRouteClient>,
  pdfRow: GovernancePdfFileRow,
  question: string,
  maxChars: number,
) {
  const vectorReady =
    String(pdfRow.vector_index_status ?? "").toLowerCase() === "ready" &&
    Number(pdfRow.vector_chunks_count ?? 0) > 0;

  if (!vectorReady) {
    return "";
  }

  const queryEmbedding = await getGovernancePdfQueryEmbedding(question);

  if (!queryEmbedding) {
    return "";
  }

  const { data: matches, error: matchError } = await client.rpc("match_pdf_chunks", {
    query_embedding: queryEmbedding,
    match_count: RAG_TOP_K,
    filter_pdf_file_id: pdfRow.id,
  } as any);

  if (matchError) {
    console.error("[governance/chat] Erro ao buscar chunks vetoriais do PDF:", {
      pdfFileId: pdfRow.id,
      error: matchError.message,
    });

    return "";
  }

  if (!Array.isArray(matches) || matches.length === 0) {
    return "";
  }

  const label = buildGovernancePdfLabel(pdfRow);

  const raw = (matches as GovernanceMatchPdfChunkRow[])
    .map((match, index) =>
      [
        `[${label}] Trecho ${index + 1} (chunk #${Number(match.chunk_index ?? 0)}):`,
        String(match.content ?? "").trim(),
      ]
        .filter(Boolean)
        .join("\n"),
    )
    .filter((block) => block.trim().length > 0)
    .join("\n\n---\n\n");

  return clampText(raw, maxChars);
}

function buildGovernancePdfContextFromExtractedText(
  pdfRow: GovernancePdfFileRow,
  question: string,
  maxChars: number,
) {
  if (String(pdfRow.extracted_text_status ?? "").toLowerCase() !== "ready") {
    return "";
  }

  const text = normalizePdfText(pdfRow.extracted_text ?? "");

  if (!text) {
    return "";
  }

  const chunks = chunkText(text, {
    chunkSize: 1200,
    overlap: 200,
    maxChunks: 320,
  });

  const picked = pickRelevantChunks(chunks, question, {
    maxChunks: 4,
    maxChars,
    minScore: 1,
  });

  const chunksToUse = picked.length > 0 ? picked : chunks.slice(0, 4);

  if (!chunksToUse.length) {
    return "";
  }

  const label = buildGovernancePdfLabel(pdfRow);

  const raw = chunksToUse
    .map((chunk, index) =>
      [
        `[${label}] Trecho ${index + 1} (chunk #${chunk.index}):`,
        chunk.text,
      ].join("\n"),
    )
    .join("\n\n---\n\n");

  return clampText(raw, maxChars);
}

async function buildGovernancePdfContext({
  client,
  userId,
  selectedPdfFileIds,
  question,
}: {
  client: ReturnType<typeof createWritableSupabaseRouteClient>;
  userId: string;
  selectedPdfFileIds: string[];
  question: string;
}): Promise<GovernancePdfContextResult> {
  const uniquePdfFileIds = Array.from(new Set(selectedPdfFileIds))
    .map((id) => id.trim())
    .filter((id) => uuidRe.test(id))
    .slice(0, MAX_SELECTED_PDFS_IN_GOVERNANCE_CHAT);

  if (uniquePdfFileIds.length === 0) {
    return {
      selectedPdfFileIds: [],
      pdfContextText: "",
      pdfContextAvailable: false,
      pdfContextWarnings: [],
    };
  }

  const warnings: string[] = [];
  const contextBlocks: string[] = [];

  const { data: pdfRows, error: pdfRowsError } = await client
    .from("pdf_files")
    .select(
      `
        id,
        file_name,
        extracted_text,
        extracted_text_status,
        vector_index_status,
        vector_chunks_count
      `,
    )
    .eq("user_id", userId)
    .in("id", uniquePdfFileIds);

  if (pdfRowsError) {
    console.error("[governance/chat] Erro ao buscar PDFs selecionados:", pdfRowsError);
    return {
      selectedPdfFileIds: uniquePdfFileIds,
      pdfContextText: "",
      pdfContextAvailable: false,
      pdfContextWarnings: ["Não foi possível validar os PDFs selecionados."],
    };
  }

  const rowsById = new Map(
    ((pdfRows ?? []) as GovernancePdfFileRow[]).map((row) => [String(row.id), row]),
  );

  const maxCharsPerPdf = Math.max(
    900,
    Math.floor(MAX_GOVERNANCE_PDF_CONTEXT_CHARS / Math.max(1, uniquePdfFileIds.length)),
  );

  for (const pdfFileId of uniquePdfFileIds) {
    const pdf = rowsById.get(pdfFileId);
    const fileName = String(pdf?.file_name ?? "PDF selecionado");

    if (!pdf) {
      warnings.push(`PDF não encontrado ou sem permissão: ${pdfFileId}.`);
      continue;
    }

    const extractedStatus = String(pdf.extracted_text_status ?? "").toLowerCase();
    const vectorStatus = String(pdf.vector_index_status ?? "").toLowerCase();

    const vectorContext = await buildGovernancePdfContextFromVector(
      client,
      pdf,
      question,
      maxCharsPerPdf,
    );

    const extractedTextContext = vectorContext
      ? ""
      : buildGovernancePdfContextFromExtractedText(pdf, question, maxCharsPerPdf);

    const contextText = vectorContext || extractedTextContext;

    if (!contextText) {
      warnings.push(
        `Não encontrei trechos disponíveis no PDF "${fileName}". Status de texto: ${extractedStatus || "não informado"}. Status vetorial: ${vectorStatus || "não informado"}.`,
      );
      continue;
    }

    contextBlocks.push(
      [
        `PDF: ${fileName}`,
        `ID: ${pdfFileId}`,
        "",
        contextText,
      ].join("\n"),
    );
  }

  const pdfContextText = contextBlocks
    .join("\n\n---\n\n")
    .slice(0, MAX_GOVERNANCE_PDF_CONTEXT_CHARS);

  return {
    selectedPdfFileIds: uniquePdfFileIds,
    pdfContextText,
    pdfContextAvailable: pdfContextText.trim().length > 0,
    pdfContextWarnings: warnings,
  };
}


type InstitutionalDocumentContextRow = {
  id: string;
  title: string | null;
  document_type: string | null;
  source_url: string | null;
  storage_bucket: string | null;
  storage_path: string | null;
  extracted_text: string | null;
  indexing_status: string | null;
  review_status: string | null;
  indexed_at: string | null;
  updated_at: string | null;
};

type GovernanceChatSource = {
  id: string;
  title: string;
  url: string | null;
  type: string | null;
};

type GovernanceChatSources = {
  institutional: GovernanceChatSource[];
  officialGazette: GovernanceChatSource[];
  officialSources: GovernanceChatSource[];
};

type GovernanceChatReference = {
  title: string;
  url: string | null;
  kind: "institutional" | "official" | "legal";
};

function buildGovernanceChatReferences(
  sources: GovernanceChatSources,
): GovernanceChatReference[] {
  const unique = new Map<string, GovernanceChatReference>();

  function addReference(
    source: GovernanceChatSource,
    kind: GovernanceChatReference["kind"],
  ) {
    const title = String(source?.title ?? "").trim();
    const url = String(source?.url ?? "").trim() || null;

    if (!title) {
      return;
    }

    const key = `${kind}::${title.toLowerCase()}::${url ?? ""}`;

    if (!unique.has(key)) {
      unique.set(key, { title, url, kind });
    }
  }

  for (const source of sources.institutional ?? []) {
    addReference(source, "institutional");
  }

  for (const source of sources.officialSources ?? []) {
    addReference(source, "official");
  }

  for (const source of sources.officialGazette ?? []) {
    addReference(source, "official");
  }

  return Array.from(unique.values());
}


function normalizeGovernanceReferenceKey(reference: GovernanceChatReference) {
  const title = String(reference.title ?? "")
    .trim()
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\s+/g, " ");

  const normalizedTitle = title
    .replace(/lei\s*n?[º°]?\s*14\.?133\/?2021/g, "lei 14133 2021")
    .replace(/lei\s*14\.?133\/?2021/g, "lei 14133 2021")
    .replace(/decreto\s*(?:federal\s*)?n?[º°]?\s*12\.?807\/?2025/g, "decreto 12807 2025")
    .replace(/tribunal de contas do estado do parana.*tce\s*pr|tce\s*pr/g, "tce pr");

  return `${reference.kind}::${normalizedTitle}`;
}

function mergeGovernanceChatReferences(
  baseReferences: GovernanceChatReference[],
  additionalReferences: GovernanceChatReference[],
) {
  const merged = new Map<string, GovernanceChatReference>();

  for (const reference of [...baseReferences, ...additionalReferences]) {
    const title = String(reference.title ?? "").trim();
    const url = String(reference.url ?? "").trim() || null;

    if (!title) {
      continue;
    }

    const normalizedReference: GovernanceChatReference = {
      title,
      url,
      kind: reference.kind,
    };
    const key = normalizeGovernanceReferenceKey(normalizedReference);
    const existing = merged.get(key);

    if (!existing) {
      merged.set(key, normalizedReference);
      continue;
    }

    const existingHasUrl = Boolean(String(existing.url ?? "").trim());
    const incomingHasUrl = Boolean(url);
    const incomingIsRicher =
      incomingHasUrl && !existingHasUrl
        ? true
        : title.length > String(existing.title ?? "").trim().length;

    if (incomingIsRicher) {
      merged.set(key, {
        title: title.length >= String(existing.title ?? "").trim().length ? title : existing.title,
        url: incomingHasUrl ? url : existing.url,
        kind: reference.kind,
      });
    }
  }

  return Array.from(merged.values());
}

function normalizeOfficialLegalResolverText(value: string) {
  return String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();
}

type OfficialLegalResolverEntry = {
  title: string;
  url: string;
  triggers: string[];
};

const OFFICIAL_LEGAL_RESOLVER_ENTRIES: OfficialLegalResolverEntry[] = [
  {
    title: "Lei nº 14.133/2021 — Lei de Licitações e Contratos Administrativos",
    url: "https://www.planalto.gov.br/ccivil_03/_ato2019-2022/2021/lei/l14133.htm",
    triggers: [
      "14.133",
      "14133",
      "lei de licitacoes",
      "nova lei de licitacoes",
      "licitacao",
      "licitacoes",
      "contratacao direta",
      "dispensa",
      "inexigibilidade",
      "pregao",
      "art. 75",
      "artigo 75",
      "art. 74",
      "artigo 74",
    ],
  },
  {
    title: "Decreto Federal nº 12.807/2025 — Atualização dos valores da Lei nº 14.133/2021",
    url: "https://www.planalto.gov.br/ccivil_03/_ato2023-2026/2025/decreto/d12807.htm",
    triggers: [
      "12.807/2025",
      "12807/2025",
      "decreto federal 12.807",
      "decreto 12.807",
      "130.984,20",
      "65.492,11",
      "valores atualizados",
      "atualizacao dos valores",
      "atualização dos valores",
      "limites de dispensa",
    ],
  },
  {
    title: "Constituição Federal de 1988",
    url: "https://www.planalto.gov.br/ccivil_03/constituicao/constituicao.htm",
    triggers: [
      "constituicao",
      "constituicao federal",
      "cf/88",
      "art. 37",
      "artigo 37",
      "administracao publica",
      "principios da administracao",
      "concurso publico",
    ],
  },
  {
    title: "Lei Complementar nº 101/2000 — Lei de Responsabilidade Fiscal",
    url: "https://www.planalto.gov.br/ccivil_03/leis/lcp/lcp101.htm",
    triggers: [
      "lrf",
      "lei de responsabilidade fiscal",
      "responsabilidade fiscal",
      "despesa com pessoal",
      "limite de pessoal",
      "endividamento",
      "renuncia de receita",
      "rreo",
      "rgf",
    ],
  },
  {
    title: "Lei nº 12.527/2011 — Lei de Acesso à Informação",
    url: "https://www.planalto.gov.br/ccivil_03/_ato2011-2014/2011/lei/l12527.htm",
    triggers: [
      "lai",
      "lei de acesso a informacao",
      "acesso a informacao",
      "transparencia",
      "informacao publica",
      "pedido de informacao",
    ],
  },
  {
    title: "Lei nº 13.709/2018 — Lei Geral de Proteção de Dados Pessoais",
    url: "https://www.planalto.gov.br/ccivil_03/_ato2015-2018/2018/lei/l13709.htm",
    triggers: [
      "lgpd",
      "lei geral de protecao de dados",
      "protecao de dados",
      "dados pessoais",
      "tratamento de dados",
    ],
  },
  {
    title: "Lei nº 13.460/2017 — Participação, Proteção e Defesa dos Usuários de Serviços Públicos",
    url: "https://www.planalto.gov.br/ccivil_03/_ato2015-2018/2017/lei/l13460.htm",
    triggers: [
      "ouvidoria",
      "carta de servicos",
      "servicos publicos",
      "usuario de servico publico",
      "manifestacao de usuario",
    ],
  },
];

function buildOfficialLegalReferencesForGovernance(params: {
  question: string;
  answer: string;
  forceWebFirst: boolean;
}): GovernanceChatReference[] {
  const questionText = normalizeOfficialLegalResolverText(params.question);
  const answerText = normalizeOfficialLegalResolverText(params.answer);
  const combinedText = `${questionText}\n${answerText}`;

  const questionHasAny = (terms: string[]) =>
    terms.some((term) => questionText.includes(normalizeOfficialLegalResolverText(term)));
  const answerHasAny = (terms: string[]) =>
    terms.some((term) => answerText.includes(normalizeOfficialLegalResolverText(term)));
  const combinedHasAny = (terms: string[]) =>
    terms.some((term) => combinedText.includes(normalizeOfficialLegalResolverText(term)));

  const shouldResolve =
    params.forceWebFirst ||
    /\b(lei|decreto|art\.|artigo|inciso|paragrafo|licitacao|contratacao|dispensa|inexigibilidade|lrf|lai|lgpd|constituicao)\b/i.test(
      combinedText,
    );

  if (!shouldResolve) {
    return [];
  }

  return OFFICIAL_LEGAL_RESOLVER_ENTRIES.filter((entry) => {
    const title = normalizeOfficialLegalResolverText(entry.title);

    /*
      v9.4 — evita Base Legal contaminada por menções incidentais.
      Ex.: "Departamento Municipal de Licitação e Contratos" em resposta sobre
      estrutura administrativa não pode puxar automaticamente a Lei 14.133/2021.
    */
    if (title.includes("14 133") || title.includes("licitacoes")) {
      return (
        questionHasAny([
          "14.133",
          "14133",
          "licitacao",
          "licitacoes",
          "dispensa",
          "inexigibilidade",
          "pregao",
          "contratacao direta",
          "lei de licitacoes",
          "nova lei de licitacoes",
        ]) ||
        answerHasAny([
          "lei n 14.133",
          "lei 14.133",
          "14.133/2021",
          "lei de licitacoes",
          "nova lei de licitacoes",
          "contratacao direta",
          "dispensa de licitacao",
          "inexigibilidade",
        ])
      );
    }

    if (title.includes("12 807")) {
      return (
        questionHasAny(["12.807", "12807", "valores de dispensa", "limites de dispensa"]) ||
        answerHasAny(["decreto federal n 12.807", "decreto 12.807", "12.807/2025", "130.984,20", "65.492,11"])
      );
    }

    if (title.includes("constituicao federal")) {
      return combinedHasAny([
        "constituicao federal",
        "cf/88",
        "carta magna",
        "art. 37",
        "artigo 37",
        "art. 169",
        "artigo 169",
      ]);
    }

    return entry.triggers.some((trigger) =>
      combinedText.includes(normalizeOfficialLegalResolverText(trigger)),
    );
  })
    .slice(0, 6)
    .map((entry) => ({
      title: entry.title,
      url: entry.url,
      kind: "legal" as const,
    }));
}

function normalizeReferenceTextForMatch(value: unknown) {
  return String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

function referenceIncludesAny(text: string, terms: string[]) {
  return terms.some((term) => text.includes(normalizeReferenceTextForMatch(term)));
}

function getReferenceImportantTerms(reference: GovernanceChatReference) {
  const normalizedTitle = normalizeReferenceTextForMatch(reference.title);

  return normalizedTitle
    .split(" ")
    .filter((term) => term.length >= 5)
    .filter(
      (term) =>
        ![
          "municipio",
          "municipal",
          "santana",
          "itarare",
          "prefeitura",
          "gestao",
          "documento",
          "oficial",
        ].includes(term),
    );
}

function governanceReferenceAppearsInAnswer(
  reference: GovernanceChatReference,
  answer: string,
) {
  const normalizedAnswer = normalizeReferenceTextForMatch(answer);
  const normalizedTitle = normalizeReferenceTextForMatch(reference.title);
  const normalizedUrl = normalizeReferenceTextForMatch(reference.url);

  if (!normalizedTitle) {
    return false;
  }

  if (normalizedAnswer.includes(normalizedTitle)) {
    return true;
  }

  if (normalizedUrl && normalizedAnswer.includes(normalizedUrl)) {
    return true;
  }

  const terms = getReferenceImportantTerms(reference);

  if (terms.length === 0) {
    return false;
  }

  const requiredMatches = terms.length <= 2 ? terms.length : 2;
  const matches = terms.filter((term) => normalizedAnswer.includes(term)).length;

  return matches >= requiredMatches;
}

function isLicitationEvidenceQuestion(question: string, answer: string) {
  const text = normalizeReferenceTextForMatch(`${question} ${answer}`);

  return referenceIncludesAny(text, [
    "licitacao",
    "licitacoes",
    "dispensa",
    "inexigibilidade",
    "pregao",
    "contratacao direta",
    "contrato",
    "extrato de contrato",
    "lei 14 133",
  ]);
}

function isOfficialSourcesEvidenceQuestion(question: string, answer: string) {
  const text = normalizeReferenceTextForMatch(`${question} ${answer}`);

  return referenceIncludesAny(text, [
    "fontes oficiais",
    "fonte oficial",
    "canais oficiais",
    "canal oficial",
    "site oficial",
    "diario oficial",
    "portal de transparencia",
    "portal da transparencia",
  ]);
}

function isOfficialGazetteReference(reference: GovernanceChatReference) {
  const title = normalizeReferenceTextForMatch(reference.title);

  return reference.kind === "official" && referenceIncludesAny(title, [
    "diario oficial",
    "diário oficial",
    "edicao",
    "edição",
  ]);
}

function isLicitationConsultationOfficialReference(reference: GovernanceChatReference) {
  const title = normalizeReferenceTextForMatch(reference.title);

  return reference.kind === "official" && referenceIncludesAny(title, [
    "portal",
    "transparencia",
    "transparência",
    "betha",
    "betha contabil",
    "betha contábil",
    "site oficial",
    "licitacao",
    "licitações",
    "licitacoes",
    "contrato",
    "contratos",
  ]);
}

function shouldKeepGovernanceReferenceForClient(params: {
  reference: GovernanceChatReference;
  question: string;
  answer: string;
}) {
  const { reference, question, answer } = params;

  if (reference.kind === "legal") {
    return false;
  }

  if (governanceReferenceAppearsInAnswer(reference, answer)) {
    return true;
  }

  const title = normalizeReferenceTextForMatch(reference.title);

  if (isOfficialSourcesEvidenceQuestion(question, answer)) {
    return referenceIncludesAny(title, [
      "ata de posse",
      "codigo tributario",
      "código tributário",
      "lei organica",
      "lei orgânica",
      "diario oficial",
      "diário oficial",
      "portal",
      "transparencia",
      "transparência",
      "site oficial",
    ]);
  }

  if (isLicitationEvidenceQuestion(question, answer)) {
    return isOfficialGazetteReference(reference) || isLicitationConsultationOfficialReference(reference);
  }

  return false;
}

function filterGovernanceChatReferencesForClient(
  references: GovernanceChatReference[],
  options?: {
    question?: string;
    answer?: string;
  },
) {
  const question = String(options?.question ?? "");
  const answer = String(options?.answer ?? "");
  const unique = new Map<string, GovernanceChatReference>();

  for (const reference of references) {
    if (
      !shouldKeepGovernanceReferenceForClient({
        reference,
        question,
        answer,
      })
    ) {
      continue;
    }

    const title = String(reference.title ?? "").trim();
    const url = String(reference.url ?? "").trim() || null;

    if (!title) {
      continue;
    }

    const key = `${reference.kind}::${normalizeReferenceTextForMatch(title)}::${url ?? ""}`;

    if (!unique.has(key)) {
      unique.set(key, {
        ...reference,
        title,
        url,
      });
    }
  }

  const filtered = Array.from(unique.values());
  const officialGazetteReferences = filtered.filter(isOfficialGazetteReference);
  const licitationOfficialReferences = filtered.filter(
    (reference) =>
      !isOfficialGazetteReference(reference) &&
      isLicitationConsultationOfficialReference(reference),
  );
  const otherReferences = filtered.filter(
    (reference) =>
      !isOfficialGazetteReference(reference) &&
      !isLicitationConsultationOfficialReference(reference),
  );

  if (isLicitationEvidenceQuestion(question, answer)) {
    return [
      ...officialGazetteReferences.slice(0, 3),
      ...licitationOfficialReferences.slice(0, 3),
      ...otherReferences.slice(0, 2),
    ].slice(0, 6);
  }

  return filtered.slice(0, 6);
}


type InstitutionalContextResult = {
  contextText: string;
  matchedDocumentIds: string[];
  matchedDocumentTitles: string[];
  sources: GovernanceChatSource[];
  warnings: string[];
};

function isInstitutionalDocumentAvailable(row: InstitutionalDocumentContextRow) {
  const extractedText = String(row.extracted_text ?? "").trim();
  if (!extractedText) {
    return false;
  }

  const indexingStatus = String(row.indexing_status ?? "")
    .trim()
    .toLowerCase();

  if (
    indexingStatus &&
    ![
      "indexed",
      "indexado",
      "processed",
      "completed",
      "success",
      "ready",
    ].includes(indexingStatus)
  ) {
    return false;
  }

  const reviewStatus = String(row.review_status ?? "")
    .trim()
    .toLowerCase();

  if (reviewStatus !== "approved") {
    return false;
  }

  return true;
}

function getInstitutionalDocumentTypeLabel(value: string | null | undefined) {
  const normalized = String(value ?? "")
    .trim()
    .toLowerCase();

  const labels: Record<string, string> = {
    ata: "Ata",
    codigo: "Código",
    contrato: "Contrato",
    decreto: "Decreto",
    decreto_consolidado: "Decreto",
    edital: "Edital",
    estatuto: "Estatuto",
    instrucao_normativa: "Instrução Normativa",
    lei: "Lei",
    lei_organica: "Lei",
    manual: "Manual",
    norma_interna: "Instrução Normativa",
    organograma: "Organograma",
    outro: "Outro",
    parecer: "Parecer Jurídico",
    parecer_juridico: "Parecer Jurídico",
    parecer_modelo: "Parecer Jurídico",
    plano: "Plano",
    portaria: "Portaria",
    recomendacoes_mp: "Recomendações do MP",
    regulamento: "Regulamento",
    resolucao: "Resolução",
  };

  return labels[normalized] ?? "Documento institucional";
}


async function createInstitutionalStorageSignedUrl(params: {
  client: ReturnType<typeof createWritableSupabaseRouteClient>;
  storageBucket: string;
  storagePath: string;
}) {
  const { client, storageBucket, storagePath } = params;

  const { data: signedByUserClient, error: userClientError } = await client.storage
    .from(storageBucket)
    .createSignedUrl(storagePath, 60 * 60 * 24);

  const signedUrlByUserClient = String(
    signedByUserClient?.signedUrl ?? "",
  ).trim();

  if (!userClientError && signedUrlByUserClient) {
    return signedUrlByUserClient;
  }

  const serviceRoleClient = createServiceRoleSupabaseClient();

  if (!serviceRoleClient) {
    console.warn(
      "[governance/chat] Não foi possível gerar URL assinada do Storage: SUPABASE_SERVICE_ROLE_KEY ausente.",
      {
        storageBucket,
        storagePath,
        userClientError: userClientError?.message ?? null,
      },
    );

    return null;
  }

  const { data: signedByServiceRole, error: serviceRoleError } =
    await serviceRoleClient.storage
      .from(storageBucket)
      .createSignedUrl(storagePath, 60 * 60 * 24);

  const signedUrlByServiceRole = String(
    signedByServiceRole?.signedUrl ?? "",
  ).trim();

  if (!serviceRoleError && signedUrlByServiceRole) {
    return signedUrlByServiceRole;
  }

  console.warn(
    "[governance/chat] Não foi possível gerar URL assinada do Storage.",
    {
      storageBucket,
      storagePath,
      userClientError: userClientError?.message ?? null,
      serviceRoleError: serviceRoleError?.message ?? null,
    },
  );

  return null;
}

async function resolveInstitutionalDocumentUrl(
  client: ReturnType<typeof createWritableSupabaseRouteClient>,
  document: InstitutionalDocumentContextRow,
) {
  const sourceUrl = String(document.source_url ?? "").trim();

  if (/^https?:\/\//i.test(sourceUrl)) {
    return sourceUrl;
  }

  const storageBucket = String(document.storage_bucket ?? "").trim();
  const storagePath = String(document.storage_path ?? "").trim();

  if (storageBucket && storagePath) {
    const signedUrl = await createInstitutionalStorageSignedUrl({
      client,
      storageBucket,
      storagePath,
    });

    if (signedUrl) {
      return signedUrl;
    }
  }

  const normalizedTitle = normalizeInstitutionalSearchText(document.title);
  if (
    normalizedTitle.includes("lei estadual") &&
    (normalizedTitle.includes("cria") || normalizedTitle.includes("criacao")) &&
    normalizedTitle.includes("municipio")
  ) {
    return "https://www.legislacao.pr.gov.br/legislacao/pesquisarAto.do?action=exibir&codAto=12935&indice=1&totalRegistros=1";
  }

  return null;
}

async function buildInstitutionalSource(
  client: ReturnType<typeof createWritableSupabaseRouteClient>,
  document: InstitutionalDocumentContextRow,
): Promise<GovernanceChatSource> {
  const title =
    String(document.title ?? "").trim() ||
    "Documento institucional sem título";

  return {
    id: document.id,
    title,
    url: await resolveInstitutionalDocumentUrl(client, document),
    type: getInstitutionalDocumentTypeLabel(document.document_type),
  };
}


const INSTITUTIONAL_STOP_WORDS = new Set([
  "a",
  "as",
  "o",
  "os",
  "e",
  "em",
  "de",
  "da",
  "das",
  "do",
  "dos",
  "para",
  "por",
  "com",
  "sem",
  "sobre",
  "qual",
  "quais",
  "onde",
  "posso",
  "pode",
  "tem",
  "possui",
  "existe",
  "existem",
  "municipio",
  "municipal",
  "municipais",
  "prefeitura",
  "santana",
  "itarare",
  "pr",
  "publicado",
  "publicada",
  "consultar",
  "encontrar",
  "localizar",
]);

function normalizeInstitutionalSearchText(value: string | null | undefined) {
  return String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function getInstitutionalSearchTokens(value: string) {
  return normalizeInstitutionalSearchText(value)
    .split(" ")
    .map((token) => token.trim())
    .filter((token) => token.length >= 3 && !INSTITUTIONAL_STOP_WORDS.has(token));
}

function getInstitutionalQueryPhrases(question: string) {
  const q = normalizeInstitutionalSearchText(question);
  const phrases: string[] = [];

  const phraseRules = [
    "ata de posse",
    "gestao 2025 2028",
    "plano diretor",
    "lei organica",
    "codigo tributario",
    "sistema tributario",
    "estatuto dos servidores",
    "estatuto servidor",
    "servidores municipais",
    "portal transparencia",
    "diario oficial",
    "fontes oficiais",
  ];

  for (const phrase of phraseRules) {
    if (q.includes(phrase)) {
      phrases.push(phrase);
    }
  }

  return phrases;
}

function isLocalOfficeHolderQuestion(question: string) {
  const q = normalizeInstitutionalSearchText(question);

  if (!q) {
    return false;
  }

  const asksPerson =
    /\b(quem|qual|quais|nome|nomes|identifique|informe)\b/.test(q);

  const hasLocalOffice =
    /\b(prefeito|prefeita|vice prefeito|vice prefeita|viceprefeito|viceprefeita|secretario|secretaria|presidente da camara|vereador|vereadora|tomou posse|posse|empossado|empossada|mandato)\b/.test(q);

  return asksPerson && hasLocalOffice;
}

function scoreLocalOfficeHolderDocument(
  document: InstitutionalDocumentContextRow,
  question: string,
) {
  if (!isLocalOfficeHolderQuestion(question)) {
    return 0;
  }

  const q = normalizeInstitutionalSearchText(question);
  const title = normalizeInstitutionalSearchText(document.title);
  const type = normalizeInstitutionalSearchText(document.document_type);
  const text = normalizeInstitutionalSearchText(
    String(document.extracted_text ?? "").slice(0, 60000),
  );

  let score = 0;

  if (title.includes("ata") && title.includes("posse")) score += 180;
  if (title.includes("posse")) score += 120;
  if (title.includes("gestao") && /\b2025\b/.test(title)) score += 90;
  if (type.includes("ata")) score += 80;

  if (/\b(prefeito|prefeita)\b/.test(q) && /\b(prefeito|prefeita)\b/.test(text)) {
    score += 120;
  }

  if (/\bvice\b/.test(q) && /\bvice prefeito|vice prefeita|viceprefeito|viceprefeita\b/.test(text)) {
    score += 130;
  }

  if (/\b(posse|tomou posse|empossado|empossada)\b/.test(q) && /\b(posse|empossad[oa]s?|mandato)\b/.test(text)) {
    score += 100;
  }

  if (/\b2025\b/.test(q) && /\b2025\b/.test(text)) {
    score += 45;
  }

  if (/\b2028\b/.test(q) && /\b2028\b/.test(text)) {
    score += 35;
  }

  return score;
}


function isMunicipalCreationLawQuestion(question: string) {
  const q = normalizeInstitutionalSearchText(question);

  return (
    /\blei\b/.test(q) &&
    (q.includes("cria") || q.includes("criacao") || q.includes("criação")) &&
    (q.includes("municipio") || q.includes("município"))
  );
}

function isAdministrativeStructureQuestion(question: string) {
  const q = normalizeInstitutionalSearchText(question);

  return (
    (q.includes("estrutura") && (q.includes("administrativa") || q.includes("administracao"))) ||
    q.includes("organograma") ||
    (q.includes("secretaria") && q.includes("municipal"))
  );
}

function isCareerProgressionQuestion(question: string) {
  const q = normalizeInstitutionalSearchText(question);

  return (
    q.includes("progressao") ||
    q.includes("progressão") ||
    q.includes("intersticio") ||
    q.includes("interstício") ||
    q.includes("carreira") ||
    q.includes("referencia") ||
    q.includes("referência")
  );
}

function isCreationLawDocument(document: InstitutionalDocumentContextRow) {
  const title = normalizeInstitutionalSearchText(document.title);
  const type = normalizeInstitutionalSearchText(document.document_type);
  const text = normalizeInstitutionalSearchText(String(document.extracted_text ?? "").slice(0, 5000));

  return (
    title.includes("lei estadual") &&
    (title.includes("cria") || title.includes("criacao")) &&
    (title.includes("municipio") || title.includes("município") || text.includes("santana do itarare"))
  ) || (
    type.includes("lei") &&
    text.includes("santana do itarare") &&
    (text.includes("cria") || text.includes("criado") || text.includes("criacao"))
  );
}

function isAdministrativeStructureDocument(document: InstitutionalDocumentContextRow) {
  const title = normalizeInstitutionalSearchText(document.title);
  const type = normalizeInstitutionalSearchText(document.document_type);
  const text = normalizeInstitutionalSearchText(String(document.extracted_text ?? "").slice(0, 15000));

  const positive =
    title.includes("estrutura administrativa") ||
    title.includes("administrativa da prefeitura") ||
    text.includes("estrutura administrativa") ||
    text.includes("administracao direta") ||
    text.includes("administração direta");

  const negative =
    title.includes("codigo tributario") ||
    title.includes("código tributário") ||
    title.includes("plano de cargos") ||
    title.includes("carreiras") ||
    title.includes("vencimentos") ||
    title.includes("plano diretor") ||
    title.includes("lei organica") ||
    title.includes("lei orgânica") ||
    type.includes("contrato");

  return positive && !negative;
}

function isCareerProgressionDocument(document: InstitutionalDocumentContextRow) {
  const title = normalizeInstitutionalSearchText(document.title);
  const text = normalizeInstitutionalSearchText(String(document.extracted_text ?? "").slice(0, 15000));

  const positive =
    title.includes("plano de cargos") ||
    title.includes("carreira") ||
    title.includes("carreiras") ||
    title.includes("vencimentos") ||
    title.includes("estatuto") ||
    text.includes("progressao horizontal") ||
    text.includes("progressão horizontal");

  const negative =
    title.includes("lei estadual") && (title.includes("cria") || title.includes("criacao")) ||
    title.includes("plano diretor") ||
    title.includes("codigo tributario") ||
    title.includes("estrutura administrativa");

  return positive && !negative;
}

function getInstitutionalQuestionGuard(question: string) {
  if (isMunicipalCreationLawQuestion(question)) {
    return {
      kind: "creation-law",
      maxDocuments: 1,
      accepts: isCreationLawDocument,
    };
  }

  if (isAdministrativeStructureQuestion(question)) {
    return {
      kind: "administrative-structure",
      maxDocuments: 1,
      accepts: isAdministrativeStructureDocument,
    };
  }

  if (isCareerProgressionQuestion(question)) {
    return {
      kind: "career-progression",
      maxDocuments: 2,
      accepts: isCareerProgressionDocument,
    };
  }

  return null;
}

function getInstitutionalDocumentPriorityBoost(
  document: InstitutionalDocumentContextRow,
  question: string,
) {
  if (isMunicipalCreationLawQuestion(question) && isCreationLawDocument(document)) {
    return 240;
  }

  if (isAdministrativeStructureQuestion(question) && isAdministrativeStructureDocument(document)) {
    return 220;
  }

  if (isCareerProgressionQuestion(question) && isCareerProgressionDocument(document)) {
    return 180;
  }

  return 0;
}


function scoreInstitutionalDocumentForQuestion(
  document: InstitutionalDocumentContextRow,
  question: string,
) {
  const q = normalizeInstitutionalSearchText(question);
  const title = normalizeInstitutionalSearchText(document.title);
  const type = normalizeInstitutionalSearchText(document.document_type);
  const text = normalizeInstitutionalSearchText(
    String(document.extracted_text ?? "").slice(0, 30000),
  );

  if (!q || !title) {
    return 0;
  }

  let score = 0;
  const queryTokens = getInstitutionalSearchTokens(question);
  const titleTokens = new Set(getInstitutionalSearchTokens(title));
  const phrases = getInstitutionalQueryPhrases(question);

  if (q.length >= 6 && (title.includes(q) || q.includes(title))) {
    score += 180;
  }

  for (const phrase of phrases) {
    if (title.includes(phrase)) {
      score += 170;
    }

    if (type.includes(phrase)) {
      score += 60;
    }

    if (text.includes(phrase)) {
      score += 18;
    }
  }

  for (const token of queryTokens) {
    if (titleTokens.has(token) || title.includes(token)) {
      score += 28;
    } else if (type.includes(token)) {
      score += 12;
    } else if (text.includes(token)) {
      score += 3;
    }
  }

  const matchedTitleTokens = queryTokens.filter(
    (token) => titleTokens.has(token) || title.includes(token),
  );

  if (queryTokens.length >= 2 && matchedTitleTokens.length >= 2) {
    score += 70;
  }

  if (queryTokens.length >= 3 && matchedTitleTokens.length >= queryTokens.length - 1) {
    score += 60;
  }

  if (/\bata\b/.test(q) && title.includes("ata")) {
    score += 90;
  }

  if (/\bposse\b/.test(q) && title.includes("posse")) {
    score += 90;
  }

  if (/\bplano\b/.test(q) && /\bdiretor\b/.test(q) && title.includes("plano") && title.includes("diretor")) {
    score += 130;
  }

  if (/\bestatuto\b/.test(q) && title.includes("estatuto")) {
    score += 120;
  }

  if (/\blei\b/.test(q) && /\borganica\b/.test(q) && title.includes("lei") && title.includes("organica")) {
    score += 130;
  }

  if (/\bcodigo\b/.test(q) && /\btributario\b/.test(q) && title.includes("codigo") && title.includes("tributario")) {
    score += 130;
  }

  score += scoreLocalOfficeHolderDocument(document, question);
  score += getInstitutionalDocumentPriorityBoost(document, question);

  return score;
}

function selectRelevantInstitutionalDocuments(
  rows: InstitutionalDocumentContextRow[],
  question: string,
) {
  const isOfficeHolderQuestion = isLocalOfficeHolderQuestion(question);
  const guard = getInstitutionalQuestionGuard(question);
  const minimumScore = isOfficeHolderQuestion ? 18 : guard ? 45 : 28;

  let ranked = rows
    .map((document) => ({
      document,
      score: scoreInstitutionalDocumentForQuestion(document, question),
    }))
    .filter((item) => item.score >= minimumScore)
    .sort((a, b) => b.score - a.score);

  if (guard) {
    const guarded = ranked.filter((item) => guard.accepts(item.document));

    if (guarded.length > 0) {
      return guarded.slice(0, guard.maxDocuments);
    }

    return [];
  }

  if (ranked.length === 0) {
    return [];
  }

  const topScore = ranked[0]?.score ?? 0;
  const minScore = Math.max(
    minimumScore,
    topScore >= 120 ? topScore * 0.65 : minimumScore,
  );
  const maxDocuments = isOfficeHolderQuestion ? 4 : topScore >= 120 ? 1 : 3;

  return ranked
    .filter((item) => item.score >= minScore)
    .slice(0, maxDocuments);
}


async function buildInstitutionalDocumentsContext(params: {
  client: ReturnType<typeof createWritableSupabaseRouteClient>;
  organizationId: string;
  question: string;
}): Promise<InstitutionalContextResult> {
  const { client, organizationId, question } = params;

  const { data, error } = await client
    .from("institutional_documents")
    .select(
      `
        id,
        title,
        document_type,
        source_url,
        storage_bucket,
        storage_path,
        extracted_text,
        indexing_status,
        review_status,
        indexed_at,
        updated_at
      `,
    )
    .eq("organization_id", organizationId)
    .not("extracted_text", "is", null)
    .order("updated_at", { ascending: false })
    .limit(MAX_INSTITUTIONAL_DOCUMENTS);

  if (error) {
    console.warn(
      "[governance/chat] Não foi possível carregar Base Institucional:",
      error,
    );

    return {
      contextText: "",
      matchedDocumentIds: [],
      matchedDocumentTitles: [],
      sources: [],
      warnings: ["Não foi possível consultar a Base Institucional."],
    };
  }

  const rows = ((data ?? []) as InstitutionalDocumentContextRow[]).filter(
    isInstitutionalDocumentAvailable,
  );

  const candidateDocuments = selectRelevantInstitutionalDocuments(rows, question);

  if (candidateDocuments.length === 0) {
    return {
      contextText: "",
      matchedDocumentIds: [],
      matchedDocumentTitles: [],
      sources: [],
      warnings: [],
    };
  }

  const selected: Array<{
    document: InstitutionalDocumentContextRow;
    documentScore: number;
    chunkIndex: number;
    text: string;
  }> = [];

  for (const candidate of candidateDocuments) {
    const document = candidate.document;
    const text = normalizePdfText(document.extracted_text ?? "");

    if (!text) {
      continue;
    }

    const chunks = chunkText(text, {
      chunkSize: 1400,
      overlap: 180,
      maxChunks: 250,
    });

    const relevantChunks = pickRelevantChunks(chunks, question, {
      maxChunks: candidate.score >= 120 ? 10 : 4,
      maxChars: candidate.score >= 120 ? 18000 : 7000,
      minScore: candidate.score >= 120 ? 0 : 1,
    });

    const chunksToUse =
      relevantChunks.length > 0
        ? relevantChunks
        : candidate.score >= 120
          ? chunks.slice(0, 2).map((chunk) => ({
              index: chunk.index,
              text: chunk.text,
              score: candidate.score,
            }))
          : [];

    for (const chunk of chunksToUse) {
      selected.push({
        document,
        documentScore: candidate.score,
        chunkIndex: chunk.index,
        text: clampText(chunk.text, candidate.score >= 120 ? 3500 : 2200),
      });
    }

    if (selected.length >= MAX_INSTITUTIONAL_SELECTED_CHUNKS) {
      break;
    }
  }

  if (selected.length === 0) {
    return {
      contextText: "",
      matchedDocumentIds: [],
      matchedDocumentTitles: [],
      sources: [],
      warnings: [],
    };
  }

  const selectedDocumentsById = new Map<string, InstitutionalDocumentContextRow>();

  for (const item of selected) {
    if (!selectedDocumentsById.has(item.document.id)) {
      selectedDocumentsById.set(item.document.id, item.document);
    }
  }

  const matchedDocumentIds = Array.from(selectedDocumentsById.keys());

  const matchedDocumentTitles = Array.from(selectedDocumentsById.values()).map(
    (document) =>
      String(document.title ?? "").trim() ||
      "Documento institucional sem título",
  );

  const sources = await Promise.all(
    Array.from(selectedDocumentsById.values()).map((document) =>
      buildInstitutionalSource(client, document),
    ),
  );

  let usedChars = 0;
  const blocks: string[] = [];

  for (const [index, item] of selected.entries()) {
    const title =
      String(item.document.title ?? "").trim() ||
      "Documento institucional sem título";

    const documentTypeLabel = getInstitutionalDocumentTypeLabel(
      item.document.document_type,
    );

    const sourceUrl = await resolveInstitutionalDocumentUrl(client, item.document);

    const block = [
      `[Base Institucional - Trecho ${index + 1}]`,
      `Documento: ${title}`,
      `Tipo: ${documentTypeLabel}`,
      `Relevância interna: ${item.documentScore}`,
      `document_id: ${item.document.id}`,
      `chunk_index: ${item.chunkIndex}`,
      sourceUrl ? `Link da fonte: ${sourceUrl}` : "",
      "",
      item.text,
    ]
      .filter(Boolean)
      .join("\n");

    if (usedChars + block.length > MAX_INSTITUTIONAL_CONTEXT_CHARS) {
      break;
    }

    blocks.push(block);
    usedChars += block.length;
  }

  if (blocks.length === 0) {
    return {
      contextText: "",
      matchedDocumentIds,
      matchedDocumentTitles,
      sources,
      warnings: [],
    };
  }

  const contextText = [
    "BASE INSTITUCIONAL DA ORGANIZAÇÃO",
    "",
    "Prioridade máxima: use estes trechos antes do Diário Oficial, das Fontes Oficiais e do conhecimento geral.",
    "Use somente os documentos institucionais listados nos trechos abaixo para responder sobre Base Institucional.",
    "Quando responder com base nestes trechos, mencione o documento institucional utilizado pelo título, sem criar link manual no corpo da resposta.",
    "Não inclua seção 'Base institucional' no texto da resposta; o sistema exibirá essa fonte de forma estruturada e clicável abaixo da resposta.",
    "Não misture documentos da Base Institucional com a seção 'Base legal'. Não use o termo 'Base legal' para documentos cadastrados; documentos cadastrados ficam exclusivamente nas referências estruturadas da interface.",
    "Não escreva frases como 'Não houve consulta web nesta resposta'. Se não houver referência oficial específica, simplesmente omita essa observação.",
    "Não invente conteúdo ausente. Se os trechos forem insuficientes, diga que a Base Institucional não trouxe informação suficiente.",
    "Nunca declare que um documento institucional recuperado está errado apenas com base em memória do modelo. Se o documento foi selecionado pelo sistema, trate-o como fonte institucional cadastrada.",
    "Não crie links no corpo da resposta. Cite o nome do documento em texto simples; o link oficial será exibido abaixo em 'Fontes consultadas'.",
    "",
    ...blocks,
  ].join("\n");

  return {
    contextText,
    matchedDocumentIds,
    matchedDocumentTitles,
    sources,
    warnings: [],
  };
}


function normalizeContent(content: string) {
  return content.trim().slice(0, MAX_USER_MESSAGE_LENGTH);
}


function normalizeAdministrativeText(value: string) {
  return String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();
}

function isObjectiveAdministrativeQuestion(userText: string) {
  const q = normalizeAdministrativeText(userText);

  if (!q.trim()) {
    return false;
  }

  const asksObjectiveData =
    /\b(qual|quais|quanto|quantos|quando|prazo|valor|limite|teto|percentual|porcentagem|requisito|documento|documentos|competencia|competência)\b/.test(q);

  const hasAdministrativeTheme =
    /\b(dispensa|licitacao|licitação|contrato|contratacao|contratação|ata|carona|reajuste|repactuacao|repactuação|sancao|sanção|lrf|prudencial|pessoal|irrf|tributo|tributario|tributário|contabil|contábil|orcamentaria|orçamentária|estagio|estágio|diaria|diária|empenho|liquidacao|liquidação|pagamento|lei|decreto|portaria|municipio|município|executivo|legislativo)\b/.test(q);

  return asksObjectiveData && hasAdministrativeTheme;
}


type ConversationRelation =
  | "INICIAL"
  | "CONTINUA"
  | "CONTINUA_COMPLEMENTAR"
  | "RELACIONA"
  | "ROMPE";

const GOVERNANCE_CONTEXT_DOMAINS: Record<string, RegExp> = {
  fiscal_arrecadacao:
    /\b(arrecadacao|arrecadação|receita|tributo|tributario|tributária|imposto|iptu|iss|itbi|taxa|taxas|divida ativa|dívida ativa|contribuinte|cadastro imobiliario|cadastro imobiliário|cadastro mobiliario|cadastro mobiliário|cobranca|cobrança|inadimplencia|inadimplência|refis|pgv|planta generica|planta genérica|inteligencia de dados|inteligência de dados|dados fiscais|gestao fiscal|gestão fiscal)\b/,
  transparencia:
    /\b(transparencia|transparência|portal da transparencia|portal da transparência|lai|lei de acesso|acesso a informacao|acesso à informação|contas publicas|contas públicas|sic|e-sic|controle social|audiencia publica|audiência pública|dados abertos)\b/,
  contratacoes:
    /\b(licitacao|licitação|licitacoes|licitações|contratacao|contratação|contratacoes|contratações|contrato|contratos|pca|plano de contratacoes|plano de contratações|etp|estudo tecnico preliminar|estudo técnico preliminar|termo de referencia|termo de referência|tr|matriz de riscos|dispensa|inexigibilidade|pregao|pregão|ata de registro|carona|reajuste|repactuacao|repactuação)\b/,
  pessoal_rh:
    /\b(servidor|servidores|ferias|férias|decimo terceiro|décimo terceiro|13o|13º|folha|remuneracao|remuneração|vencimento|cargo|concurso|admissao|admissão|contratacao temporaria|contratação temporária|estatutario|estatutário|rh|recursos humanos)\b/,
  lrf_pessoal:
    /\b(lrf|lei de responsabilidade fiscal|limite prudencial|limite maximo|limite máximo|despesa com pessoal|rcl|receita corrente liquida|receita corrente líquida|gasto com pessoal)\b/,
  contabilidade:
    /\b(contabilidade|contabil|contábil|orcamento|orçamento|orcamentaria|orçamentária|empenho|liquidacao|liquidação|pagamento|dotacao|dotação|gnd|elemento de despesa|restos a pagar|balanco|balanço)\b/,
  controle_interno:
    /\b(controle interno|auditoria|conformidade|governanca|governança|risco|riscos|responsabilizacao|responsabilização|tce|tribunal de contas|ministerio publico|ministério público)\b/,
  urbanismo:
    /\b(plano diretor|zoneamento|uso do solo|parcelamento do solo|mobilidade urbana|cidade|urbanismo|habite-se|alvara de construcao|alvará de construção|obra particular)\b/,
  lgpd:
    /\b(lgpd|dados pessoais|proteção de dados|protecao de dados|encarregado de dados|dpo|privacidade)\b/,
};

const RELATED_CONTEXT_DOMAIN_PAIRS = new Set([
  "fiscal_arrecadacao::transparencia",
  "transparencia::fiscal_arrecadacao",
  "fiscal_arrecadacao::contabilidade",
  "contabilidade::fiscal_arrecadacao",
  "fiscal_arrecadacao::controle_interno",
  "controle_interno::fiscal_arrecadacao",
  "transparencia::controle_interno",
  "controle_interno::transparencia",
  "transparencia::contratacoes",
  "contratacoes::transparencia",
  "contratacoes::controle_interno",
  "controle_interno::contratacoes",
  "contratacoes::contabilidade",
  "contabilidade::contratacoes",
  "pessoal_rh::lrf_pessoal",
  "lrf_pessoal::pessoal_rh",
  "lrf_pessoal::contabilidade",
  "contabilidade::lrf_pessoal",
]);

function detectGovernanceContextDomains(text: string) {
  const normalized = normalizeAdministrativeText(text);
  const domains: string[] = [];

  for (const [domain, pattern] of Object.entries(GOVERNANCE_CONTEXT_DOMAINS)) {
    if (pattern.test(normalized)) {
      domains.push(domain);
    }
  }

  return domains;
}

function hasExplicitContinuationCue(userText: string) {
  const q = normalizeAdministrativeText(userText);

  return /\b(para isso|sobre isso|nesse caso|neste caso|nesse contexto|neste contexto|com base nisso|diante disso|a partir disso|essas medidas|essas acoes|essas ações|isso|esse tema|essa situacao|essa situação|e como|e quais|e qual|qual a diferenca|qual a diferença|quais medidas|proximo passo|próximo passo|como mensurar|como acompanhar|como implementar)\b/.test(q);
}

function isComplementaryContinuationQuestion(userText: string) {
  const q = normalizeAdministrativeText(userText);

  if (!q.trim()) {
    return false;
  }

  const asksMeasurementOrFollowUp =
    /\b(como medir|como mensurar|como acompanhar|como monitorar|como avaliar|como verificar|como controlar|como saber se|como demonstrar|como comprovar|quais indicadores|quais metricas|quais métricas|quais kpis|indicadores|metricas|métricas|resultados|metas|painel|dashboard|relatorio|relatório)\b/.test(q);

  const refersToPreviousActions =
    /\b(essas medidas|essas acoes|essas ações|esses pontos|essas providencias|essas providências|isso|desse plano|deste plano|da estrategia|da estratégia|do que foi dito|do que foi discutido|na pratica|na prática)\b/.test(q);

  return asksMeasurementOrFollowUp || refersToPreviousActions;
}

function classifyConversationRelation(params: {
  previousUserQuestion: string;
  currentUserQuestion: string;
}): ConversationRelation {
  const previous = params.previousUserQuestion.trim();
  const current = params.currentUserQuestion.trim();

  if (!previous) {
    return "INICIAL";
  }

  const isComplementary = isComplementaryContinuationQuestion(current);

  if (hasExplicitContinuationCue(current)) {
    return isComplementary ? "CONTINUA_COMPLEMENTAR" : "CONTINUA";
  }

  const previousDomains = detectGovernanceContextDomains(previous);
  const currentDomains = detectGovernanceContextDomains(current);

  if (previousDomains.length === 0 || currentDomains.length === 0) {
    return "ROMPE";
  }

  const previousDomainSet = new Set(previousDomains);

  if (currentDomains.some((domain) => previousDomainSet.has(domain))) {
    return isComplementary ? "CONTINUA_COMPLEMENTAR" : "CONTINUA";
  }

  const hasRelatedDomain = previousDomains.some((previousDomain) =>
    currentDomains.some((currentDomain) =>
      RELATED_CONTEXT_DOMAIN_PAIRS.has(`${previousDomain}::${currentDomain}`),
    ),
  );

  return hasRelatedDomain ? "RELACIONA" : "ROMPE";
}

function getPreviousUserQuestion(
  history: GovernanceMessage[],
  currentUserMessageId: string,
) {
  return [...history]
    .reverse()
    .find(
      (message) =>
        message.role === "user" &&
        message.id !== currentUserMessageId &&
        String(message.content ?? "").trim().length > 0,
    )?.content ?? "";
}

function buildConversationRelationInstruction(params: {
  relation: ConversationRelation;
  previousUserQuestion: string;
  currentUserQuestion: string;
}) {
  const previousQuestion = clampText(params.previousUserQuestion, 600);
  const currentQuestion = clampText(params.currentUserQuestion, 600);

  const base = [
    "CLASSIFICAÇÃO DA RELAÇÃO ENTRE PERGUNTAS",
    "",
    `Resultado: ${params.relation}.`,
    previousQuestion ? `Pergunta anterior do usuário: ${previousQuestion}` : "Pergunta anterior do usuário: não identificada.",
    `Pergunta atual do usuário: ${currentQuestion}`,
    "",
    "A pergunta atual continua sendo a prioridade absoluta da resposta.",
    "Use esta classificação para controlar continuidade, repetição e tamanho da resposta.",
    "",
  ];

  if (params.relation === "CONTINUA_COMPLEMENTAR") {
    return [
      ...base,
      "REGRA PARA CONTINUIDADE COMPLEMENTAR",
      "- A pergunta atual é um complemento do tema anterior, geralmente pedindo medição, acompanhamento, indicadores, metas, verificação ou próximos controles.",
      "- Responda apenas ao aspecto específico perguntado agora.",
      "- Não redefina conceitos já explicados.",
      "- Não reapresente contexto amplo.",
      "- Não recrie listas gerais já apresentadas em respostas anteriores.",
      "- Não escreva uma nova consultoria completa.",
      "- Comece diretamente com a resposta prática.",
      "- A resposta deve ser completa o suficiente para resolver o pedido atual, sem cortes artificiais.",
      "- Não aplique limite artificial de palavras. Responda com o detalhamento necessário para resolver o pedido.",
      "- Use no máximo 6 itens principais.",
      "- Se a pergunta pedir indicadores, métricas, monitoramento ou avaliação, entregue os indicadores diretamente no início.",
      "- Não inclua Base legal ou Referências oficiais nesse tipo de follow-up, salvo pedido expresso ou risco jurídico direto.",
      "- Feche com uma orientação prática de aplicação para o gestor em uma única frase.",
    ].join("\n");
  }

  if (params.relation === "CONTINUA") {
    return [
      ...base,
      "REGRA PARA CONTINUIDADE FORTE",
      "- A pergunta atual aprofunda ou desdobra o tema anterior.",
      "- Não redefina conceitos já explicados, salvo se for indispensável em uma frase curta.",
      "- Não repita listas gerais, fundamentos amplos ou blocos já apresentados.",
      "- Comece conectando em no máximo 1 frase e avance para o próximo passo prático.",
      "- A resposta deve ser mais complementar e mais enxuta que uma resposta inicial.",
      "- Foque no novo recorte pedido pelo usuário.",
    ].join("\n");
  }

  if (params.relation === "RELACIONA") {
    return [
      ...base,
      "REGRA PARA TEMA RELACIONADO",
      "- A pergunta atual tem relação com a trajetória da conversa, mas não é o mesmo tema.",
      "- Faça uma ponte curta, de no máximo 1 frase, se isso ajudar.",
      "- Depois responda o novo foco normalmente.",
      "- Não recapitule os temas anteriores.",
      "- Não transforme a resposta em plano integrado salvo pedido expresso do usuário.",
    ].join("\n");
  }

  if (params.relation === "ROMPE") {
    return [
      ...base,
      "REGRA PARA RUPTURA DE TEMA",
      "- A pergunta atual iniciou um novo assunto.",
      "- Não mencione, não recapitule e não responda temas anteriores.",
      "- Ignore a trajetória anterior, salvo se o usuário pedir comparação ou relação expressamente.",
      "- Responda exclusivamente ao novo assunto.",
    ].join("\n");
  }

  return [
    ...base,
    "REGRA PARA PRIMEIRA PERGUNTA OU CONTEXTO INICIAL",
    "- Responda normalmente, sem tentar conectar com histórico inexistente.",
  ].join("\n");
}

function buildForcedExecutiveFollowUpInstruction(params: {
  relation: ConversationRelation;
  mode: GovernanceResponseMode;
}) {
  if (params.mode !== "objective" || params.relation !== "CONTINUA_COMPLEMENTAR") {
    return "";
  }

  return [
    "PRIORIDADE MÁXIMA — FOLLOW-UP EXECUTIVO",
    "",
    "Esta instrução prevalece sobre o estilo consultivo padrão do Governança.",
    "A pergunta atual é complementar. Portanto, responda como acompanhamento executivo, não como nova explicação completa.",
    "",
    "FORMATO OBRIGATÓRIO DA RESPOSTA:",
    "",
    "Resposta direta:",
    "[uma frase curta]",
    "",
    "Indicadores/Métricas principais:",
    "- [item objetivo]",
    "- [item objetivo]",
    "- [item objetivo]",
    "- [item objetivo]",
    "- [item objetivo]",
    "",
    "Como acompanhar:",
    "- [ação objetiva]",
    "- [ação objetiva]",
    "",
    "PROIBIDO NESTE CASO:",
    "- abrir com contextualização ampla;",
    "- repetir conceitos já explicados;",
    "- criar seções novas além das três acima;",
    "- escrever como artigo, parecer, plano completo ou mini consultoria;",
    "- incluir Base legal ou Referências oficiais, salvo pedido expresso ou risco jurídico direto;",
    "- ultrapassar 180 palavras.",
  ].join("\n");
}


function isDefaultConversationTitle(title: string | null | undefined) {
  const normalized = String(title ?? "").trim().toLowerCase();

  return (
    normalized === "" ||
    normalized === "nova conversa" ||
    normalized === "nova conversa institucional"
  );
}

function buildConversationTitleFromMessage(content: string) {
  const clean = String(content ?? "")
    .split("\nPDFs selecionados para esta pergunta:")[0]
    .replace(/\s+/g, " ")
    .trim();

  if (!clean) {
    return "Conversa";
  }

  if (clean.length <= 54) {
    return clean;
  }

  return `${clean.slice(0, 54).trim()}...`;
}

async function updateConversationTitleFromMessage(params: {
  supabase: ReturnType<typeof createWritableSupabaseRouteClient>;
  conversation: GovernanceConversationForChat;
  organizationId: string;
  content: string;
}) {
  const { supabase, conversation, organizationId, content } = params;

  if (!isDefaultConversationTitle(conversation.title)) {
    return conversation.title;
  }

  // O título da conversa deve nascer da PRIMEIRA mensagem do usuário.
  // Mesmo que a conversa ainda esteja com título padrão após várias mensagens,
  // evitamos usar a pergunta atual, pois isso faria o histórico mudar para a última.
  const { data: firstUserMessage, error: firstUserMessageError } = await supabase
    .from("governance_messages")
    .select("content")
    .eq("conversation_id", conversation.id)
    .eq("organization_id", organizationId)
    .eq("role", "user")
    .order("created_at", { ascending: true })
    .limit(1)
    .maybeSingle<{ content: string | null }>();

  if (firstUserMessageError) {
    console.warn(
      "[governance/chat] Não foi possível buscar a primeira mensagem para compor o título:",
      firstUserMessageError,
    );
  }

  const titleSource =
    typeof firstUserMessage?.content === "string" &&
    firstUserMessage.content.trim().length > 0
      ? firstUserMessage.content
      : content;

  const nextTitle = buildConversationTitleFromMessage(titleSource);

  const { error } = await supabase
    .from("governance_conversations")
    .update({
      title: nextTitle,
      updated_at: new Date().toISOString(),
    })
    .eq("id", conversation.id)
    .eq("organization_id", organizationId);

  if (error) {
    console.warn(
      "[governance/chat] Mensagem salva, mas não foi possível atualizar o título da conversa:",
      error,
    );

    return conversation.title;
  }

  conversation.title = nextTitle;

  return nextTitle;
}


type OfficialGazetteContextChunkRow = {
  document_id: string;
  organization_id: string;
  page_number: number | null;
  section_type: string | null;
  title: string | null;
  content: string | null;
  governance_official_gazette_documents?:
    | {
        edition_number?: number | null;
        publication_date?: string | null;
        public_url?: string | null;
        pdf_url?: string | null;
        source_page_url?: string | null;
      }
    | {
        edition_number?: number | null;
        publication_date?: string | null;
        public_url?: string | null;
        pdf_url?: string | null;
        source_page_url?: string | null;
      }[];
};

type OfficialGazetteReferenceLink = {
  label: string;
  url: string;
  title: string;
  editionNumber: number | null;
  publicationDate: string | null;
};

type OfficialGazetteContextResult = {
  contextText: string;
  chunksUsed: number;
  totalChunksRead: number;
  enabled: boolean;
  referenceLinks: OfficialGazetteReferenceLink[];
};

const OFFICIAL_GAZETTE_TRIGGER_WORDS = [
  "diario oficial",
  "diário oficial",
  "ato",
  "atos",
  "decreto",
  "portaria",
  "resolucao",
  "resolução",
  "dispensa",
  "licitacao",
  "licitação",
  "inexigibilidade",
  "edital",
  "extrato",
  "contrato",
  "publicado",
  "publicada",
  "publicadas",
  "publicados",
  "suplementacao",
  "suplementação",
];

const OFFICIAL_GAZETTE_STOPWORDS = new Set([
  "sobre",
  "para",
  "com",
  "sem",
  "que",
  "qual",
  "quais",
  "quando",
  "quanto",
  "quantas",
  "quantos",
  "houve",
  "existe",
  "existem",
  "foram",
  "publicada",
  "publicadas",
  "publicado",
  "publicados",
  "diario",
  "diário",
  "oficial",
  "atos",
  "ato",
  "tem",
  "das",
  "dos",
  "uma",
  "uns",
  "por",
  "entre",
  "este",
  "esta",
  "esse",
  "essa",
  "municipio",
  "município",
]);

function normalizeOfficialGazetteSearchText(value: string) {
  return String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9/.-]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function shouldUseOfficialGazetteContext(question: string) {
  const normalizedQuestion = normalizeOfficialGazetteSearchText(question);

  if (
    isMunicipalCreationLawQuestion(question) ||
    isAdministrativeStructureQuestion(question) ||
    isCareerProgressionQuestion(question)
  ) {
    return false;
  }

  return OFFICIAL_GAZETTE_TRIGGER_WORDS.some((word) =>
    normalizedQuestion.includes(normalizeOfficialGazetteSearchText(word)),
  );
}

function extractOfficialGazetteSearchTerms(question: string) {
  const normalizedQuestion = normalizeOfficialGazetteSearchText(question);

  const terms = normalizedQuestion
    .split(" ")
    .map((term) => term.trim())
    .filter((term) => term.length >= 4)
    .filter((term) => !OFFICIAL_GAZETTE_STOPWORDS.has(term));

  const mappedTerms: string[] = [];

  if (normalizedQuestion.includes("decreto")) mappedTerms.push("decreto");
  if (normalizedQuestion.includes("portaria")) mappedTerms.push("portaria");
  if (normalizedQuestion.includes("resolucao")) mappedTerms.push("resolucao");
  if (normalizedQuestion.includes("dispensa")) mappedTerms.push("dispensa", "licitacao");
  if (normalizedQuestion.includes("licitacao")) mappedTerms.push("licitacao");
  if (normalizedQuestion.includes("suplementacao")) mappedTerms.push("suplementacao", "credito", "orcamento");
  if (normalizedQuestion.includes("junho")) mappedTerms.push("junho", "06/");

  return Array.from(new Set([...mappedTerms, ...terms])).slice(0, 20);
}

function extractOfficialGazetteEditionNumber(question: string) {
  const normalizedQuestion = normalizeOfficialGazetteSearchText(question);

  const editionMatch =
    normalizedQuestion.match(/\bedicao\s+(?:do\s+diario\s+oficial\s+)?(\d{1,8})\b/i) ??
    normalizedQuestion.match(/\bdiario\s+oficial\s+(?:n\s*)?(\d{1,8})\b/i) ??
    normalizedQuestion.match(/\bdiario\s+(?:n\s*)?(\d{1,8})\b/i);

  if (!editionMatch?.[1]) {
    return null;
  }

  const editionNumber = Number(editionMatch[1]);

  return Number.isFinite(editionNumber) ? editionNumber : null;
}

function normalizeOfficialGazetteDateFromQuestion(question: string) {
  const text = String(question ?? "");

  const brDateMatch = text.match(/\b(\d{1,2})[/-](\d{1,2})[/-](\d{4})\b/);

  if (brDateMatch) {
    const day = brDateMatch[1].padStart(2, "0");
    const month = brDateMatch[2].padStart(2, "0");
    const year = brDateMatch[3];

    return `${year}-${month}-${day}`;
  }

  const isoDateMatch = text.match(/\b(\d{4})-(\d{1,2})-(\d{1,2})\b/);

  if (isoDateMatch) {
    const year = isoDateMatch[1];
    const month = isoDateMatch[2].padStart(2, "0");
    const day = isoDateMatch[3].padStart(2, "0");

    return `${year}-${month}-${day}`;
  }

  return null;
}

function isOfficialGazetteCompleteListIntent(question: string) {
  const normalizedQuestion = normalizeOfficialGazetteSearchText(question);

  const mentionsGazette =
    normalizedQuestion.includes("diario") ||
    normalizedQuestion.includes("edicao") ||
    normalizedQuestion.includes("publicacao") ||
    normalizedQuestion.includes("publicacoes") ||
    normalizedQuestion.includes("atos") ||
    normalizedQuestion.includes("ato");

  const asksCount =
    /\b(quantos|quantas|quantidade|total|numero|número)\b/i.test(normalizedQuestion) &&
    /\b(atos|ato|publicacoes|publicacao|publicados|publicadas)\b/i.test(normalizedQuestion);

  const asksList =
    /\b(liste|listar|lista|mostre|mostrar|relacione|descreva|descrever|quais)\b/i.test(
      normalizedQuestion,
    ) &&
    /\b(atos|ato|publicacoes|publicacao|publicados|publicadas)\b/i.test(normalizedQuestion);

  return mentionsGazette && (asksCount || asksList || normalizedQuestion.includes("todos os atos"));
}

function compareOfficialGazetteRows(a: OfficialGazetteContextChunkRow, b: OfficialGazetteContextChunkRow) {
  const aPage = typeof a.page_number === "number" ? a.page_number : Number.MAX_SAFE_INTEGER;
  const bPage = typeof b.page_number === "number" ? b.page_number : Number.MAX_SAFE_INTEGER;

  if (aPage !== bPage) {
    return aPage - bPage;
  }

  return String(a.title ?? "").localeCompare(String(b.title ?? ""), "pt-BR", {
    numeric: true,
    sensitivity: "base",
  });
}

function getOfficialGazetteDocumentSortValue(rows: OfficialGazetteContextChunkRow[]) {
  const firstRow = rows[0];

  if (!firstRow) {
    return 0;
  }

  const { editionNumber, publicationDate } = getOfficialGazetteDocumentMetadata(firstRow);
  const publicationTime = publicationDate ? Date.parse(`${publicationDate}T00:00:00Z`) : 0;
  const safePublicationTime = Number.isFinite(publicationTime) ? publicationTime : 0;

  return safePublicationTime + Number(editionNumber ?? 0);
}

function selectCompleteOfficialGazetteRowsForQuestion(
  rows: OfficialGazetteContextChunkRow[],
  question: string,
) {
  const editionNumber = extractOfficialGazetteEditionNumber(question);
  const publicationDate = normalizeOfficialGazetteDateFromQuestion(question);
  const completeListIntent = isOfficialGazetteCompleteListIntent(question);

  if (!editionNumber && !publicationDate && !completeListIntent) {
    return null;
  }

  const rowsByDocumentId = new Map<string, OfficialGazetteContextChunkRow[]>();

  for (const row of rows) {
    const documentRows = rowsByDocumentId.get(row.document_id) ?? [];

    documentRows.push(row);
    rowsByDocumentId.set(row.document_id, documentRows);
  }

  const documentGroups = Array.from(rowsByDocumentId.values()).map((documentRows) =>
    [...documentRows].sort(compareOfficialGazetteRows),
  );

  const matchedGroups = documentGroups.filter((documentRows) => {
    const metadata = getOfficialGazetteDocumentMetadata(documentRows[0]);

    if (editionNumber && Number(metadata.editionNumber) !== editionNumber) {
      return false;
    }

    if (publicationDate && metadata.publicationDate !== publicationDate) {
      return false;
    }

    return true;
  });

  if (matchedGroups.length > 0) {
    return matchedGroups
      .sort((a, b) => getOfficialGazetteDocumentSortValue(b) - getOfficialGazetteDocumentSortValue(a))
      .flat();
  }

  if (!editionNumber && !publicationDate && completeListIntent && documentGroups.length > 0) {
    return documentGroups.sort(
      (a, b) => getOfficialGazetteDocumentSortValue(b) - getOfficialGazetteDocumentSortValue(a),
    )[0];
  }

  return null;
}

function scoreOfficialGazetteChunk(
  row: OfficialGazetteContextChunkRow,
  question: string,
  searchTerms: string[],
) {
  const normalizedQuestion = normalizeOfficialGazetteSearchText(question);
  const normalizedTitle = normalizeOfficialGazetteSearchText(row.title ?? "");
  const normalizedSectionType = normalizeOfficialGazetteSearchText(row.section_type ?? "");
  const normalizedContent = normalizeOfficialGazetteSearchText(row.content ?? "");
  const searchableText = [normalizedTitle, normalizedSectionType, normalizedContent].join(" ");

  let score = 0;

  for (const term of searchTerms) {
    if (!term) continue;

    if (normalizedTitle.includes(term)) {
      score += 4;
    }

    if (normalizedSectionType.includes(term)) {
      score += 3;
    }

    if (normalizedContent.includes(term)) {
      score += 1;
    }
  }

  if (normalizedQuestion.includes("decreto") && searchableText.includes("decreto")) score += 10;
  if (normalizedQuestion.includes("portaria") && searchableText.includes("portaria")) score += 10;
  if (normalizedQuestion.includes("resolucao") && searchableText.includes("resolucao")) score += 10;
  if (normalizedQuestion.includes("dispensa") && searchableText.includes("dispensa")) score += 10;
  if (normalizedQuestion.includes("licitacao") && searchableText.includes("licitacao")) score += 6;
  if (normalizedQuestion.includes("junho") && searchableText.includes("junho")) score += 5;

  return score;
}


function isBrokenSupabasePublicStorageUrl(url: string) {
  try {
    const parsedUrl = new URL(url);

    return (
      parsedUrl.hostname.endsWith(".supabase.co") &&
      parsedUrl.pathname.includes("/storage/v1/object/public/governance-documents/")
    );
  } catch {
    return false;
  }
}

const OFFICIAL_GAZETTE_MONTH_NAME_TO_NUMBER: Record<string, string> = {
  janeiro: "01",
  fevereiro: "02",
  marco: "03",
  março: "03",
  abril: "04",
  maio: "05",
  junho: "06",
  julho: "07",
  agosto: "08",
  setembro: "09",
  outubro: "10",
  novembro: "11",
  dezembro: "12",
};

function getOfficialGazetteUploadYearMonth(publicationDate?: string | null) {
  const dateMatch = String(publicationDate ?? "").match(/^(\d{4})-(\d{2})-/);

  if (dateMatch) {
    return {
      year: dateMatch[1],
      month: dateMatch[2],
    };
  }

  return null;
}

function normalizeOfficialGazetteFileName(fileName: string) {
  return String(fileName ?? "")
    .trim()
    .replace(/^\d{10,}-/, "")
    .replace(/-d4sign\.pdf$/i, "-D4Sign.pdf");
}

function inferOfficialGazetteUploadYearMonthFromFileName(fileName: string) {
  const normalized = String(fileName ?? "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");

  const numericDateMatch = normalized.match(/(?:^|[^0-9])(\d{1,2})[-_]?(\d{1,2})[-_]?(\d{4})(?:[^0-9]|$)/);

  if (numericDateMatch) {
    return {
      year: numericDateMatch[3],
      month: numericDateMatch[2].padStart(2, "0"),
    };
  }

  for (const [monthName, month] of Object.entries(OFFICIAL_GAZETTE_MONTH_NAME_TO_NUMBER)) {
    const plainMonthName = monthName
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "");

    const monthYearMatch = normalized.match(
      new RegExp(`${plainMonthName}\\D*(20\\d{2})`),
    );

    if (monthYearMatch) {
      return {
        year: monthYearMatch[1],
        month,
      };
    }
  }

  return null;
}

function buildOfficialMunicipalGazettePdfUrlFromStorageUrl(
  url: string,
  publicationDate?: string | null,
) {
  if (!isBrokenSupabasePublicStorageUrl(url)) {
    return "";
  }

  try {
    const parsedUrl = new URL(url);
    const rawFileName = decodeURIComponent(
      parsedUrl.pathname.split("/").filter(Boolean).pop() ?? "",
    );
    const fileName = normalizeOfficialGazetteFileName(rawFileName);

    if (!fileName || !/\.pdf$/i.test(fileName)) {
      return "";
    }

    const uploadYearMonth =
      getOfficialGazetteUploadYearMonth(publicationDate) ||
      inferOfficialGazetteUploadYearMonthFromFileName(fileName);

    if (!uploadYearMonth) {
      return "";
    }

    /*
      Correção V4:
      alguns registros antigos guardaram o PDF como URL pública do Supabase Storage
      em um bucket que não existe mais/ não está público no ambiente atual.

      Para esses casos, reconstruímos o link oficial municipal do Diário Oficial
      a partir do nome real do arquivo e da data de publicação já cadastrada no documento.
    */
    return `https://santanadoitarare.pr.gov.br/diariooficial/wp-content/uploads/${uploadYearMonth.year}/${uploadYearMonth.month}/${fileName}`;
  } catch {
    return "";
  }
}

function normalizeOfficialGazetteUrl(
  value: string | null | undefined,
  publicationDate?: string | null,
) {
  const url = String(value ?? "").trim();

  if (!/^https?:\/\//i.test(url)) {
    return "";
  }

  if (isBrokenSupabasePublicStorageUrl(url)) {
    return buildOfficialMunicipalGazettePdfUrlFromStorageUrl(url, publicationDate);
  }

  return url;
}

function pickOfficialGazetteUrl(params: {
  sourcePageUrl?: string | null;
  publicUrl?: string | null;
  pdfUrl?: string | null;
  publicationDate?: string | null;
}) {
  const sourcePageUrl = normalizeOfficialGazetteUrl(
    params.sourcePageUrl,
    params.publicationDate,
  );
  const publicUrl = normalizeOfficialGazetteUrl(params.publicUrl, params.publicationDate);
  const pdfUrl = normalizeOfficialGazetteUrl(params.pdfUrl, params.publicationDate);

  /*
    Preferência:
    1) source_page_url: página oficial da edição, quando cadastrada.
    2) public_url: URL pública consolidada, quando cadastrada.
    3) pdf_url: PDF oficial.
       Se o pdf_url antigo apontar para o Supabase Storage quebrado, ele é convertido
       para o endereço oficial do Diário Oficial municipal.
  */
  return sourcePageUrl || publicUrl || pdfUrl || "";
}

function normalizeGovernanceSourceUrl(value: string | null | undefined) {
  const url = String(value ?? "").trim();

  if (!/^https?:\/\//i.test(url)) {
    return null;
  }

  if (isBrokenSupabasePublicStorageUrl(url)) {
    return normalizeOfficialGazetteUrl(url) || null;
  }

  return url;
}

function normalizeGeneralGovernanceSourceUrl(value: string | null | undefined) {
  const url = String(value ?? "").trim();

  if (!/^https?:\/\//i.test(url)) {
    return null;
  }

  return url;
}

function normalizeGovernanceChatSourcesForResponse(
  sources: GovernanceChatSources,
): GovernanceChatSources {
  const normalizeInstitutionalOrOfficialSource = (
    source: GovernanceChatSource,
  ): GovernanceChatSource => ({
    ...source,
    url: normalizeGeneralGovernanceSourceUrl(source.url),
  });

  const normalizeOfficialGazetteSource = (
    source: GovernanceChatSource,
  ): GovernanceChatSource => ({
    ...source,
    url: normalizeGovernanceSourceUrl(source.url),
  });

  return {
    institutional: sources.institutional.map(normalizeInstitutionalOrOfficialSource),
    officialGazette: sources.officialGazette.map(normalizeOfficialGazetteSource),
    officialSources: sources.officialSources.map(normalizeInstitutionalOrOfficialSource),
  };
}

function escapeRegExp(value: string) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function normalizeOfficialGazetteLabel(value: string) {
  return String(value ?? "")
    .replace(/\s+/g, " ")
    .replace(/\s*,.*$/g, "")
    .trim();
}

function extractOfficialGazetteLegalLabels(value: string) {
  const text = String(value ?? "");
  const pattern =
    /\b(?:Lei(?:\s+Complementar)?|Decreto|Portaria|Instrução Normativa|Resolução|Edital|Dispensa|Inexigibilidade)\s+n[º°]?\s*[\d.]+\/\d{4}\b/gi;

  const labels = new Set<string>();

  for (const match of text.matchAll(pattern)) {
    const label = normalizeOfficialGazetteLabel(match[0]);

    if (label) {
      labels.add(label);
    }
  }

  return Array.from(labels);
}

function buildOfficialGazetteReferenceLinks(
  chunks: OfficialGazetteContextChunkRow[],
) {
  const linksByKey = new Map<string, OfficialGazetteReferenceLink>();

  for (const chunk of chunks) {
    const title = String(chunk.title ?? "Ato do Diário Oficial").trim();
    const content = String(chunk.content ?? "");
    const { editionNumber, publicationDate, publicUrl, pdfUrl, sourcePageUrl } =
      getOfficialGazetteDocumentMetadata(chunk);
    const officialUrl = pickOfficialGazetteUrl({
      sourcePageUrl,
      publicUrl,
      pdfUrl,
      publicationDate,
    });

    if (!officialUrl) {
      continue;
    }

    const labels = [
      ...extractOfficialGazetteLegalLabels(title),
      ...extractOfficialGazetteLegalLabels(content).slice(0, 8),
    ];

    for (const label of labels) {
      const key = label.toLocaleLowerCase("pt-BR");

      if (!linksByKey.has(key)) {
        linksByKey.set(key, {
          label,
          url: officialUrl,
          title,
          editionNumber,
          publicationDate,
        });
      }
    }
  }

  return Array.from(linksByKey.values());
}

function linkOfficialGazetteReferencesInAssistantText(
  content: string,
  referenceLinks: OfficialGazetteReferenceLink[],
) {
  let nextContent = String(content ?? "");

  for (const referenceLink of referenceLinks) {
    const label = normalizeOfficialGazetteLabel(referenceLink.label);
    const url = normalizeOfficialGazetteUrl(
      referenceLink.url,
      referenceLink.publicationDate,
    );

    if (!label || !url) {
      continue;
    }

    const pattern = new RegExp(`\\b${escapeRegExp(label)}\\b`, "gi");

    nextContent = nextContent.replace(pattern, (match, offset: number, fullText: string) => {
      const before = fullText.slice(Math.max(0, offset - 2), offset);
      const after = fullText.slice(offset + match.length, offset + match.length + 2);

      if (before.includes("[") || after.startsWith("](")) {
        return match;
      }

      return `[${match}](${url})`;
    });
  }

  return nextContent;
}


function getOfficialGazetteDocumentMetadata(chunk: OfficialGazetteContextChunkRow) {
  const relation = chunk.governance_official_gazette_documents;
  const documentMetadata = Array.isArray(relation) ? relation[0] : relation;

  return {
    editionNumber: documentMetadata?.edition_number ?? null,
    publicationDate: documentMetadata?.publication_date ?? null,
    publicUrl: String(documentMetadata?.public_url ?? "").trim(),
    pdfUrl: String(documentMetadata?.pdf_url ?? "").trim(),
    sourcePageUrl: String(documentMetadata?.source_page_url ?? "").trim(),
  };
}

function buildOfficialGazetteContextText(params: {
  chunks: OfficialGazetteContextChunkRow[];
  question: string;
  completeListMode?: boolean;
}) {
  const { chunks, question, completeListMode = false } = params;

  if (chunks.length === 0) {
    return "";
  }

  let totalChars = 0;
  const blocks: string[] = [];

  for (const [index, chunk] of chunks.entries()) {
    const title = String(chunk.title ?? "Ato do Diário Oficial").trim();
    const sectionType = String(chunk.section_type ?? "não classificado").trim();
    const pageNumber =
      typeof chunk.page_number === "number" ? `Página ${chunk.page_number}` : "Página não informada";
    const content = clampText(String(chunk.content ?? "").trim(), completeListMode ? 420 : 1600);
    const { editionNumber, publicationDate, publicUrl, pdfUrl, sourcePageUrl } =
      getOfficialGazetteDocumentMetadata(chunk);
    const normalizedSourcePageUrl = normalizeOfficialGazetteUrl(
      sourcePageUrl,
      publicationDate,
    );
    const normalizedPublicUrl = normalizeOfficialGazetteUrl(publicUrl, publicationDate);
    const normalizedPdfUrl = normalizeOfficialGazetteUrl(pdfUrl, publicationDate);
    const officialUrl = pickOfficialGazetteUrl({
      sourcePageUrl,
      publicUrl,
      pdfUrl,
      publicationDate,
    });

    const officialLinks = [
      officialUrl ? `Link oficial para citar este ato: ${officialUrl}` : null,
      normalizedSourcePageUrl
        ? `Página oficial da edição: ${normalizedSourcePageUrl}`
        : null,
      normalizedPublicUrl ? `URL pública do documento: ${normalizedPublicUrl}` : null,
      normalizedPdfUrl ? `PDF oficial do Diário Oficial: ${normalizedPdfUrl}` : null,
    ].filter(Boolean);

    const block = [
      `ATO ${index + 1}`,
      `Título: ${title}`,
      `Tipo: ${sectionType}`,
      `Documento: ${chunk.document_id}`,
      editionNumber ? `Edição do Diário Oficial: ${editionNumber}` : null,
      publicationDate ? `Data de publicação: ${publicationDate}` : null,
      pageNumber,
      ...officialLinks,
      "",
      content,
    ]
      .filter((line): line is string => typeof line === "string")
      .join("\n");

    const maxContextChars = completeListMode
      ? MAX_OFFICIAL_GAZETTE_COMPLETE_LIST_CONTEXT_CHARS
      : MAX_OFFICIAL_GAZETTE_CONTEXT_CHARS;

    if (totalChars + block.length > maxContextChars) {
      break;
    }

    blocks.push(block);
    totalChars += block.length;
  }

  if (blocks.length === 0) {
    return "";
  }

  return [
    "CONTEXTO DO DIÁRIO OFICIAL MUNICIPAL",
    "",
    "Use os atos abaixo como base factual quando a pergunta envolver Diário Oficial, decretos, portarias, licitações, dispensas, resoluções, leis, editais, extratos ou atos publicados.",
    "Não invente ato não listado. Se os atos recuperados não forem suficientes, diga que não localizou evidência suficiente nos atos indexados.",
    completeListMode
      ? "Quando a pergunta pedir contagem ou lista completa da edição, use exatamente o número informado em 'Atos recuperados'. Não reduza, não agrupe e não ignore blocos ATO. Cada bloco ATO representa um ato indexado."
      : "Quando a pergunta pedir contagem, conte apenas os atos recuperados neste contexto e informe que o número depende dos atos já indexados no sistema.",
    "Quando citar ato municipal recuperado deste contexto, transforme o próprio nome do ato em link Markdown usando o campo 'Link oficial para citar este ato'. Exemplo: [Decreto nº 042/2026](URL).",
    "Não coloque URL bruta isolada no final quando o nome do ato puder ser linkado no próprio texto.",
    "Use somente os links informados no próprio ato. Não crie link do Planalto para decreto, portaria, resolução, edital, dispensa, extrato ou outro ato municipal.",
    "Se o ato recuperado não trouxer link oficial, cite o ato em texto simples, sem hyperlink presumido.",
    "",
    `Pergunta do usuário: ${question}`,
    "",
    completeListMode
      ? `Atos recuperados: ${blocks.length} de ${chunks.length} atos indexados para o filtro solicitado`
      : `Atos recuperados: ${blocks.length}`,
    "",
    blocks.join("\n\n---\n\n"),
  ].join("\n");
}

async function buildOfficialGazetteContext(params: {
  client: any;
  organizationId: string;
  question: string;
}): Promise<OfficialGazetteContextResult> {
  const { client, organizationId, question } = params;

  if (!shouldUseOfficialGazetteContext(question)) {
    return {
      contextText: "",
      chunksUsed: 0,
      totalChunksRead: 0,
      enabled: false,
      referenceLinks: [],
    };
  }

  const searchTerms = extractOfficialGazetteSearchTerms(question);

  try {
    const { data, error } = await client
      .from("governance_official_gazette_chunks")
      .select(
        `
          document_id,
          organization_id,
          page_number,
          section_type,
          title,
          content,
          governance_official_gazette_documents(
            edition_number,
            publication_date,
            public_url,
            pdf_url,
            source_page_url
          )
        `,
      )
      .eq("organization_id", organizationId)
      .order("document_id", { ascending: false })
      .order("page_number", { ascending: true, nullsFirst: false })
      .order("title", { ascending: true, nullsFirst: false })
      .limit(MAX_OFFICIAL_GAZETTE_CHUNKS);

    if (error) {
      console.warn("[governance/chat] Não foi possível carregar atos do Diário Oficial:", error);

      return {
        contextText: "",
        chunksUsed: 0,
        totalChunksRead: 0,
        enabled: true,
        referenceLinks: [],
      };
    }

    const rows = ((data ?? []) as OfficialGazetteContextChunkRow[]).filter((row) =>
      String(row.content ?? "").trim().length > 0,
    );

    const completeRows = selectCompleteOfficialGazetteRowsForQuestion(rows, question);

    const scoredRows = completeRows
      ? []
      : rows
          .map((row) => ({
            row,
            score: scoreOfficialGazetteChunk(row, question, searchTerms),
          }))
          .filter((item) => item.score > 0)
          .sort((a, b) => b.score - a.score)
          .slice(0, MAX_OFFICIAL_GAZETTE_SELECTED_CHUNKS)
          .map((item) => item.row);

    const selectedRows = completeRows ?? (scoredRows.length > 0 ? scoredRows : rows.slice(0, 20));
    const completeListMode = Boolean(completeRows);
    const contextText = buildOfficialGazetteContextText({
      chunks: selectedRows,
      question,
      completeListMode,
    });

    return {
      contextText,
      chunksUsed: selectedRows.length,
      totalChunksRead: rows.length,
      enabled: true,
      referenceLinks: buildOfficialGazetteReferenceLinks(selectedRows),
    };
  } catch (error) {
    console.warn("[governance/chat] Erro inesperado ao montar contexto do Diário Oficial:", error);

    return {
      contextText: "",
      chunksUsed: 0,
      totalChunksRead: 0,
      enabled: true,
      referenceLinks: [],
    };
  }
}


function sseEvent(event: string, data: unknown) {
  return `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
}

export async function POST(request: Request) {
  try {
    if (!openai) {
      return NextResponse.json(
        { error: "OpenAI não configurada. Verifique OPENAI_API_KEY." },
        { status: 500 },
      );
    }

    const supabase = createWritableSupabaseRouteClient();

    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser();

    if (userError || !user) {
      return NextResponse.json(
        { error: "Usuário não autenticado." },
        { status: 401 },
      );
    }

    const context = await getCurrentGovernanceOrganization(user.id);

    if (!context) {
      return NextResponse.json(
        { error: "Usuário não vinculado a uma organização ativa." },
        { status: 403 },
      );
    }

    const body = (await request.json().catch(() => null)) as
      | GovernanceChatRequestBody
      | null;

    const conversationId =
      typeof body?.conversationId === "string"
        ? body.conversationId.trim()
        : "";

    const rawContent =
      typeof body?.content === "string" ? body.content : "";

    const content = normalizeContent(rawContent);
    const selectedPdfAttachmentNames = Array.isArray(body?.selectedPdfAttachmentNames)
      ? body.selectedPdfAttachmentNames
          .filter((name): name is string => typeof name === "string")
          .map((name) => name.trim())
          .filter(Boolean)
      : [];

    const selectedPdfFileIds = Array.isArray(body?.selectedPdfFileIds)
      ? body.selectedPdfFileIds
          .filter((id): id is string => typeof id === "string")
          .map((id) => id.trim())
          .filter((id) => uuidRe.test(id))
      : [];

    const requestedResponseMode = body?.responseMode;

    const hasSelectedPdfAttachments =
      selectedPdfAttachmentNames.length > 0 || selectedPdfFileIds.length > 0;

    if (!conversationId) {
      return NextResponse.json(
        { error: "Conversa institucional não informada." },
        { status: 400 },
      );
    }

    if (!content) {
      return NextResponse.json(
        { error: "Mensagem vazia. Digite um conteúdo antes de enviar." },
        { status: 400 },
      );
    }

    if (rawContent.trim().length > MAX_USER_MESSAGE_LENGTH) {
      return NextResponse.json(
        {
          error:
            "Mensagem muito longa. Reduza o texto ou envie o conteúdo como documento na base institucional futuramente.",
        },
        { status: 400 },
      );
    }

    const { data: conversation, error: conversationError } = await supabase
      .from("governance_conversations")
      .select(
        `
          id,
          organization_id,
          user_id,
          title,
          category,
          response_mode,
          visibility,
          status,
          deleted_at
        `,
      )
      .eq("id", conversationId)
      .eq("organization_id", context.organization.id)
      .is("deleted_at", null)
      .neq("status", "deleted")
      .maybeSingle<GovernanceConversationForChat>();

    if (conversationError) {
      console.error(
        "[governance/chat] Erro ao validar conversa:",
        conversationError,
      );

      return NextResponse.json(
        { error: "Não foi possível validar a conversa institucional." },
        { status: 500 },
      );
    }

    if (!conversation) {
      return NextResponse.json(
        { error: "Conversa institucional não encontrada para este órgão." },
        { status: 404 },
      );
    }

    if (conversation.status !== "active") {
      return NextResponse.json(
        { error: "Esta conversa não está ativa para novas mensagens." },
        { status: 409 },
      );
    }

    const effectiveResponseMode = normalizeResponseMode(
      requestedResponseMode,
      conversation.response_mode,
    );

    const queryAnalysis = analyzeGovernanceQuery(content);
    const shouldUseMunicipalKnowledgeContext =
      queryAnalysis.queryNature !== "legal_general";

    const forceWebFirst = shouldForceWebFirst(content);

    const criticalKnowledge =
      findGovernanceCriticalKnowledge(content);

    const legalGuardrails = buildGovernanceLegalGuardrails(content);
    const hasLegalGuardrails = legalGuardrails.trim().length > 0;

    const criticalKnowledgeInstruction =
      criticalKnowledge.length > 0
        ? [
            "BASE NORMATIVA OFICIAL DO PUBL.IA",
            "",
            "Os entendimentos abaixo são institucionais e devem prevalecer sobre interpretações alternativas.",
            "Não apresente conclusão incompatível com essas teses.",
            "",
            ...criticalKnowledge.map(
              (item) => `TEMA: ${item.title}\n\n${item.rule}`,
            ),
          ].join("\n")
        : "";
    const currentQuestionOnly =
      hasSelectedPdfAttachments ||
      hasLegalGuardrails ||
      queryAnalysis.queryNature === "legal_general";

    if (effectiveResponseMode !== conversation.response_mode) {
      const { error: updateResponseModeError } = await supabase
        .from("governance_conversations")
        .update({
          response_mode: effectiveResponseMode,
          updated_at: new Date().toISOString(),
        })
        .eq("id", conversation.id)
        .eq("organization_id", context.organization.id);

      if (updateResponseModeError) {
        console.warn(
          "[governance/chat] Não foi possível atualizar o modo de resposta da conversa:",
          updateResponseModeError,
        );
      } else {
        conversation.response_mode = effectiveResponseMode;
      }
    }

    const { data: userMessage, error: userMessageError } = await supabase
      .from("governance_messages")
      .insert({
        organization_id: context.organization.id,
        conversation_id: conversation.id,
        user_id: user.id,
        role: "user",
        content,
        metadata: {
          source: "governance_chat",
          product_tier: "governance",
          response_mode: effectiveResponseMode,
          selected_pdf_attachment_names: selectedPdfAttachmentNames,
          selected_pdf_file_ids: selectedPdfFileIds,
        },
      })
      .select(
        `
          id,
          organization_id,
          conversation_id,
          user_id,
          role,
          content,
          metadata,
          created_at
        `,
      )
      .single<GovernanceMessage>();

    if (userMessageError || !userMessage) {
      console.error(
        "[governance/chat] Erro ao salvar mensagem do usuário:",
        userMessageError,
      );

      return NextResponse.json(
        { error: "Não foi possível salvar a mensagem do usuário." },
        { status: 500 },
      );
    }

    const conversationTitle = await updateConversationTitleFromMessage({
      supabase,
      conversation,
      organizationId: context.organization.id,
      content,
    });

    const pdfContextResult = await buildGovernancePdfContext({
      client: supabase,
      userId: user.id,
      selectedPdfFileIds,
      question: content,
    });

    const knowledgeContextResult = await buildGovernanceKnowledgeContext({
      client: supabase,
      organizationId: context.organization.id,
      question: content,
      maxContextChars: 22000,
    });

    const rawResponseSources: GovernanceChatSources = normalizeGovernanceChatSourcesForResponse({
      institutional: knowledgeContextResult.sources.institutional,
      officialGazette: knowledgeContextResult.sources.officialGazette,
      officialSources: knowledgeContextResult.sources.officialSources,
    });

    const responseSources: GovernanceChatSources = filterGovernanceSourcesForResponse({
      sources: rawResponseSources,
      question: content,
      queryNature: queryAnalysis.queryNature,
    });

    let responseReferences = buildGovernanceChatReferences(responseSources);

    const { data: recentHistoryData, error: historyError } = await supabase
      .from("governance_messages")
      .select(
        `
          id,
          organization_id,
          conversation_id,
          user_id,
          role,
          content,
          metadata,
          created_at
        `,
      )
      .eq("organization_id", context.organization.id)
      .eq("conversation_id", conversation.id)
      .order("created_at", { ascending: false })
      .limit(MAX_HISTORY_MESSAGES);

    if (historyError) {
      console.error(
        "[governance/chat] Erro ao carregar histórico:",
        historyError,
      );

      return NextResponse.json(
        { error: "Não foi possível carregar o histórico da conversa." },
        { status: 500 },
      );
    }

    const history = ((recentHistoryData ?? []) as GovernanceMessage[]).reverse();

    const previousUserQuestion = getPreviousUserQuestion(history, userMessage.id);
    const conversationRelation = classifyConversationRelation({
      previousUserQuestion,
      currentUserQuestion: content,
    });

    console.log("[GOVERNANCA] Relation:", conversationRelation);
    console.log("[GOVERNANCA] Mode:", effectiveResponseMode);

    const governancePrompt = buildGovernancePrompt({
      responseMode: mapGovernanceModeToPromptMode(effectiveResponseMode),
    });

    const instructions = [
      governancePrompt,
      "",
      criticalKnowledgeInstruction,
      "",
      buildConversationContext({
        organizationName: context.organization.name,
        organizationId: context.organization.id,
        conversation,
      }),
      "",
      buildConversationRelationInstruction({
        relation: conversationRelation,
        previousUserQuestion,
        currentUserQuestion: content,
      }),
      "",
      buildGovernanceModeInstruction(effectiveResponseMode),
      "",
      buildGovernanceConsultantStyleInstruction(
        effectiveResponseMode,
        content,
        conversationRelation,
      ),
      "",
      buildFinalConsultativeOverride(effectiveResponseMode, conversationRelation),
      "",
      [
        "REGRA DE REFERÊNCIAS E LINGUAGEM:",
        "Não escreva 'Não houve consulta web nesta resposta' nem variações semelhantes.",
        "Não gere hyperlinks inventados no corpo da resposta.",
        "Não transforme automaticamente leis municipais, leis estaduais, leis complementares municipais, decretos municipais ou atos do Diário Oficial em links do Planalto.",
        "Use links somente quando eles vierem explicitamente no contexto como link oficial. Caso contrário, deixe o nome da norma sem link.",
        "Não crie seções finais chamadas 'Base legal', 'Referências oficiais' ou 'Base institucional'.",
        "Quando houver fundamento legal estruturado, o sistema exibirá a seção 'Fundamento legal consultado' ao final da resposta.",
        "Não economize resposta. Quando o contexto trouxer dados suficientes, responda de forma completa e útil para uso administrativo.",
        "Não diga que o trecho foi cortado, truncado ou incompleto por economia. Use todo o contexto recebido; se ainda faltar dado essencial, diga exatamente qual dado faltou.",
        "Não mande o usuário clicar na lei para obter a resposta quando a resposta puder ser extraída do contexto. O link serve para conferência, não para substituir a resposta.",
      ].join("\n"),
      "",
      buildForcedExecutiveFollowUpInstruction({
        relation: conversationRelation,
        mode: effectiveResponseMode,
      }),
      "",
      forceWebFirst
        ? [
            "ALERTA INTERNO WEB-FIRST / VALIDAÇÃO NORMATIVA",
            "A pergunta atual envolve prazo, valor, limite, percentual, dispositivo legal, licitação, contrato, sanção ou tema normativo sensível.",
            "Não responda por memória quando houver dado legal específico, volátil ou dependente de fonte oficial.",
            "Se não houver ferramenta de consulta oficial disponível neste fluxo, preserve o tom consultivo, mas indique a necessidade de validação em fonte oficial antes de decisão administrativa.",
          ].join("\n")
        : "",
      legalGuardrails,
      shouldUseMunicipalKnowledgeContext && knowledgeContextResult.contextText
        ? [
            "CONTEXTO ESTRUTURADO DO KNOWLEDGE ENGINE:",
            knowledgeContextResult.contextText,
          ].join("\n\n")
        : "",
      hasSelectedPdfAttachments
        ? [
            "REGRA PONTUAL PARA PDFS SELECIONADOS NESTA PERGUNTA:",
            "Use prioritariamente o conteúdo textual recuperado dos PDFs selecionados nesta pergunta.",
            "Ignore PDFs citados em mensagens anteriores desta conversa, salvo se o usuário pedir comparação ou histórico.",
            selectedPdfAttachmentNames.length > 0
              ? `Nomes informados pelo frontend: ${selectedPdfAttachmentNames.join(", ")}.`
              : "",
            pdfContextResult.selectedPdfFileIds.length > 0
              ? `IDs dos PDFs selecionados: ${pdfContextResult.selectedPdfFileIds.join(", ")}.`
              : "",
            pdfContextResult.pdfContextAvailable
              ? ["TRECHOS RECUPERADOS DOS PDFS SELECIONADOS:", pdfContextResult.pdfContextText].join("\n\n")
              : "Nenhum trecho textual dos PDFs selecionados foi recuperado para esta pergunta.",
            pdfContextResult.pdfContextWarnings.length > 0
              ? ["Avisos de recuperação dos PDFs:", ...pdfContextResult.pdfContextWarnings.map((warning) => `- ${warning}`)].join("\n")
              : "",
            "Se não houver trechos recuperados suficientes, diga isso com clareza. Não invente conteúdo dos PDFs.",
          ]
            .filter(Boolean)
            .join("\n")
        : "",
    ]
      .join("\n\n")
      .trim();

    const wantsStreaming = request.headers
      .get("accept")
      ?.includes("text/event-stream") === true;

    if (!wantsStreaming) {
      let assistantText = "";

      try {
        const response = await openai!.responses.create({
          model: OPENAI_MODEL_GOVERNANCE,
          instructions,
          input: mapMessagesToOpenAIInput(history, { currentMessageOnly: currentQuestionOnly }),
          temperature: 0.3,
        } as any);

        assistantText = response.output_text?.trim() ?? "";
      } catch (error) {
        console.error("[governance/chat] Erro OpenAI:", error);

        return NextResponse.json(
          { error: "Erro ao gerar resposta da IA institucional." },
          { status: 500 },
        );
      }

      if (!assistantText) {
        return NextResponse.json(
          { error: "A IA não retornou uma resposta válida." },
          { status: 500 },
        );
      }

      // Governança V2: links não são gerados automaticamente no texto da IA.
      // O backend expõe fontes e referências estruturadas em metadata.sources/references.
      assistantText = sanitizeGovernanceAssistantText({
        assistantText,
        question: content,
        institutionalSources: responseSources.institutional,
      });

      const officialLegalReferences = buildOfficialLegalReferencesForGovernance({
        question: content,
        answer: assistantText,
        forceWebFirst,
      });

      responseReferences = mergeGovernanceChatReferences(
        responseReferences,
        officialLegalReferences,
      );

      assistantText = buildGovernanceFinalAnswer({
        answer: assistantText,
        question: content,
        sources: responseSources,
        references: responseReferences,
      });

      const responseReferencesForClient =
        filterGovernanceChatReferencesForClient(responseReferences, {
          question: content,
          answer: assistantText,
        });

      const { data: assistantMessage, error: assistantMessageError } =
        await supabase
          .from("governance_messages")
          .insert({
            organization_id: context.organization.id,
            conversation_id: conversation.id,
            user_id: null,
            role: "assistant",
            content: assistantText,
            metadata: {
              source: "openai",
              product_tier: "governance",
              model: OPENAI_MODEL_GOVERNANCE,
              query_analysis: queryAnalysis,
              response_mode: effectiveResponseMode,
              history_messages_used: currentQuestionOnly ? 1 : history.length,
              selected_pdf_attachment_names: selectedPdfAttachmentNames,
              selected_pdf_file_ids: selectedPdfFileIds,
              current_message_only_for_pdf: hasSelectedPdfAttachments,
              current_message_only_for_legal_guardrails: hasLegalGuardrails,
              official_gazette_context_enabled: responseSources.officialGazette.length > 0,
              official_gazette_chunks_used: knowledgeContextResult.items.filter((item) => item.provider === "official_gazette").length,
              official_gazette_reference_links: responseSources.officialGazette,
              sources: responseSources,
              references: responseReferencesForClient,
              official_legal_references_used: officialLegalReferences,
              knowledge_engine: {
                version: "governance-v2.2.3-knowledge-motor",
                diagnostics: knowledgeContextResult.diagnostics,
                selected_items: knowledgeContextResult.items.map((item) => ({
                  id: item.id,
                  provider: item.provider,
                  title: item.title,
                  type: item.type,
                  url: item.url,
                  score: item.score,
                })),
              },
              institutional_sources_used: responseSources.institutional,
              official_sources_context_enabled: responseSources.officialSources.length > 0,
              official_sources_used: responseSources.officialSources,
              official_sources_prioritized_source: responseSources.officialSources[0] ?? null,
              official_sources_error: null,
              conversation_relation: conversationRelation,
              previous_user_question: previousUserQuestion || null,
              streaming: false,
            },
          })
          .select(
            `
              id,
              organization_id,
              conversation_id,
              user_id,
              role,
              content,
              metadata,
              created_at
            `,
          )
          .single<GovernanceMessage>();

      if (assistantMessageError || !assistantMessage) {
        console.error(
          "[governance/chat] Erro ao salvar resposta da IA:",
          assistantMessageError,
        );

        return NextResponse.json(
          { error: "A resposta foi gerada, mas não pôde ser salva." },
          { status: 500 },
        );
      }

      const { error: updateConversationError } = await supabase
        .from("governance_conversations")
        .update({
          updated_at: new Date().toISOString(),
        })
        .eq("id", conversation.id)
        .eq("organization_id", context.organization.id);

      if (updateConversationError) {
        console.warn(
          "[governance/chat] Mensagens salvas, mas não foi possível atualizar a conversa:",
          updateConversationError,
        );
      }

      const suggestions = await generateGovernanceFollowUpSuggestions({
        userContent: content,
        assistantText,
        responseMode: effectiveResponseMode,
        hasSelectedPdfAttachments,
        selectedPdfAttachmentNames,
      });

      return NextResponse.json({
        userMessage,
        assistantMessage,
        conversationTitle,
        suggestions,
        sources: responseSources,
        references: responseReferencesForClient,
      });
    }

    const encoder = new TextEncoder();

    const stream = new ReadableStream<Uint8Array>({
      async start(controller) {
        let assistantText = "";

        function send(event: string, data: unknown) {
          controller.enqueue(encoder.encode(sseEvent(event, data)));
        }

        send("userMessage", { userMessage });

        try {
          const openaiStream = await openai!.responses.create({
            model: OPENAI_MODEL_GOVERNANCE,
            instructions,
            input: mapMessagesToOpenAIInput(history, { currentMessageOnly: currentQuestionOnly }),
            temperature: 0.3,
            stream: true,
          } as any);

          for await (const event of openaiStream as any) {
            if (event?.type === "response.output_text.delta") {
              const delta = String(event.delta ?? "");

              if (delta) {
                assistantText += delta;
                send("delta", { delta });
              }
            }
          }
        } catch (error) {
          console.error("[governance/chat] Erro OpenAI streaming:", error);
          send("error", {
            error: "Erro ao gerar resposta da IA institucional.",
          });
          controller.close();
          return;
        }

        assistantText = assistantText.trim();

        if (!assistantText) {
          send("error", {
            error: "A IA não retornou uma resposta válida.",
          });
          controller.close();
          return;
        }

        // Governança V2: links não são gerados automaticamente no texto da IA.
        // O backend expõe fontes e referências estruturadas em metadata.sources/references.
        assistantText = sanitizeGovernanceAssistantText({
          assistantText,
          question: content,
          institutionalSources: responseSources.institutional,
        });

        const officialLegalReferences = buildOfficialLegalReferencesForGovernance({
          question: content,
          answer: assistantText,
          forceWebFirst,
        });

        responseReferences = mergeGovernanceChatReferences(
          responseReferences,
          officialLegalReferences,
        );

        const finalAssistantText = buildGovernanceFinalAnswer({
          answer: assistantText,
          question: content,
          sources: responseSources,
          references: responseReferences,
        });

        if (finalAssistantText !== assistantText) {
          const finalDelta = finalAssistantText.slice(assistantText.length);
          if (finalDelta) {
            send("delta", { delta: finalDelta });
          }
          assistantText = finalAssistantText;
        }

        const responseReferencesForClient =
          filterGovernanceChatReferencesForClient(responseReferences, {
          question: content,
          answer: assistantText,
        });

        const { data: assistantMessage, error: assistantMessageError } =
          await supabase
            .from("governance_messages")
            .insert({
              organization_id: context.organization.id,
              conversation_id: conversation.id,
              user_id: null,
              role: "assistant",
              content: assistantText,
              metadata: {
                source: "openai",
                product_tier: "governance",
                model: OPENAI_MODEL_GOVERNANCE,
                query_analysis: queryAnalysis,
                response_mode: effectiveResponseMode,
                history_messages_used: currentQuestionOnly ? 1 : history.length,
                selected_pdf_attachment_names: selectedPdfAttachmentNames,
                selected_pdf_file_ids: selectedPdfFileIds,
                current_message_only_for_pdf: hasSelectedPdfAttachments,
                current_message_only_for_legal_guardrails: hasLegalGuardrails,
                official_gazette_context_enabled: responseSources.officialGazette.length > 0,
                official_gazette_chunks_used: knowledgeContextResult.items.filter((item) => item.provider === "official_gazette").length,
                official_gazette_reference_links: responseSources.officialGazette,
                sources: responseSources,
              references: responseReferencesForClient,
              official_legal_references_used: officialLegalReferences,
              knowledge_engine: {
                version: "governance-v2.2.3-knowledge-motor",
                diagnostics: knowledgeContextResult.diagnostics,
                selected_items: knowledgeContextResult.items.map((item) => ({
                  id: item.id,
                  provider: item.provider,
                  title: item.title,
                  type: item.type,
                  url: item.url,
                  score: item.score,
                })),
              },
              institutional_sources_used: responseSources.institutional,
              official_sources_context_enabled: responseSources.officialSources.length > 0,
                official_sources_used: responseSources.officialSources,
                official_sources_error: null,
                conversation_relation: conversationRelation,
                previous_user_question: previousUserQuestion || null,
                streaming: true,
              },
            })
            .select(
              `
                id,
                organization_id,
                conversation_id,
                user_id,
                role,
                content,
                metadata,
                created_at
              `,
            )
            .single<GovernanceMessage>();

        if (assistantMessageError || !assistantMessage) {
          console.error(
            "[governance/chat] Erro ao salvar resposta da IA:",
            assistantMessageError,
          );

          send("error", {
            error: "A resposta foi gerada, mas não pôde ser salva.",
          });
          controller.close();
          return;
        }

        const { error: updateConversationError } = await supabase
          .from("governance_conversations")
          .update({
            updated_at: new Date().toISOString(),
          })
          .eq("id", conversation.id)
          .eq("organization_id", context.organization.id);

        if (updateConversationError) {
          console.warn(
            "[governance/chat] Mensagens salvas, mas não foi possível atualizar a conversa:",
            updateConversationError,
          );
        }

        const suggestions = await generateGovernanceFollowUpSuggestions({
          userContent: content,
          assistantText,
          responseMode: effectiveResponseMode,
          hasSelectedPdfAttachments,
          selectedPdfAttachmentNames,
        });

        if (suggestions.length > 0) {
          send("suggestions", { suggestions });
        }

        send("done", {
          userMessage,
          assistantMessage,
          conversationTitle,
          suggestions,
          sources: responseSources,
          references: responseReferencesForClient,
        });

        controller.close();
      },
    });

    return new Response(stream, { headers: SSE_HEADERS });
  } catch (error) {
    console.error("[governance/chat] Erro inesperado:", error);

    return NextResponse.json(
      { error: "Erro inesperado ao processar chat institucional." },
      { status: 500 },
    );
  }
}