//src/app/(auth)/criar-conta/CriarContaPageClient.tsx
"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useFormState } from "react-dom";

import AuthShell from "@/components/auth/AuthShell";
import AuthInput from "@/components/auth/AuthInput";
import SubmitButton from "@/components/auth/SubmitButton";
import Alert from "@/components/auth/Alert";
import AuthPasswordInput from "@/components/auth/AuthPasswordInput";
import { criarConta } from "./formActions";

type State = {
  ok: boolean;
  error?: string;
  redirect?: string;
  code?: string;
};

const initialState: State = { ok: false };

export default function CriarContaPageClient() {
  const sp = useSearchParams();
  const tk = sp.get("tk") ?? "";
  const orderId = sp.get("order_id") ?? sp.get("order_code") ?? "";

  return <CriarContaInner key={`${tk}:${orderId}`} tk={tk} orderId={orderId} />;
}

function CriarContaInner({ tk, orderId }: { tk: string; orderId: string }) {
  const router = useRouter();

  const ts = React.useMemo(() => String(Date.now()), []);

  const [state, formAction] = useFormState<State, FormData>(criarConta as any, initialState);

  const [regenLoading, setRegenLoading] = React.useState(false);

  React.useEffect(() => {
    if (state?.ok && state?.redirect) {
      const t = setTimeout(() => router.push(state.redirect!), 1500);
      return () => clearTimeout(t);
    }
  }, [state?.ok, state?.redirect, router]);

  const disabled = !!state?.ok;

  const isPaidPurchaseMode = !tk || !!orderId;

  const showRegen = Boolean(tk) && state?.code === "signup_token_invalid";

  async function handleGenerateNewLink() {
    try {
      setRegenLoading(true);

      const r = await fetch("/api/signup-token", { method: "POST" });
      const j = await r.json();

      if (!r.ok) {
        alert(j?.error || "Falha ao gerar novo link. Tente novamente.");
        return;
      }

      if (!j?.ok || !j?.token) {
        alert("Falha ao gerar novo link. Tente novamente.");
        return;
      }

      router.replace(`/criar-conta?tk=${encodeURIComponent(j.token)}`);
    } catch {
      alert("Falha ao gerar novo link. Tente novamente.");
    } finally {
      setRegenLoading(false);
    }
  }

  return (
    <AuthShell title="Publ.IA - Nexus Pública" subtitle="Crie sua conta para acessar o painel.">
      <div className="mx-auto w-full max-w-2xl">
        {isPaidPurchaseMode && !state.ok && (
          <div className="mb-4 rounded-md border border-blue-200 bg-blue-50 px-4 py-3 text-sm leading-6 text-blue-900">
            <strong>Comprou o Publ.IA?</strong>{" "}
            Crie sua conta usando o mesmo CPF/CNPJ e e-mail informados na compra.
            <br />
            Assim que o cadastro for concluído, seu plano pago será aplicado automaticamente.
          </div>
        )}

        {state.error && !state.ok && (
          <div className="space-y-2">
            <Alert type="error">{state.error}</Alert>

            {showRegen && (
              <button
                type="button"
                onClick={handleGenerateNewLink}
                disabled={regenLoading}
                className="w-full rounded-md border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-800 hover:bg-slate-50 disabled:opacity-60"
              >
                {regenLoading ? "Gerando novo link..." : "Gerar novo link de cadastro"}
              </button>
            )}
          </div>
        )}

        <form action={formAction} className="mt-2 space-y-4" autoComplete="off">
          <input type="hidden" name="tk" value={tk} />
          <input type="hidden" name="order_id" value={orderId} />
          <input type="hidden" name="ts" value={ts} />

          <div
            style={{
              position: "absolute",
              left: "-5000px",
              top: "auto",
              width: "1px",
              height: "1px",
              overflow: "hidden",
            }}
            aria-hidden="true"
          >
            <label htmlFor="company">Company</label>
            <input id="company" name="company" type="text" tabIndex={-1} autoComplete="off" />
          </div>

          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <div className="md:col-span-2">
              <AuthInput
                name="cpf_cnpj"
                type="text"
                label="CPF / CNPJ"
                placeholder="Digite seu CPF ou CNPJ"
                disabled={disabled}
                required
                inputMode="numeric"
                autoComplete="off"
                autoCorrect="off"
                autoCapitalize="none"
                spellCheck={false}
              />
            </div>

            <div className="md:col-span-2">
              <AuthInput
                name="nome"
                label="Nome ou Razão Social"
                placeholder="Seu nome completo ou razão social"
                disabled={disabled}
                required
              />
            </div>

            <AuthInput
              name="telefone"
              type="tel"
              label="Telefone/WhatsApp"
              placeholder="(00) 00000-0000"
              disabled={disabled}
              required
              inputMode="tel"
              autoComplete="tel"
            />

            <AuthInput
              name="email"
              type="email"
              label="E-mail"
              placeholder="Seu melhor e-mail"
              disabled={disabled}
              required
              inputMode="email"
              autoComplete="email"
              autoCorrect="off"
              autoCapitalize="none"
              spellCheck={false}
            />

            <AuthInput
              name="municipio"
              label="Município"
              placeholder="Ex.: Santana do Itararé"
              disabled={disabled}
              required
            />

            <AuthInput
              name="uf"
              label="Estado / UF"
              placeholder="Ex.: PR"
              disabled={disabled}
              required
            />

            <div className="md:col-span-2">
              <fieldset disabled={disabled} className="space-y-2">
                <legend className="block text-sm font-medium text-slate-700">
                  Porte do Município
                </legend>

                <div className="grid grid-cols-1 gap-2 md:grid-cols-3">
                  <label className="flex min-h-[96px] cursor-pointer items-start gap-3 rounded-md border border-slate-300 bg-white px-3 py-3 text-sm text-slate-700 transition hover:border-slate-400">
                    <input
                      type="radio"
                      name="porte_municipio"
                      value="pequeno"
                      className="mt-1"
                      required
                      disabled={disabled}
                    />
                    <span>
                      <span className="block font-medium">Pequeno</span>
                      <span className="block text-xs leading-5 text-slate-500">
                        até 50 mil habitantes
                      </span>
                    </span>
                  </label>

                  <label className="flex min-h-[96px] cursor-pointer items-start gap-3 rounded-md border border-slate-300 bg-white px-3 py-3 text-sm text-slate-700 transition hover:border-slate-400">
                    <input
                      type="radio"
                      name="porte_municipio"
                      value="medio"
                      className="mt-1"
                      required
                      disabled={disabled}
                    />
                    <span>
                      <span className="block font-medium">Médio</span>
                      <span className="block text-xs leading-5 text-slate-500">
                        de 50 mil até 200 mil habitantes
                      </span>
                    </span>
                  </label>

                  <label className="flex min-h-[96px] cursor-pointer items-start gap-3 rounded-md border border-slate-300 bg-white px-3 py-3 text-sm text-slate-700 transition hover:border-slate-400">
                    <input
                      type="radio"
                      name="porte_municipio"
                      value="grande"
                      className="mt-1"
                      required
                      disabled={disabled}
                    />
                    <span>
                      <span className="block font-medium">Grande</span>
                      <span className="block text-xs leading-5 text-slate-500">
                        acima de 200 mil habitantes
                      </span>
                    </span>
                  </label>
                </div>
              </fieldset>
            </div>

            <div className="md:col-span-2">
              <AuthPasswordInput
                name="senha"
                label="Senha (mínimo 8 caracteres)"
                placeholder="Crie uma senha segura"
                disabled={disabled}
                minLength={8}
                required
                autoComplete="new-password"
              />
            </div>
          </div>

          <div className="pt-2">
            <SubmitButton disabled={disabled}>ENVIAR</SubmitButton>
          </div>

          {state.ok && (
            <div className="mt-4 space-y-2">
              <Alert type="success">Conta criada com sucesso! Você já pode fazer LOGIN.</Alert>

              <div className="text-center">
                <Link
                  href={state.redirect || "/login"}
                  className="inline-flex items-center justify-center rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
                >
                  FAZER LOGIN
                </Link>
              </div>
            </div>
          )}
        </form>
      </div>
    </AuthShell>
  );
}