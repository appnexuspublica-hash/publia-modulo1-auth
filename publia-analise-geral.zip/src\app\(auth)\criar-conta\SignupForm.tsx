//src/app/(auth)/criar-conta/SignupForm.tsx

"use client";

import { useEffect } from "react";
import { useFormState } from "react-dom";
import { criarConta, type SignUpState } from "./formActions";

import AuthInput from "@/components/auth/AuthInput";
import AuthPasswordInput from "@/components/auth/AuthPasswordInput";
import SubmitButton from "@/components/auth/SubmitButton";
import Alert from "@/components/auth/Alert";

const initialState: SignUpState = { ok: false };

type Props = {
  token: string;
  tokenOk: boolean;
};

export default function SignupForm({ token, tokenOk }: Props) {
  const [state, formAction] = useFormState<SignUpState, FormData>(criarConta, initialState);

  useEffect(() => {
    if (state?.ok && state.redirect) {
      window.location.href = state.redirect;
    }
  }, [state]);

  const blocked = !tokenOk;

  return (
    <form action={formAction} className="space-y-4" autoComplete="off">
      <input type="hidden" name="tk" value={token} />

      {!tokenOk && (
        <Alert
          variant="error"
          title="Cadastro bloqueado. Token inválido."
          message="Use o link oficial enviado pela Nexus Pública para criar sua conta."
        />
      )}

      {state?.error && tokenOk && (
        <Alert variant="error" title={state.error ?? "Erro ao cadastrar."} />
      )}

      <AuthInput
        name="cpf_cnpj"
        type="text"
        label="CPF/CNPJ"
        placeholder="Digite seu CPF ou CNPJ"
        required
        disabled={blocked}
        inputMode="numeric"
        autoComplete="off"
        autoCorrect="off"
        autoCapitalize="none"
        spellCheck={false}
      />

      <AuthInput
        name="nome"
        label="Nome / Razão Social"
        placeholder="Seu nome completo"
        required
        disabled={blocked}
      />

      <AuthInput
        name="email"
        type="email"
        label="E-mail"
        placeholder="seuemail@exemplo.com"
        required
        disabled={blocked}
        inputMode="email"
        autoComplete="email"
        autoCorrect="off"
        autoCapitalize="none"
        spellCheck={false}
      />

      <AuthInput
        name="telefone"
        type="tel"
        label="Telefone (WhatsApp)"
        placeholder="(00) 99999-0000"
        required
        disabled={blocked}
        inputMode="tel"
        autoComplete="tel"
      />

      <AuthInput
        name="municipio"
        label="Município"
        placeholder="Santana do Itararé"
        required
        disabled={blocked}
      />

      <AuthInput
        name="uf"
        label="Estado / UF"
        placeholder="PR"
        required
        disabled={blocked}
      />

      <AuthPasswordInput
        name="senha"
        label="Senha (mínimo 8)"
        placeholder="Digite uma senha segura"
        required
        disabled={blocked}
        autoComplete="new-password"
      />

      <div className="pt-2">
        <SubmitButton disabled={blocked}>Criar conta</SubmitButton>
      </div>
    </form>
  );
}